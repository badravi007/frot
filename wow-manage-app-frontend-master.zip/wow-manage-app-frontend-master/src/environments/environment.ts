export const environment = {
  production: true,
  // baseURL: 'http://localhost:3021/api/',
  baseURL: 'http://49.50.69.61:3000/api/',
  // baseURL: 'https://manageappapi.getbiz.app/api/',

  // baseURL_Live: 'https://apitemplate.getbiz.app',

  form: 'https://apitemplate.getbiz.app/api/template-getbiz/form-controller/simple-form',
  get_ip_location: 'https://api.ipgeolocation.io/ipgeo',

  getster_login: 'getster_profile/getster_login',
  getster_logout: 'getster_profile/getster_logout',

  add_category: `user_category/add-category`,
  get_categories: `user_category/get-all-categories`,
  update_category: `user_category/update-category`,
  hide_category: `user_category/hide-category`,

  assign_category: `user_category/assign-category`,
  update_assigned_category: `user_category/update-assigned-category`,
  check_user_is_assigned_category: `user_category/check-user-is-assigned-category`,
  get_users: `user_category/get-users`,
  get_users_category_id: `user_category/get-users-by-category-id`,
  get_assigned_category: `user_category/get-assign-category`,
  passingUsersParentToChild: `user_category/passing-users-from-parent-to-child`,

  // Business Country Start New
  add_educational_institutions_category:
    'educational_institutions_category/add_educational_institutions_category',
  get_all_educational_institutions_category:
    'educational_institutions_category/get_all_educational_institutions_category',
  update_educational_institutions_category:
    'educational_institutions_category/update_educational_institutions_category',
  hide_educational_institutions_category:
    'educational_institutions_category/hide_educational_institutions_category',
  check_is_assigned_user_app_category:
    'educational_institutions_category/check_is_assigned_user_app_category',
  add_demo_video_for_educational_institutions_category:
    'educational_institutions_category/add_demo_video_for_educational_institutions_category',
  get_demo_video_for_educational_institution_category_by_id:
    'educational_institutions_category/get_demo_video_for_educational_institution_category_by_id',

  // ---------------------------- User App ---------------------------
  add_user_app: 'user_app_master/add_user_app',
  assign_category_to_user_app:
    'user_app_master/assign_category_to_user_app_custom_app',
  update_user_app_development_status: 'user_app_master/update_user_app_status',
  get_user_app_by_id: 'user_app_master/get_user_app_by_id',
  update_user_app: 'user_app_master/update_user_app',
  get_file_user_app_master: 'user_app_master/get_file_user_app_master',
  get_all_custom_apps: 'user_app_categories/get_all_custom_apps',

  // Additional Permission
  add_update_user_app_cloud_file_storage_permission:
    'user_app_cloud_storage_permission/add_update_user_app_cloud_file_storage_permission',
  get_user_app_cloud_storage_permission:
    'user_app_cloud_storage_permission/get_user_app_cloud_storage_permission',

  // User app additional data
  add_user_app_additional_data:
    'user_app_additional_data/add_user_app_additional_data',
  get_user_app_additional_data:
    'user_app_additional_data/get_user_app_additional_data',
  update_user_app_additional_data:
    'user_app_additional_data/update_user_app_additional_data',

  user_app_category_id: 'user_app_master/get_all_user_app_by_category_ids',

  // About Video

  get_user_app_about_demo_video:
    'user_app_about_demo_video/get_user_app_about_demo_video',
  add_update_user_app_about_demo_video:
    'user_app_about_demo_video/add_update_user_app_about_demo_video',
  update_user_app_about_demo:
    'user_app_about_demo_video/update_user_app_about_demo',

  // Comments and UserAppCommunicationComponent
  create_user_app_comments_communication_table:
    'user_app_comments/create_user_app_comments_communication_table',

  get_user_app_communication:
    'user_app_communication/get_user_app_communication',
  add_user_app_communication:
    'user_app_communication/add_user_app_communication',
  delete_user_app_communication:
    'user_app_communication/delete_user_app_communication',
  update_user_app_communication:
    'user_app_communication/update_user_app_communication',

  get_user_app_comments: 'user_app_comments/get_user_app_comments',
  add_user_app_comments: 'user_app_comments/add_user_app_comments',
  delete_user_app_comments: 'user_app_comments/delete_user_app_comments',
  update_user_app_comments_type:
    'user_app_comments/update_user_app_comments_type',
  update_user_app_comments: 'user_app_comments/update_user_app_comments',

  // app_launch_screen_display
  add_update_user_app_launch_screen_display:
    'getbiz_app_launch_Screen_display/add_update_user_app_launch_screen_display',
  update_user_app_launch_screen_display:
    'getbiz_app_launch_Screen_display/update_user_app_launch_screen_display',
  get_user_app_launch_screen_display:
    'getbiz_app_launch_Screen_display/get_user_app_launch_screen_display',

  get_file_user_app_launch_screen_display:
    'getbiz_app_launch_Screen_display/get_file_user_app_launch_screen_display',

  // ----------------------------- GETster App Apis ------------------------
  get_all_getster_app_by_category_wise:
    'getster_app_master/get_all_getster_app_by_category_wise',
  get_getster_app_by_id: 'getster_app_master/get_getster_app_by_id',
  get_file_getster_app_master: 'getster_app_master/get_file_getster_app_master',
  add_getster_app: 'getster_app_master/add_getster_app',
  update_getster_app: 'getster_app_master/update_getster_app',
  create_getster_app_comments_communication_table:
    'getster_app_comments/create_getster_app_comments_communication_table',
  update_getster_app_status: 'getster_app_master/update_getster_app_status',

  // About Video
  add_getster_app_about_demo_video_description:
    'getster_app_about_demo_video_description/add_getster_app_about_demo_video_description',
  get_getster_app_about_demo_video_description:
    'getster_app_about_demo_video_description/get_getster_app_about_demo_video_description',
  update_getster_app_about_demo_video_description:
    'getster_app_about_demo_video_description/update_getster_app_about_demo_video_description',

  // Communication
  add_getster_app_communication:
    'getster_app_communication/add_getster_app_communication',
  get_getster_app_communication:
    'getster_app_communication/get_getster_app_communication',
  delete_getster_app_communication:
    'getster_app_communication/delete_getster_app_communication',
  update_getster_app_communication:
    'getster_app_communication/update_getster_app_communication',

  // Comment
  get_getster_app_comments: 'getster_app_comments/get_getster_app_comments',
  add_getster_app_comments: 'getster_app_comments/add_getster_app_comments',
  delete_getster_app_comments:
    'getster_app_comments/delete_getster_app_comments',
  update_getster_app_comments_type:
    'getster_app_comments/update_getster_app_comments_type',
  update_comments: 'getster_app_comments/update_getster_app_comments',
  get_all_getster_app_audit_trail:
    'getster_app_master/get_all_getster_app_audit_trail',

  // Category
  check_getster_is_assigned_getster_app_category:
    'getster_app_category/check_getster_is_assigned_getster_app_category',
  add_getster_app_category: 'getster_app_category/add_getster_app_category', //
  update_getster_app_category:
    'getster_app_category/update_getster_app_category', //
  get_all_getster_app_category:
    'getster_app_category/get_all_getster_app_category', //
  hide_getster_app_category: 'getster_app_category/hide_getster_app_category', //
  delete_getster_app_category:
    'getster_app_category/delete_getster_app_category',
  assign_getster_category_to_getster_app:
    'getster_app_categories_assignment/assign_getster_category_to_getster_app',
  delete_apps_from_category: 'getster-app/api/ReAssignAppsDeletegetsterId',

  reassign_getster_app_category_id_to_another:
    'getster_app_category/reassign-getster-app-category-id-to-another',
  //-----------------------Custom App -------------------------

  get_custom_app_by_id: 'custom_app_master/get_custom_app_by_id',
  add_custom_app: 'custom_app_master/add_custom_app',
  update_custom_app: 'custom_app_master/update_custom_app',
  get_file_custom_app_master: 'custom_app_master/get_file_custom_app_master',
  update_custom_app_development_status:
    'custom_app_master/update_custom_app_development_status',

  get_custom_app_communication:
    'custom_app_communication/get_custom_app_communication',
  add_custom_app_communication:
    'custom_app_communication/add_custom_app_communication',
  create_custom_app_comments_communication_table:
    'custom_app_comments/create_custom_app_comments_communication_table',
  delete_custom_app_communication:
    'custom_app_communication/delete_custom_app_communication',
  update_custom_app_notification:
    'custom_app_communication/UpdateCommunicationData',

  get_custom_app_comments: 'custom_app_comments/get_custom_app_comments',
  add_custom_app_comments: 'custom_app_comments/add_custom_app_comments',
  delete_custom_app_comments: 'custom_app_comments/delete_custom_app_comments',
  update_custom_app_comments_type:
    'custom_app_comments/update_custom_app_comments_type',
  update_custom_app_comments: 'custom_app_comments/update_custom_app_comments',

  // cloud_file_storage_permission
  add_custom_app_cloud_file_storage_permission:
    'custom_app_cloud_file_storage_permission/add_custom_app_cloud_file_storage_permission',
  get_custom_app_cloud_file_storage_permission:
    'custom_app_cloud_file_storage_permission/get_custom_app_cloud_file_storage_permission',
  update_custom_app_cloud_file_storage_permission:
    'custom_app_cloud_file_storage_permission/update_custom_app_cloud_file_storage_permission',
  // additional_data
  add_custom_app_additional_data:
    'custom_app_additional_data/add_custom_app_additional_data',
  get_custom_app_additional_data:
    'custom_app_additional_data/get_custom_app_additional_data',
  update_custom_app_additional_data:
    'custom_app_additional_data/update_custom_app_additional_data',
  get_all_custom_app_audit_trail:
    'custom_app_master/get_all_custom_app_audit_trail',

  // Demo Video
  get_custom_app_about_demo_video_description:
    'custom_app_about_demo/get_custom_app_about_demo_video_description',

  update_custom_app_about_demo:
    'custom_app_about_demo/update_custom_app_about_demo',

  add_custom_app_about_demo_video_description:
    'custom_app_about_demo/add_custom_app_about_demo_video_description',

  // Category
  get_all_custom_apps_by_category_wise:
    'custom_app_master/get_all_custom_apps_by_category_wise',
  get_all_user_custom_apps_by_category_ids:
    'custom_app_master/get_all_user_custom_apps_by_category_ids',

  // ------------------ Category Management -----------------
  get_user_category_wise_app_access_and_userapp_user_registration_data: '',
  get_user_app_categories: '',
  get_all_user_app_by_category_ids: '',

  add_user_category_wise_app_access:
    'getster_category/add-user-category-wise-app-access',
  get_user_category_wise_app_access:
    'getster_category/get-user-category-wise-app-access',
  reassign_user_category_id_to_another: '',
  user_category_audit_trail: '',
  get_additional_data_fields_by_user_category_id: '',

  // Getster Category
  get_all_getster_category: 'getster_category/get_all_getster_category',
  add_getster_category: 'getster_category/add_getster_category',
  update_getster_category: 'getster_category/update_getster_category',
  hide_getster_category: 'getster_category/hide_getster_category',
  check_getster_is_assigned_getster_category:
    'getster_category/check_getster_is_assigned_getster_category',
  reassign_getster_category_id_to_another:
    'getster_category/reassign-getster-category-id-to-another',
  get_getster_category_wise_additional_fields:
    'getster_category/get-getster-category-wise-additional-fields',
  get_getster_getster_category_audit_trail:
    'getster_category/get-getster-getster-category-audit-trail',

  // Getster Register

  login_register: 'manage-getster/login-register',

  login_with_registered_mobile_number:
    'manage-getster/login-with-registered-mobile-number',
  login_with_getster_password: 'manage-getster/login-with-getster-password',

  // App screen
  home_screen_apps: 'manage-getster/home-screen-apps',

  //----------------------- Console User -------------------------
  get_new_getster: 'console-user/get-approval-getster',
  get_existing_profile: 'console-user/get-admin-getster',
  update_getster_profile: 'console-user/update-new-getster',
  get_getster_profile: 'console-user/get-getster-profile',
  get_audit_trail: 'console-user/get-audit-trail',
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //
  get_all_business_countries: 'business_countries/get_all_business_country',
  update_business_country: 'business_countries/update_business_country',
  add_business_countries: 'business_countries/add_business_country',
  delete_business_country: 'business_countries/delete_business_country',

  get_all_business_categories:
    'business_categories/get_all_business_categories',
  add_business_category: 'business_categories/add_business_category',
  update_business_category: 'business_categories/update_business_category',
  delete_business_category: 'business_categories/delete_business_category',

  add_business_category_about_demo_video:
    'business_category/add_business_category_about_demo_video',
  update_business_category_about_demo_video:
    'business_category/update_business_category_about_demo_video',
  get_business_category_about_demo_video:
    'business_category/get_business_category_about_demo_video',

  reassign_business_category: 'user-app/api/ReAssignUserAppsBusinessCategory',
  get_all_user_app_by_business_category_id:
    'business_categories/get_all_user_app_by_business_category_id',
  delete_reassigned_business_category:
    'user-app/api/ReAssignUserAppsBusinessCategoryDeleteUserId',

  get_all_user_apps: 'user_app_categories/get_all_user_apps',
  get_all_user_custom_apps: 'user_app_categories/get_all_user_custom_apps',

  get_all_user_app_audit_trail: 'user_app_master/get_all_user_app_audit_trail',
  get_all_business_category_audit_trail:
    'business_categories/get_all_business_category_audit_trail',
  get_all_country_audit_trail: 'business_countries/get_all_country_audit_trail',

  get_all_user_app_by_category_id:
    'user_app_categories/get_all_user_app_by_category_id',
  delete_user_apps_from_category: 'user-app/api/ReAssignAppsDeleteUserId',
  delete_user_app_category: 'user_app_categories/delete_user_app_category',
  reassign_user_app_category: 'user_app_master/reassign_user_app_category',
  reassign_user_app_business_category:
    'business_categories/reassign_user_app_business_category',
  update_assign_user_apps_category: 'user-app/api/ReAssignUserApps',

  get_app_category_by_id: 'getster-app/api/GetAllCategoriesById',
  get_all_getster_app_by_ids: 'getster_app_master/get_all_getster_app_by_ids',
  update_preview_location: 'getster-app/api/ModifyCategory',
  update_preview_location1: 'getster-app/api/ReLocateApp',

  // User App Category
  get_all_user_app_category: 'user_app_categories/get_all_user_app_category',
  add_user_app_category: 'user_app_categories/add_user_app_category',
  update_user_app_category: 'user_app_categories/update_user_app_category',
  hide_user_app_category: 'user_app_categories/hide_user_app_category',
  check_user_app_is_assigned_user_app_category:
    'user_app_categories/check_user_app_is_assigned_user_app_category',

  // Custom-app
  get_customer_list: 'custom-app/api/GetCustomapps_Customerslist',
  get_customer_app: 'launch-app/api/Manifest/list',
  add_customer_app: 'custom-app/api/AddCustomapps_Customerslist',
  delete_customer_app: 'custom-app/api/DeleteCustomapps_Customerslist',

  assign_custom_app_to_user_category:
    'custom_app_master/assign_custom_app_to_user_category',

  //
  get_getster_category_wise_getster_apps:
    'getster_profile/get_getster_category_wise_getster_apps',
  delete_getster_category: 'getster_category/delete_getster_category',
  get_all_getster_by_category_id:
    'getster_category/get_all_getster_by_category_id',
  reassign_getster_category: 'getster_category/reassign_getster_category',

  get_getster_apps: 'getster_profile/get_getster_home_screen_app',
  add_getster_recent_app: 'getster_profile/add_getster_recent_app',
  get_getster_recent_app: 'getster_profile/get_getster_recent_app',
  add_getster_favourite_app: 'getster_profile/add_getster_favourite_app',
  remove_favourite_apps: 'getster_profile/remove_getster_favorite_app',
  get_getster_favourite_app: 'getster_profile/get_getster_favourite_app',
  get_getster_profile_by_status:
    'getster_profile/get_getster_profile_by_status',
  get_getster_profile_by_getster_id:
    'getster_profile/get_getster_profile_by_getster_id',
  update_getster_mobile_number: 'getster_profile/update_getster_mobile_number',
  update_getster_profile_by_getster:
    'getster_profile/update_getster_profile_by_getster',
  get_individual_getster_profile: 'getster-master/api/IndividualGetsterId',
  update_getster_profile_status:
    'getster_profile/update_getster_profile_status',
  // update_getster_profile:
  //   'getster-master/api/UpdateAdditionalGetsterDataFieldValues',
  assign_getster_category_app_wise:
    'getster_profile/assign_getster_category_app_wise',
  get_user_audit_trail:
    'getster-master/api/GetsterIdLogin/api/Getgetster_audit_trail',
  get_all_getster_profile_audit_trail:
    'getster_profile/get_all_getster_profile_audit_trail',
  get_all_getster_console_profile_audit_trail:
    'getster_profile/get_all_getster_console_profile_audit_trail',
  get_getster_category_admin_audit_trail:
    'getster_category/get_getster_category_admin_audit_trail',
  get_additional_getster_form_field:
    'getster_profile/get_additional_getster_form_field',
  add_getster_registration: 'getster_profile/add_getster_registration',

  // common data field
  add_generic_launch_screen_images:
    'generic_launch_screen_image/add_generic_launch_screen_images',
  update_generic_launch_screen_images:
    'generic_launch_screen_image/update_generic_launch_screen_images',
  get_all_generic_launch_screen_images:
    'generic_launch_screen_image/get_all_generic_launch_screen_images',
  get_generic_launch_screen_images_by_id:
    'generic_launch_screen_image/get_generic_launch_screen_images_by_id',
  delete_all_generic_launch_screen_images:
    'common-data-app/api/DeleteALLGenericLaunchScreenImages',
  delete_generic_launch_screen_image:
    'generic_launch_screen_image/delete_generic_launch_screen_image',
  get_all_generic_launch_screen_images_audit_trail:
    'generic_launch_screen_image/get_all_generic_launch_screen_images_audit_trail',

  add_business_specific_launch_screen_images:
    'business_specific_launch_screen_image/add_business_specific_launch_screen_images',
  update_business_specific_launch_screen_images:
    'business_specific_launch_screen_image/update_business_specific_launch_screen_images',
  get_all_business_specific_launch_screen_images:
    'business_specific_launch_screen_image/get_all_business_specific_launch_screen_images',
  get_business_specific_launch_screen_images_by_category_id:
    'business_specific_launch_screen_image/get_business_specific_launch_screen_images_by_category_id',
  get_by_id_business_specific_launch_screen_images:
    'business_specific_launch_screen_image/GetBusinessSpecificLaunchScreenImages',
  delete_all_business_specific_launch_screen_images:
    'business_specific_launch_screen_image/DeleteALLBusinessSpecificLaunchScreenImages',
  delete_business_specific_launch_screen_image:
    'business_specific_launch_screen_image/delete_business_specific_launch_screen_image',
  get_all_business_specific_launch_screen_images_audit_trail:
    'business_specific_launch_screen_image/get_all_business_specific_launch_screen_images_audit_trail',
};
