import { HttpClient, HttpHandler } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SwUpdate } from '@angular/service-worker';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  // title = 'Manage App';
  private config: { version: string };
  mySubscription: Subscription;
  private http: HttpClient;
  constructor(
    private updateService: SwUpdate,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private handler: HttpHandler
  ) {
    this.http = new HttpClient(handler);
    // this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    // this.mySubscription = this.router.events.subscribe((event) => {
    //   if (event instanceof NavigationEnd) {
    //     this.router.navigated = false;
    //   }
    // });
  }

  ngOnInit() {
    // this.config = require('../assets/config/config.json');
    // console.log('APP Version',this.config.version);

    // const headers = new HttpHeaders()
    //   .set('Cache-Control', 'no-cache')
    //   .set('Pragma', 'no-cache');

    // this.http
    //   .get<{ version: string }>('../assets/config/config.json', { headers })
    //   .subscribe((config) => {
    //     console.log('comparing',config.version, 'and',this.config.version);
    //     if (config.version !== this.config.version) {
    //       this.http
    //         .get('', { headers, responseType: 'text' })
    //         .subscribe(() => location.reload());
    //     }
    //   });

    // location.reload();
    // console.log(VERSION.full);
    this.CheckBrowser();

    // if (!this.updateService.isEnabled) {
    //   console.log('AppComponent.ngOnInit: Service Worker is not enabled');
    //   return;
    // }
    // this.#handleUpdates();
  }

  // #handleUpdates() {
  //   this.updateService.versionUpdates.subscribe((event: VersionEvent) => {
  //     console.log(event);
  //     if (
  //       event.type === 'VERSION_READY' &&
  //       confirm(
  //         `A new version of ${this.title} app is available! Click to Update`
  //       )
  //     ) {
  //       window.location.reload();
  //     }
  //   });

  //   this.updateService.unrecoverable.subscribe(
  //     (event: UnrecoverableStateEvent) => {
  //       alert('Error reason : ' + event.reason);
  //     }
  //   );
  // }
  ngOnDestroy() {
    // if (this.mySubscription) {
    //   this.mySubscription.unsubscribe();
    // }
  }

  CheckBrowser() {
    let browsername = '';
    if (
      (navigator.userAgent.indexOf('Opera') ||
        navigator.userAgent.indexOf('OPR')) != -1
    ) {
      // alert('Opera');
      browsername = 'Opera';
    } else if (navigator.userAgent.indexOf('Edg') != -1) {
      // alert('Edge');
      browsername = 'Edge';
    } else if (navigator.userAgent.indexOf('Chrome') != -1) {
      // alert('Chrome');
      browsername = 'Chrome';
    } else if (navigator.userAgent.indexOf('Safari') != -1) {
      // alert('Safari');
      browsername = 'Safari';
    } else if (navigator.userAgent.indexOf('Firefox') != -1) {
      // alert('Firefox');
      browsername = 'Firefox';
    } else if (
      navigator.userAgent.indexOf('MSIE') != -1 ||
      !!document.DOCUMENT_NODE == true
    ) {
      //IF IE > 10
      // alert('IE');
      browsername = 'IE';
    } else {
      // alert('unknown');
      browsername = 'unknown';
    }
    sessionStorage.setItem('browsername', browsername);
  }
}
