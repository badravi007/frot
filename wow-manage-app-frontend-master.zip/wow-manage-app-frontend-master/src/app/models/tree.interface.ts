export interface TreeData {
  getster_category_id?: string;

  parent_getster_category_id?: string;

  getster_category_name?: string;

  is_the_getster_category_hidden?: boolean | string | number;

  getster_category_type?: string;

  children?: TreeData[];

  level?: number;
  expandable?: boolean;

  customer_id?: any;
  country_code?: any;
  user_id?: any;
}

export interface DialogData {
  getster_category_name: string;
  Component: string;
  parent: TreeData;
  isTop: boolean;
}

export interface UserAppTreeData {
  customer_id?: string;
  country_code?: string;
  user_app_category_id: string;
  parent_user_app_category_id?: string;
  user_app_category_name: string;
  is_the_user_app_category_hidden: boolean | string | number;
  user_app_category_type: string;
  children: TreeData[];
  level?: number;
  expandable?: boolean;
}
