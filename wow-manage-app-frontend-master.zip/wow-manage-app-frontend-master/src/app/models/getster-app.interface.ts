export interface GETsterAppCategoryData {
  getster_app_category_id: string;
  parent_getster_app_category_id?: string;
  getster_app_category_name: string;
  is_the_getster_app_category_hidden: boolean | string | number;
  getster_app_category_type: string;
  children: GETsterAppCategoryData[];
  level?: number;
  expandable?: boolean;
}

export interface GETsterAppDialogData {
  getster_app_category_name: string;
  Component: string;
  parent: GETsterAppCategoryData;
  isTop: boolean;
}
