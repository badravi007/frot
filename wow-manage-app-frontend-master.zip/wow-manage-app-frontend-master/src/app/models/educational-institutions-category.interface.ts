export interface EducationalInstitutionsCategoryData {
  country_code: string;
  user_app_educational_institution_category_id: string;
  parent_user_app_educational_institution_category_id?: string;
  user_app_educational_institution_category_name: string;
  is_user_app_educational_institution_category_hidden:
    | boolean
    | string
    | number;
  user_app_educational_institution_category_type: string;
  children: EducationalInstitutionsCategoryData[];
  level?: number;
  expandable?: boolean;
}

export interface EducationalInstitutionsCategoryDialogData {
  user_app_educational_institution_category_name: string;
  Component: string;
  parent: EducationalInstitutionsCategoryData;
  isTop: boolean;
}
