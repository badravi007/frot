export interface GETsterCategoryData {
  getster_category_id?: string;
  parent_getster_category_id?: string;
  getster_category_name?: string;
  is_the_getster_category_hidden?: boolean | string | number;
  getster_category_type?: string;
  children?: GETsterCategoryData[];
  level?: number;
  expandable?: boolean;
}

export interface GETsterDialogData {
  getster_category_name: string;
  Component: string;
  parent: GETsterCategoryData;
  isTop: boolean;
}
