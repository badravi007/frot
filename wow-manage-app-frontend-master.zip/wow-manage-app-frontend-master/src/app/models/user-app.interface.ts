export interface UserAppCategoryData {
  user_app_category_id: string;
  parent_user_app_category_id?: string;
  user_app_category_name: string;
  is_the_user_app_category_hidden: boolean | string | number;
  user_app_category_type: string;
  children: UserAppCategoryData[];
  level?: number;
  expandable?: boolean;
}

export interface UserAppDialogData {
  user_app_category_name: string;
  Component: string;
  parent: UserAppCategoryData;
  isTop: boolean;
}
