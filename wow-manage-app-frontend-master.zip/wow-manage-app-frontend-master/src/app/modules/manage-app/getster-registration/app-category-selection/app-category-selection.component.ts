import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatTree, MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import { UserAppTreeData } from 'src/app/models/tree.interface';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';

@Component({
  selector: 'app-category-selection',
  templateUrl: './app-category-selection.component.html',
  styleUrls: ['./app-category-selection.component.scss'],
})
export class AppCategorySelectionComponent implements OnInit {
  nestedTreeControl: NestedTreeControl<any>;
  nestedDataSource: MatTreeNestedDataSource<any>;
  checklistSelection = new SelectionModel<any>(true /* multiple */);
  selected_category_val: any[] = [];
  user_app_by_category: any[] = [];

  @ViewChild('tree') user_app_category_tree: MatTree<any>;
  // apps_selection = new SelectionModel<any>(true, []);
  constructor(private _getsterService: GetsterService) {}

  @Output() selectedCategory = new EventEmitter<any>();
  ngOnInit() {
    this.nestedTreeControl = new NestedTreeControl<any>(this._getChildren);
    this.nestedDataSource = new MatTreeNestedDataSource();

    this._getsterService.getAllGetsterCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;
    });

    // Get App list
    this.checklistSelection.changed.subscribe({
      next: (next) => {
        this.selectedCategory.emit(this.checklistSelection.selected);
      },
    });
    // });
  }

  isChecked(node) {
    this.checklistSelection.isSelected(node);

    return false;
  }

  search_user_app_category_id: any;

  callRecursively(node: any) {
    if (node.getster_app_category_id === this.search_user_app_category_id) {
      this.todoLeafItemSelectionToggle(node);
      this.expand(this.nestedDataSource.data, this.search_user_app_category_id);
    }
    if (node.children) {
      node.children.forEach((childNode: any) => {
        this.callRecursively(childNode);
      });
    }
  }

  expand(data: any[], uniqueId: string): any {
    data.forEach((node) => {
      if (
        node.children &&
        node.children.find((c: any) => c.getster_app_category_id === uniqueId)
      ) {
        this.nestedTreeControl.expand(node);
        this.expand(this.nestedDataSource.data, node.getster_app_category_id);
      } else if (node.children && node.children.find((c: any) => c.children)) {
        this.expand(node.children, uniqueId);
      }
    });
  }

  private _getChildren = (node: UserAppTreeData) => of(node.children);

  hasNestedChild = (_: string, nodeData: UserAppTreeData) =>
    nodeData.children.length > 0;

  refreshTreeData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  getLevel = (node: UserAppTreeData) => node.level;

  isExpandable = (node: UserAppTreeData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: UserAppTreeData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_the_user_app_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: UserAppTreeData): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.checklistSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: UserAppTreeData): void {
    this.checklistSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
    // console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.checklistSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: UserAppTreeData): void {
    // console.log(node);
    this.checklistSelection.toggle(node);
    this.selected_category_val = this.checklistSelection.selected;
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: UserAppTreeData): void {
    let parent: UserAppTreeData | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: UserAppTreeData): void {
    const nodeSelected = this.checklistSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.checklistSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.checklistSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.checklistSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: UserAppTreeData): UserAppTreeData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl?.dataNodes?.indexOf(node) - 1;

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }
}
