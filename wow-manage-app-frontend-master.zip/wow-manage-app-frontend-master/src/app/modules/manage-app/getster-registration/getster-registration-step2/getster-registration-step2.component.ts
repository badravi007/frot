import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { Observable, Subject } from 'rxjs';
import { CanComponentLeave } from 'src/app/shared/guards/unsaved-changes/unsaved-changes.guard';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { RegistrationInfoService } from 'src/app/shared/services/registration/registrationinfo.service';

@Component({
  selector: 'app-getster-registration-step2',
  templateUrl: './getster-registration-step2.component.html',
  styleUrls: ['./getster-registration-step2.component.scss'],
})
export class GetsterRegistrationStep2Component
  implements OnInit, CanComponentLeave
{
  errorMsg = '';
  hide: any;
  gesterRegistrationForm2!: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private registrationInfoService: RegistrationInfoService,
    private formBuilder: FormBuilder
  ) {
    this.gesterRegistrationForm2 = this.formBuilder.group(
      {
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
        phone: ['', [Validators.required]],
      },
      {
        validator: this.MustMatch('password', 'confirmPassword'),
      }
    );
    // this.gesterRegistrationForm2 = new FormGroup(
    //   {
    //     password: new FormControl('', Validators.required),
    //     confirmPassword: new FormControl('', Validators.required),
    //     phone: new FormControl('', [Validators.required]),
    //   },
    //   {
    //     validator: this.MustMatch('password', 'confirmPassword'),
    //   }
    // );
  }

  canLeave() {
    if (this.gesterRegistrationForm2.valid) {
      return true;
    } else {
      return window.confirm(
        'You have some unsaved changes. Are you sure you want to navigate?'
      );
    }
  }
  // full_name: string;
  // first_name: any;
  // last_name: any;
  // date_of_birth: any;
  // gender: any;
  // getster_category_id: any;
  ngOnInit(): void {
    // this.registrationInfoService.getGETster().subscribe((res) => {
    //   this.first_name = res.first_name;
    //   this.last_name = res.last_name;
    //   this.date_of_birth = res.date_of_birth;
    //   this.gender = res.gender;
    //   this.getster_category_id = res.getster_category_id;
    //   this.full_name = res.first_name + ' ' + res.last_name;
    // });

    WebcamUtil.getAvailableVideoInputs().then(
      (mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      }
    );
  }

  bodyData: any;
  registerUser() {
    // if (!this.gesterRegistrationForm2.invalid) {
    //   let product: GETsterInfo = {} as GETsterInfo;
    //   product = {
    //     first_name: this.first_name,
    //     last_name: this.last_name,
    //     date_of_birth: this.date_of_birth,
    //     gender: this.gender,
    //     getster_category_id: this.getster_category_id,
    //     login_mobile_no: this.gesterRegistrationForm2.value.phone,
    //     getster_password: this.gesterRegistrationForm2.value.password,
    //     image: this.pictureTaken.imageAsDataUrl,
    //   };

    //   this.registrationInfoService.setGETster(product);

    //   this.router.navigate(['/launch-app/registration3', {}]).then(() => {});
    // }

    const data: any = {
      registered_mobile_country_code: this.getSelectedCountry,
      getster_password: this.gesterRegistrationForm2.value.confirmPassword,
      registered_mobile_number: this.getEnteredPhoneNo,
    };

    localStorage.setItem('registration_2', JSON.stringify(data));

    this.router.navigate(['/manage-app/registration3', {}]).then(() => {
      // window.location.reload();
    });
  }

  getSelectedCountry: number;
  getEnteredPhoneNo: number;
  selectedCountry(event) {
    this.getEnteredPhoneNo = event.phoneNumber;
    this.getSelectedCountry = event.selectedCountry.dialCode;
  }
  // we cam
  public pictureTaken: WebcamImage = null;

  // toggle webcam on/off
  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<
    boolean | string
  >();

  public triggerSnapshot(): void {
    this.trigger.next();
    console.info('received webcam image', this.pictureTaken.imageAsDataUrl);
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    // true => move forward through devices
    // false => move backwards through devices
    // string => move to device with given deviceId
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    console.info('received webcam image', webcamImage);
    this.pictureTaken = webcamImage;
  }

  public cameraWasSwitched(deviceId: string): void {
    // console.log('active device: ' + deviceId);
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.gesterRegistrationForm2.controls;
  }
  // Compare Two password
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control: AbstractControl<any> = formGroup.controls[controlName];
      const matchingControl: AbstractControl<any> =
        formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }
}
