/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { GetsterRegistrationStep3Component } from './getster-registration-step3.component';

describe('GetsterRegistrationStep3Component', () => {
  let component: GetsterRegistrationStep3Component;
  let fixture: ComponentFixture<GetsterRegistrationStep3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetsterRegistrationStep3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetsterRegistrationStep3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
