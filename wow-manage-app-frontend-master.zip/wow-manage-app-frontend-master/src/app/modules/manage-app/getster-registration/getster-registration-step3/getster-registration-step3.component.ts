import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { GetsterRegisterService } from 'src/app/shared/services/app-development-console/getster-register.service';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { RegistrationInfoService } from 'src/app/shared/services/registration/registrationinfo.service';

@Component({
  selector: 'app-getster-registration-step3',
  templateUrl: './getster-registration-step3.component.html',
  styleUrls: ['./getster-registration-step3.component.scss'],
})
export class GetsterRegistrationStep3Component implements OnInit {
  // getsterRegistrationForm3: FormGroup;

  title: string = 'AGM project';
  latitude: number;
  longitude: number;
  zoom: number;
  // Get Current Location Coordinates
  private setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 15;
      });
    }
  }

  // myForm!: FormGroup;

  arrayForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private registrationInfoService: RegistrationInfoService,
    private _getsterService: GetsterService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private _getsterRegisterService: GetsterRegisterService
  ) {
    // additional data
    // this.myForm = this.fb.group({
    //   dynamicForm: this.fb.array([]),
    // });

    this.arrayForm = this.fb.group({
      dynamicForm_1: this.fb.array([]),
      dynamicForm_2: this.fb.array([]),
      dynamicForm_3: this.fb.array([]),
    });
  }

  // first_name: any;
  // last_name: any;
  // date_of_birth: any;
  // gender: any;
  // getster_category_id: any;
  // login_mobile_no: string;
  // getster_password?: string;
  // image?: any;

  registration1Data: any;
  registration2Data: any;
  ngOnInit(): void {
    // this.registrationInfoService.getGETster().subscribe((res) => {
    //   this.first_name = res.first_name;
    //   this.last_name = res.last_name;
    //   this.date_of_birth = res.date_of_birth;
    //   this.gender = res.gender;
    //   this.getster_category_id = res.getster_category_id;
    //   this.login_mobile_no = res.login_mobile_no;
    //   this.getster_password = res.getster_password;
    //   this.image = res.image;
    // });

    this.setCurrentLocation();

    this.registration1Data = JSON.parse(localStorage.getItem('registration_1'));
    this.registration2Data = JSON.parse(localStorage.getItem('registration_2'));

    // this.getsterRegistrationForm3 = this.fb.group({
    //   formOne: this.fb.array([]),
    //   formTwo: this.fb.array([]),
    //   formThree: this.fb.array([]),
    // });

    this.getSelectedCategory();
  }

  // get formOne() {
  //   return this.getsterRegistrationForm3.get('formOne') as FormArray;
  // }
  // get formTwo() {
  //   return this.getsterRegistrationForm3.get('formTwo') as FormArray;
  // }
  // get formThree() {
  //   return this.getsterRegistrationForm3.get('formThree') as FormArray;
  // }

  markLocationOne: number = null;
  markLocationTwo: number = null;
  markLocationThree: number = null;

  categoryNameOne: String = null;
  categoryNameTwo: String = null;
  categoryNameThree: String = null;

  additionalFieldsList: any;

  onRegister() {
    let body = {
      ...this.registration1Data,
      ...this.registration2Data,
      additional_getster_data_field_values: this.arrayForm.value,
    };
    this._getsterRegisterService.loginRegister(body).subscribe((res) => {
      localStorage.removeItem('registration_1');
      localStorage.removeItem('registration_2');
      this.snackBar.open('Register Successful', 'OK', {
        duration: 3000,
      });
      this.router.navigate(['/manage-app/login', {}]).then(() => {});
    });
  }

  // additional data
  // get dynamicForms() {
  //   return this.myForm.get('dynamicForm') as FormArray;
  // }
  dynamicFormsField(index): FormArray {
    return this.arrayForm.get('dynamicForm_' + index) as FormArray;
  }

  getGetsterCategoryWiseAdditionalFields: any[] = [];
  onGetGetsterCategoryWiseAdditionalFields(getster_category_id) {
    this._getsterService
      .getGetsterCategoryWiseAdditionalFields(getster_category_id)
      .subscribe({
        next: (next) => {
          // this.dynamicForms.clear();
          for (let i = 0; i < next.data.length; i++) {
            const element = next.data[i];
            let fieldName = 'dynamicForm_' + (i + 1);

            let dynamicArray = this.arrayForm.get(fieldName) as FormArray;
            for (
              let j = 0;
              j < element.additional_getster_data_field_name.length;
              j++
            ) {
              const field = element.additional_getster_data_field_name[j];

              const header = this.fb.group({
                headerKey: [null, Validators.required],
                headerLabel: [field.headerKey, Validators.required],
                headerType: [field.headerType, Validators.required],
                headerValue: [field.headerValue],
                isMandatory: [field.isMandatory],
              });

              dynamicArray.push(header);
            }
          }
          this.getGetsterCategoryWiseAdditionalFields = next.data;
        },
      });
  }

  getSelectedCategoryIds: string;
  getSelectedCategory() {
    let registration1Data: any[] = JSON.parse(
      localStorage.getItem('registration_1')
    );
    this.getSelectedCategoryIds = registration1Data['getster_category_id'];

    this.onGetGetsterCategoryWiseAdditionalFields(this.getSelectedCategoryIds);
  }
}

interface marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}
