import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CanComponentLeave } from 'src/app/shared/guards/unsaved-changes/unsaved-changes.guard';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { RegistrationInfoService } from 'src/app/shared/services/registration/registrationinfo.service';
import { UtcTimeService } from 'src/app/shared/util/utc-time.service';

@Component({
  selector: 'app-getster-registration-step1',
  templateUrl: './getster-registration-step1.component.html',
  styleUrls: ['./getster-registration-step1.component.scss'],
})
export class GetsterRegistrationStep1Component
  implements OnInit, CanComponentLeave
{
  errorMsg = '';
  hide: any;
  getsterRegistrationForm1!: FormGroup;

  constructor(
    private router: Router,
    private registrationInfoService: RegistrationInfoService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private utcTimeService: UtcTimeService
  ) {}

  canLeave() {
    if (
      this.getsterRegistrationForm1.valid &&
      this.selectedCategory.length > 0
    ) {
      return true;
    } else {
      return window.confirm(
        'You have some unsaved changes. Are you sure you want to navigate?'
      );
    }
  }

  @ViewChild('contactForm') public contactForm: NgForm;

  ngOnInit(): void {
    this.getsterRegistrationForm1 = new FormGroup({
      first_name: new FormControl('', Validators.required),
      last_name: new FormControl('', Validators.required),
      date_of_birth: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
    });
  }

  onNext() {
    // console.log('DD' + this.getsterRegistrationForm1.value.dob);
    // console.log(
    //   'dob :' +
    //     this.utcTimeService.timestampToDate(
    //       this.getsterRegistrationForm1.value.dob
    //     )
    // );
    // let fname = this.getsterRegistrationForm1.value.firstname;
    // let lname = this.getsterRegistrationForm1.value.lastname;
    // if (
    //   fname != '' &&
    //   lname != '' &&
    //   this.getsterAppCategoryIds.length <= 3 &&
    //   this.getsterAppCategoryIds.length >= 1
    // ) {
    //   let dob = JSON.parse(
    //     JSON.stringify(this.getsterRegistrationForm1.value.dob)
    //   );

    //   let product: GETsterInfo = {} as GETsterInfo;
    //   product = {
    //     first_name: fname,
    //     last_name: lname,
    //     date_of_birth: dob,
    //     gender: this.getsterRegistrationForm1.value.gender,
    //     getster_category_id: this.getsterAppCategoryIds,
    //     login_mobile_no: '',
    //     getster_password: '',
    //     image: '',
    //   };

    //   this.registrationInfoService.setGETster(product);

    //   this.router.navigate(['/launch-app/registration2', {}]).then(() => {});
    // }
    let getSelectedCategoryIds: string[] = [];
    this.selectedCategory.map((m) => {
      getSelectedCategoryIds.push(m.getster_category_id);
    });
    let data: any = {
      ...this.getsterRegistrationForm1.value,
      getster_category_id: getSelectedCategoryIds.toString(),
    };

    localStorage.setItem('registration_1', JSON.stringify(data));
    this.router.navigate(['/manage-app/registration2', {}]).then(() => {});
  }

  selectedCategory: any[] = [];
  getSelectedCategory(event: any[]) {
    this.selectedCategory = event;
  }

  isValid() {
    if (
      this.getsterRegistrationForm1.valid &&
      this.selectedCategory.length > 0
    ) {
      return false;
    } else {
      return true;
    }
  }
}
