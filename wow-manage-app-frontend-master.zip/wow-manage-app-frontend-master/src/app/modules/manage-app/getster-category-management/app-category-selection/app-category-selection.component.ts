import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatTree, MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import { UserAppTreeData } from 'src/app/models/tree.interface';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { GETsterCategoryData } from './../../../../models/getster.interface';

@Component({
  selector: 'app-app-category-app-selection',
  templateUrl: './app-category-selection.component.html',
  styleUrls: ['./app-category-selection.component.scss'],
})
export class AppCategoryAppSelectionComponent implements OnInit {
  nestedTreeControl: NestedTreeControl<any>;
  nestedDataSource: MatTreeNestedDataSource<any>;
  checklistSelection = new SelectionModel<any>(true /* multiple */);
  selected_category_val: any[] = [];
  user_app_by_category: any[] = [];

  @Input() set selected_user_app_category_ids(value) {
    if (value) {
      if (value.length > 0) {
        this.checklistSelection.clear(true);
        this.user_app_category_tree.treeControl.collapseAll();
        this.getAllUserApp();
        this.getUserCategoryWiseAppAccess(value);
      } else {
        this.checklistSelection.clear(true);
        this.apps_selection.clear(true);
        this.list_of_apps = [];
        // this._dataShare.updateAppCategoryListOfAppData([]);
      }
    }
  }
  @Input() selected_user_category_wise_app_access: any; //!Remove

  @ViewChild('tree') user_app_category_tree: MatTree<any>;
  apps_selection = new SelectionModel<any>(true, []);
  list_of_apps: any[] = [];
  constructor(
    // private _apiService: UserCategoryManagementService,
    private _getsterAppService: GetsterAppService,
    private _getsterService: GetsterService,

    private _headerTitle: HeaderTitleService // private _dataShare: DataSharingService
  ) {}

  @Output() userAppSelectionData = new EventEmitter<any>();
  ngOnInit() {
    this._headerTitle.setTitle('Tree View');

    this.nestedTreeControl = new NestedTreeControl<any>(this._getChildren);
    this.nestedDataSource = new MatTreeNestedDataSource();

    this._getsterAppService.getAllGetsterAppCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;
    });

    this.apps_selection.changed.subscribe((val) => {
      // console.log(val);

      // Get App list
      let selectedGetsterApps: any[] = [];
      this.apps_selection.selected.map((e) => {
        selectedGetsterApps.push({
          getster_app_category_id: e.getster_app_category_id,
          getster_app_id: e.getster_app_id,
        });
      });

      this.userAppSelectionData.emit(selectedGetsterApps);
    });
  }

  search_user_app_category_id: any;
  ngOnChanges(changes: SimpleChanges): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    // console.log(changes['selected_user_app_category_ids']);
    // if (changes['selected_user_app_category_ids']?.currentValue) {
    //   // console.log(this.selected_user_app_category_ids);
    //   // if receive empty array clear the selections or received values means go with loop.
    // }
    // if (changes['selected_user_category_wise_app_access']?.currentValue) {
    //   console.log(this.selected_user_category_wise_app_access);
    //   this._dataShare.app_category_list_of_apps_data.subscribe((res) => {
    //     if (res) {
    //       let temp: any[] = [];
    //       for (let i = 0; i < this.list_of_apps.length; i++) {
    //         const element = this.list_of_apps[i].data;
    //         temp.push(...element);
    //       }
    //       // console.log(temp);
    //       // console.log(this.selected_user_category_wise_app_access);
    //       for (let i = 0; i < temp.length; i++) {
    //         const element = temp[i];
    //         this.selected_user_category_wise_app_access.forEach((e: any) => {
    //           // console.log(e);
    //           // console.log(element);
    //           if (
    //             +e.app_id === element.user_app_id &&
    //             e.getster_app_category_id === element.getster_app_category_id
    //           ) {
    //             // console.log(element);
    //             this.apps_selection.select(element);
    //           }
    //         });
    //       }
    //     }
    //   });
    // }
  }

  callRecursively(node: any) {
    if (node.getster_app_category_id === this.search_user_app_category_id) {
      this.todoLeafItemSelectionToggle(node);
      this.expand(this.nestedDataSource.data, this.search_user_app_category_id);
    }
    if (node.children) {
      node.children.forEach((childNode: any) => {
        this.callRecursively(childNode);
      });
    }
  }

  expand(data: any[], uniqueId: string): any {
    data.forEach((node) => {
      if (
        node.children &&
        node.children.find((c: any) => c.getster_app_category_id === uniqueId)
      ) {
        this.nestedTreeControl.expand(node);
        this.expand(this.nestedDataSource.data, node.getster_app_category_id);
      } else if (node.children && node.children.find((c: any) => c.children)) {
        this.expand(node.children, uniqueId);
      }
    });
  }

  private _getChildren = (node: UserAppTreeData) => of(node.children);

  hasNestedChild = (_: string, nodeData: UserAppTreeData) =>
    nodeData.children.length > 0;

  refreshTreeData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  getAllUserApp() {
    let getster_app_category_id: any[] = [];
    this.selected_category_val.map((e) => {
      getster_app_category_id.push(e.getster_app_category_id);
    });
    const getsterAppCategoryIds = getster_app_category_id.toString();

    if (this.checklistSelection.selected.length !== 0) {
      this._getsterAppService
        .getAllGetsterAppByIds(getsterAppCategoryIds)
        .subscribe((res) => {
          // this.user_app_by_category = res[0];
          // // this.userAppCategoryData.emit(res[0]);
          this.apps_selection.clear(true);
          this.list_of_apps = res.data;

          // this.selectedAppIdDetails

          if (res) {
            let temp: any[] = [];

            temp = this.list_of_apps;

            // console.log(temp);
            // console.log(this.selected_user_category_wise_app_access);
            for (let i = 0; i < temp.length; i++) {
              const element = temp[i];
              this.selectedAppIdDetails.forEach((e: any) => {
                // console.log(e);
                element.data.forEach((app) => {
                  if (
                    +e.getster_app_id === +app.getster_app_id &&
                    e.getster_app_category_id === app.getster_app_category_id
                  ) {
                    this.apps_selection.select(app);
                  }
                });
              });
            }
          }

          // this._dataShare.updateAppCategoryListOfAppData(res[0]);
        });
    } else if (this.checklistSelection.selected.length == 0) {
      this.user_app_by_category = [];
      this.apps_selection.clear(true);
      this.list_of_apps = [];
      // this._dataShare.updateAppCategoryListOfAppData([]);
      // this.userAppCategoryData.emit([]);
    }
  }

  selectedAppIdDetails: any;
  @Output() getsterGetsterAppCategoryInit = new EventEmitter<
    GETsterCategoryData[]
  >();

  getUserCategoryWiseAppAccess(getster_category_id: string) {
    this._getsterService
      .getUserCategoryWiseAppAccess(getster_category_id)
      .subscribe({
        next: (next) => {
          this.selectedAppIdDetails = next.data;

          this.getsterGetsterAppCategoryInit.emit(next.data);
          for (let i = 0; i < next.data.length; i++) {
            const getster_app_category_id =
              next.data[i].getster_app_category_id;
            this.search_user_app_category_id = getster_app_category_id;
            this.nestedDataSource?.data.forEach((node) => {
              this.callRecursively(node);
            });
          }
          this.getAllUserApp();
        },
      });
  }
  getLevel = (node: UserAppTreeData) => node.level;

  isExpandable = (node: UserAppTreeData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: UserAppTreeData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_the_user_app_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: UserAppTreeData): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.checklistSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: UserAppTreeData): void {
    this.checklistSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
    // console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.checklistSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: UserAppTreeData): void {
    // console.log(node);
    this.checklistSelection.toggle(node);
    this.selected_category_val = this.checklistSelection.selected;
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: UserAppTreeData): void {
    let parent: UserAppTreeData | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: UserAppTreeData): void {
    const nodeSelected = this.checklistSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.checklistSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.checklistSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.checklistSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: UserAppTreeData): UserAppTreeData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl?.dataNodes?.indexOf(node) - 1;

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  getSelectedAppsValues() {
    // this.apps_selection.selected;
    console.log(this.apps_selection.selected);
  }
}
