import { Component, DoCheck, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { GETsterCategoryData } from 'src/app/models/getster.interface';
import { CanComponentLeave } from 'src/app/shared/guards/unsaved-changes/unsaved-changes.guard';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { AppCategoryAppSelectionComponent } from './app-category-selection/app-category-selection.component';
import { AuditTrailGetsterCategoryManagementComponent } from './audit-trail-getster-category-management/audit-trail-getster-category-management.component';
import { CategorizationOfGetsterComponent } from './categorization-of-getster/categorization-of-getster.component';

@Component({
  selector: 'app-getster-category-management',
  templateUrl: './getster-category-management.component.html',
  styleUrls: ['./getster-category-management.component.scss'],
})
export class GetsterCategoryManagementComponent
  implements OnInit, CanComponentLeave, DoCheck
{
  myForm!: FormGroup;

  @ViewChild('appCategory') appCategory: AppCategoryAppSelectionComponent;
  @ViewChild('getsterCategory')
  getsterCategory: CategorizationOfGetsterComponent;
  getsterCategoryId: string;

  is_submit_btn_disable: boolean = true;
  submit_btn_name: string = 'SAVE';

  constructor(
    private _apiService: GetsterService,
    private _headerTitle: HeaderTitleService,
    public dialog: MatDialog,
    public snackBarService: SnackBarService,
    private fb: FormBuilder
  ) {
    // additional data
    this.myForm = this.fb.group({
      // dynamicForm: this.fb.array([this.createDefaultDynamicItem()]),
      dynamicForm: this.fb.array([]),
    });
  }

  selectedGetsterApps: {
    getster_app_category_id;
    getster_app_id;
  }[];
  ngOnInit() {}
  ngDoCheck(): void {
    // this.isSaveButtonDisabled();
  }

  canLeave(): boolean {
    let isValid =
      this.previewsSelection.length === this.currentSelection.length &&
      this.myForm.valid;

    if (isValid) {
      return true;
    } else {
      return window.confirm(
        'You have some unsaved changes. Are you sure you want to navigate?'
      );
    }
  }

  getSelectedGetsterCategoryID(category: GETsterCategoryData) {
    this.getsterCategoryId = category.getster_category_id;
    // this.getUserCategoryWiseAppAccess(category.getster_category_id);
    this.getGetsterCategoryWiseAdditionalFields(category.getster_category_id);
    if (category.getster_category_id) this.is_submit_btn_disable = false;
  }

  previewsSelection: any[] = [];
  currentSelection: any[] = [];
  getsterGetsterAppCategoryInit(category: GETsterCategoryData[]) {
    this.previewsSelection = category;
    if (category.length == 0) {
      this.submit_btn_name = 'SAVE';
    } else {
      this.submit_btn_name = 'UPDATE';
    }
  }
  getGetsterCategoryWiseAdditionalFields(getster_category_id) {
    this._apiService
      .getGetsterCategoryWiseAdditionalFields(getster_category_id)
      .subscribe({
        next: (next) => {
          this.dynamicForms.clear();

          if (next.data[0]?.additional_getster_data_field_name) {
            for (
              let i = 0;
              i < next.data[0].additional_getster_data_field_name.length;
              i++
            ) {
              const element =
                next.data[0].additional_getster_data_field_name[i];

              const header = this.fb.group({
                headerKey: [element.headerKey, Validators.required],
                headerType: [element.headerType, Validators.required],
                headerValue: [element.headerValue],
                isMandatory: [element.isMandatory],
              });

              this.dynamicForms.push(header);
            }
          } else {
            this.dynamicForms.push(this.createDefaultDynamicItem());
          }
        },
      });
  }

  getAppSelectionData(apps) {
    this.currentSelection = apps;
    this.selectedGetsterApps = apps;
  }

  // getUserCategoryWiseAppAccess(getster_category_id: string) {
  //   this._apiService
  //     .getUserCategoryWiseAppAccess(getster_category_id)
  //     .subscribe({
  //       next: (next) => {
  //         console.log(
  //           'file: getster-category-management.component.ts:51 ~ next',
  //           next.data
  //         );
  //       },
  //     });
  // }

  addedChildCategory() {
    // appCategory
    this.appCategory.user_app_category_tree.treeControl.collapseAll();
    this.appCategory.checklistSelection.clear(true);
    this.appCategory.apps_selection.clear(true);
    this.getsterCategoryId = null;
    this.appCategory.list_of_apps = [];

    // getsterCategory
    this.getsterCategory.selected_category_name_val = null;
  }

  reAssignedGetsterCategoryID() {
    // appCategory
    this.dynamicForms.clear();
    this.getsterCategoryId = null;
    this.appCategory.user_app_category_tree.treeControl.collapseAll();
    this.appCategory.apps_selection.clear(true);
    this.appCategory.checklistSelection.clear(true);
    this.appCategory.list_of_apps = [];

    // getsterCategory
    this.getsterCategory.selected_category_name_val = null;
  }

  saveCategoryDetails() {
    let data = {
      selected_getster_apps: this.selectedGetsterApps,
      additional_getster_data_field_name: this.dynamicForms.value,
      getster_category_id: this.getsterCategoryId,
      is_location_of_getster_required: false,
    };

    this._apiService.addUserCategoryWiseAppAccess(data).subscribe((next) => {
      this.reAssignedGetsterCategoryID();

      this.previewsSelection = null;
      this.currentSelection = null;
    });

    // if (this.submit_btn_name === 'SAVE') {
    // } else if (this.submit_btn_name === 'UPDATE') {
    //   this._apiService.updateUserCategoryWiseAppAccess(data).subscribe();
    // }

    // !NOTE: if there is no data in that category id use the insert query if already the data is present in the table means use the update query in it.

    // !TODO: get api based on the category id fetch the additional fields table data, category wise app access data.
  }

  openAuditTrail(): void {
    // Todo
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(
      AuditTrailGetsterCategoryManagementComponent,
      {
        // panelClass: 'app-full-bleed-dialog',
        // maxWidth: '80vw',
        // maxHeight: '100vh',
        width: '80%',
        data: {},
      }
    );

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'ok') {
        // window.location.reload();
      } else {
        return;
      }
    });
  }

  // Button Disabled Function
  get isSaveButtonDisabled() {
    return !this.myForm.valid || this.is_submit_btn_disable;
  }

  // additional data
  get dynamicForms() {
    return this.myForm.get('dynamicForm') as FormArray;
  }

  createDefaultDynamicItem() {
    return this.fb.group({
      headerKey: ['Company Name', Validators.required],
      headerType: ['text', Validators.required],
      headerValue: [],
      isMandatory: [true],
    });
  }

  addDynamicControl() {
    const header = this.fb.group({
      headerKey: ['', Validators.required],
      headerType: ['text', Validators.required],
      headerValue: [],
      isMandatory: [true],
    });
    this.dynamicForms.push(header);
  }

  deleteDynamicControl(i: any) {
    if (i != 0) {
      this.dynamicForms.removeAt(i);
    }
  }

  changeValue(pos: any, event: any) {
    this.myForm.value.dynamicForm[pos].isMandatory = event.checked
      ? true
      : false;
  }
}
