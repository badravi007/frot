import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  GETsterDialogData,
  GETsterCategoryData,
} from 'src/app/models/getster.interface';
import { CustomIdGeneratorService } from 'src/app/shared/services/custom-id-generator/custom-id-generator.service';

@Component({
  selector: 'app-edit-getster-category',

  template: `
    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons edit-btn"
      (click)="openDialog()"
    >
      <mat-icon> edit </mat-icon>
    </button>
  `,
  styles: [
    `
      .edit-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 90%; */
        /* font-size: 18px; */
      }
      /* */
    `,
  ],
})
export class EditGetsterCategoryComponent implements OnInit {
  @Input() isTop: boolean;
  @Input() currentNode: GETsterCategoryData;
  @Input() isDisabled: boolean;
  @Output() edittedNode = new EventEmitter();

  constructor(public dialog: MatDialog) {}

  ngOnInit() {}

  openDialog(): void {
    const dialogRef = this.dialog.open(GETsterEditDialogRadioButtonComponent, {
      disableClose: true,
      width: '400px',
      minHeight: 'calc(100vh - 700px)',
      data: {
        getster_category_name: this.currentNode.getster_category_name,
        Component: 'Edit',
        parent: this.currentNode,
        isTop: this.isTop,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const node: GETsterCategoryData = {
          getster_category_id: this.currentNode.getster_category_id,
          parent_getster_category_id:
            this.currentNode.parent_getster_category_id,
          getster_category_name: result.getster_category_name,
          is_the_getster_category_hidden:
            this.currentNode.is_the_getster_category_hidden,
          children: this.currentNode.children,
          getster_category_type: '0',
        };
        this.edittedNode.emit({ currentNode: this.currentNode, node: node });
      }
    });
  }
}

@Component({
  selector: 'getster-edit-node-checkbox',
  templateUrl:
    '../getster-category-dialog/getster-category-dialog.component.html',
})
export class GETsterEditDialogRadioButtonComponent {
  constructor(
    public dialogRef: MatDialogRef<GETsterEditDialogRadioButtonComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GETsterDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
