import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import { GETsterCategoryData } from 'src/app/models/getster.interface';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';
import { DataSharingService } from 'src/app/shared/services/data-sharing/data-sharing.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { UserReassignDialogComponent } from './user-reassign-dialog/user-reassign-dialog.component';

@Component({
  selector: 'app-categorization-of-getster',
  templateUrl: './categorization-of-getster.component.html',
  styleUrls: ['./categorization-of-getster.component.scss'],
})
export class CategorizationOfGetsterComponent implements OnInit {
  @ViewChild('tree') tree: ElementRef;

  @Input() selected_getster_app_category_id: string;

  hiddenCategories: boolean = false;

  users_list: any[] = [];
  selected_users_list_val: any = null;
  selected_category_name_val: any = null;

  constructor(
    private _apiService: GetsterService,
    private _headerTitle: HeaderTitleService,
    public dialog: MatDialog,
    public snackBarService: SnackBarService,
    public dataSharingService: DataSharingService,
    private fb: FormBuilder
  ) {}

  nestedTreeControl: NestedTreeControl<GETsterCategoryData>;
  nestedDataSource: MatTreeNestedDataSource<GETsterCategoryData>;
  treeNodeSelection = new SelectionModel<GETsterCategoryData>(
    true /* multiple */
  );

  ngOnInit() {
    this.nestedTreeControl = new NestedTreeControl<GETsterCategoryData>(
      this._getChildren
    );
    this.nestedDataSource = new MatTreeNestedDataSource();
    this.getAllGetsterCategory();
  }

  getAllGetsterCategory() {
    this._apiService.getAllGetsterCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;
    });
  }

  //
  private _getChildren = (node: GETsterCategoryData) => of(node.children);

  hasNestedChild = (_: string, nodeData: GETsterCategoryData) =>
    nodeData.children.length > 0;

  refreshTreeData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  currentNodeVal: any;

  currentNodes(val: any) {
    console.log(val);

    this.currentNodeVal = val;
  }

  addNode(node: GETsterCategoryData) {
    let api_data: GETsterCategoryData = {
      getster_category_id: node.getster_category_id,
      parent_getster_category_id: node.parent_getster_category_id,
      getster_category_name: node.getster_category_name,
      is_the_getster_category_hidden: '0',
      getster_category_type: node.getster_category_type,
      children: node.children,
    };
    this._apiService.addGetsterCategory(api_data).subscribe((res) => {
      if (res['statusCode'] === 200) {
        let data: GETsterCategoryData = {
          getster_category_id: node.getster_category_id,
          parent_getster_category_id: node.parent_getster_category_id,
          getster_category_name: node.getster_category_name,
          is_the_getster_category_hidden: 0,
          getster_category_type: node.getster_category_type,
          children: node.children,
        };
        this.nestedDataSource.data.push(data);
        this.refreshTreeData();
      }
    });
  }

  @Output() addedChildCategory = new EventEmitter();

  addChildNode(childrenNodeData: {
    currentNode: { children: any[] };
    node: any;
  }) {
    this._apiService
      .checkGetsterIsAssignedGetsterCategory(
        childrenNodeData.currentNode['getster_category_id']
      )
      .subscribe((res) => {
        const userIsAssigned = res.userIsAssigned;

        if (userIsAssigned) {
          if (
            confirm(
              'As there are registered users in this category, these users will be transferred to the new sub-category: ' +
                childrenNodeData.node.category_name +
                ' if you press the accept button. If you do not wish that to happen, reassign them to another category before adding a new subcategory' +
                ' \n Do you wish to proceed ? '
            ) === true
          ) {
            this._apiService
              .addGetsterCategory(childrenNodeData.node)
              .subscribe((res) => {
                if (res['statusCode'] === 200) {
                  let parent_data = childrenNodeData.currentNode;
                  let child_data = childrenNodeData.node;

                  this._apiService
                    .reassignGetsterCategoryIdToAnother(
                      parent_data['getster_category_id'],
                      child_data['getster_category_id']
                    )
                    .subscribe((res) => {
                      if (res['statusCode'] == 200) {
                        // res.OK call the refresh tree method
                        // childrenNodeData.currentNode.children.push(
                        //   childrenNodeData.node
                        // );
                        // this.refreshTreeData();

                        this.getAllGetsterCategory();
                        this.addedChildCategory.emit();
                      }
                    });
                }
              });
          }
        } else {
          this._apiService
            .addGetsterCategory(childrenNodeData.node)
            .subscribe((res) => {
              if (res['statusCode'] === 200) {
                childrenNodeData.currentNode.children.push(
                  childrenNodeData.node
                );
                this.refreshTreeData();
              }
            });
        }
      });
  }

  editNode(nodeToBeEdited: {
    node: GETsterCategoryData;
    currentNode: { getster_category_id: string };
  }) {
    this._apiService
      .updateGetsterCategory(nodeToBeEdited.node)
      .subscribe((res) => {
        if (res['status'] == 200) {
          const fatherElement: GETsterCategoryData | any = this.findFatherNode(
            nodeToBeEdited.currentNode.getster_category_id,
            this.nestedDataSource.data
          );
          let elementPosition: number;
          if (fatherElement[0]) {
            fatherElement[0].children[fatherElement[1]] = nodeToBeEdited.node;
          } else {
            elementPosition = this.findPosition(
              nodeToBeEdited.currentNode.getster_category_id,
              this.nestedDataSource.data
            );
            this.nestedDataSource.data[elementPosition] = nodeToBeEdited.node;
          }

          this.refreshTreeData();
        }
      });
  }

  deleteNode(nodeToBeDeleted: GETsterCategoryData) {
    const deletedElement: GETsterCategoryData | any = this.findFatherNode(
      nodeToBeDeleted.getster_category_id,
      this.nestedDataSource.data
    );

    if (nodeToBeDeleted.is_the_getster_category_hidden == 1) {
      let confirm_text_1 =
        'Are you sure you want to Unhide \nParent Category: ' +
        nodeToBeDeleted.getster_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Unhide \nSub Category: ' +
        nodeToBeDeleted.getster_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_getster_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          parent_getster_category_id:
            nodeToBeDeleted.parent_getster_category_id,
          getster_category_name: nodeToBeDeleted.getster_category_name,
          is_the_getster_category_hidden: '0',
          children: nodeToBeDeleted.children,
          getster_category_type: '0',
        };

        let data: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          parent_getster_category_id:
            nodeToBeDeleted.parent_getster_category_id,
          getster_category_name: nodeToBeDeleted.getster_category_name,
          is_the_getster_category_hidden: 0,
          children: nodeToBeDeleted.children,
          getster_category_type: '0',
        };

        this._apiService.hideGETsterCategory(apidata).subscribe((res) => {
          if (res['status'] === 200) {
            const fatherElement: GETsterCategoryData | any =
              this.findFatherNode(
                nodeToBeDeleted.getster_category_id,
                this.nestedDataSource.data
              );
            let elementPosition: number;
            if (fatherElement[0]) {
              fatherElement[0].children[fatherElement[1]] = data;
            } else {
              elementPosition = this.findPosition(
                nodeToBeDeleted.getster_category_id,
                this.nestedDataSource.data
              );
              this.nestedDataSource.data[elementPosition] = data;
            }
            this.refreshTreeData();
          }
        });
      }
    } else if (nodeToBeDeleted.is_the_getster_category_hidden == 0) {
      let confirm_text_1 =
        'Are you sure you want to Hide \nParent Category: ' +
        nodeToBeDeleted.getster_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Hide \nSub Category: ' +
        nodeToBeDeleted.getster_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_getster_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          is_the_getster_category_hidden: true,
        };

        let data: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          parent_getster_category_id:
            nodeToBeDeleted.parent_getster_category_id,
          getster_category_name: nodeToBeDeleted.getster_category_name,
          is_the_getster_category_hidden: 1,
          children: nodeToBeDeleted.children,
          getster_category_type: '0',
        };

        this._apiService
          .checkGetsterIsAssignedGetsterCategory(
            nodeToBeDeleted['getster_category_id']
          )
          .subscribe((res) => {
            const userIsAssigned = res.userIsAssigned;

            if (userIsAssigned) {
              alert(
                'Users are present in this category! \n To hide kindly reassign the user to another category'
              );

              this.openUserReassignDialog(nodeToBeDeleted);
            } else {
              this._apiService.hideGETsterCategory(apidata).subscribe((res) => {
                if (res['status'] === 200) {
                  const fatherElement: GETsterCategoryData | any =
                    this.findFatherNode(
                      nodeToBeDeleted.getster_category_id,
                      this.nestedDataSource.data
                    );
                  let elementPosition: number;
                  if (fatherElement[0]) {
                    fatherElement[0].children[fatherElement[1]] = data;
                  } else {
                    elementPosition = this.findPosition(
                      nodeToBeDeleted.getster_category_id,
                      this.nestedDataSource.data
                    );
                    this.nestedDataSource.data[elementPosition] = data;
                  }
                  this.refreshTreeData();
                }
              });
            }
          });

        // if (condition) {

        // }
      }
    }
    this.refreshTreeData();
  }

  @Output() reAssignedGetsterCategoryID = new EventEmitter();

  openUserReassignDialog(nodeToBeDeleted: GETsterCategoryData) {
    const dialogRef = this.dialog.open(UserReassignDialogComponent, {
      disableClose: true,
      width: '400px',
      minHeight: 'calc(100vh - 700px)',
      data: {
        nodeToBeDeleted: nodeToBeDeleted,
        tree_data: this.nestedDataSource.data,
      },
    });

    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        let apidata: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          is_the_getster_category_hidden: true,
        };
        let data: GETsterCategoryData = {
          getster_category_id: nodeToBeDeleted.getster_category_id,
          parent_getster_category_id:
            nodeToBeDeleted.parent_getster_category_id,
          getster_category_name: nodeToBeDeleted.getster_category_name,
          is_the_getster_category_hidden: 1,
          children: nodeToBeDeleted.children,
          getster_category_type: '0',
        };

        this._apiService.hideGETsterCategory(apidata).subscribe((res) => {
          if (res['status'] === 200) {
            const fatherElement: GETsterCategoryData | any =
              this.findFatherNode(
                nodeToBeDeleted.getster_category_id,
                this.nestedDataSource.data
              );
            let elementPosition: number;
            if (fatherElement[0]) {
              fatherElement[0].children[fatherElement[1]] = data;
            } else {
              elementPosition = this.findPosition(
                nodeToBeDeleted.getster_category_id,
                this.nestedDataSource.data
              );
              this.nestedDataSource.data[elementPosition] = data;
            }
            this.refreshTreeData();
          }
        });

        this.getAllGetsterCategory();
        this.reAssignedGetsterCategoryID.emit();
        // this.selected_user_app_category_ids_data = [];
        // this.selected_user_category_wise_app_access_data = [];
        // this.removeFormFields();
        // this.myForm = this.fb.group({
        //   dynamicForm: this.fb.array([this.createDefaultDynamicItem()]),
        // });
      }
    });
  }
  // Tree Functions
  flatJsonArray(
    flattenedAray: Array<GETsterCategoryData>,
    node: GETsterCategoryData[]
  ) {
    const array: Array<GETsterCategoryData> = flattenedAray;
    node.forEach((element) => {
      if (element.children) {
        array.push(element);
        this.flatJsonArray(array, element.children);
      }
    });
    return array;
  }

  findNodeMaxId(node: GETsterCategoryData[]) {
    const flatArray = this.flatJsonArray([], node);
    const flatArrayWithoutChildren: any[] = [];
    flatArray.forEach((element) => {
      flatArrayWithoutChildren.push(element.getster_category_id);
    });
    return Math.max(...flatArrayWithoutChildren);
  }

  findPosition(id: string, data: GETsterCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      if (id === data[i].getster_category_id) {
        return i;
      }
    }
    return null;
  }

  findFatherNode(category_id: string, data: GETsterCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      const currentFather = data[i];
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (category_id === currentFather.children[z]['category_id']) {
          return [currentFather, z];
        }
      }
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (category_id !== currentFather.children[z]['category_id']) {
          const result: any = this.findFatherNode(
            category_id,
            currentFather.children
          );
          if (result !== false) {
            return result;
          }
        }
      }
    }
    return false;
  }

  radiobtnval(node: GETsterCategoryData) {
    console.log(node);
  }

  getLevel = (node: GETsterCategoryData) => node.level;

  isExpandable = (node: GETsterCategoryData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: GETsterCategoryData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_the_getster_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: GETsterCategoryData): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.treeNodeSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: GETsterCategoryData): void {
    this.treeNodeSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.treeNodeSelection.isSelected(node)
      ? this.treeNodeSelection.select(...descendants)
      : this.treeNodeSelection.deselect(...descendants);
    console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.treeNodeSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: GETsterCategoryData): void {
    console.log(node);
    this.treeNodeSelection.toggle(node);
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: GETsterCategoryData): void {
    let parent: GETsterCategoryData | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: GETsterCategoryData): void {
    const nodeSelected = this.treeNodeSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.treeNodeSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.treeNodeSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.treeNodeSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: GETsterCategoryData): GETsterCategoryData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl.dataNodes.indexOf(node) - 1;
    console.log(startIndex);

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  @Output() getSelectedGetsterCategoryID = new EventEmitter();
  onCategorySelection() {
    this.getSelectedGetsterCategoryID.emit(this.selected_category_name_val);
    // console.log(this.selected_category_name_val);
  }
}
