/* tslint:disable:no-unused-variable */
import { ComponentFixture, TestBed, async } from '@angular/core/testing';

import { AuditTrailGetsterCategoryManagementComponent } from './audit-trail-getster-category-management.component';

describe('AuditTrailUserCategoryManagementComponent', () => {
  let component: AuditTrailGetsterCategoryManagementComponent;
  let fixture: ComponentFixture<AuditTrailGetsterCategoryManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AuditTrailGetsterCategoryManagementComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(
      AuditTrailGetsterCategoryManagementComponent
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
