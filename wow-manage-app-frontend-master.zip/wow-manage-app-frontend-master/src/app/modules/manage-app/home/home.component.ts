import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetsterService } from 'src/app/shared/services/app-development-console/getster.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  constructor(
    private setTileService: HeaderTitleService,
    private router: Router,
    private _getsterService: GetsterService
  ) {}

  getHomeScreenApps: any[] = [];
  ngOnInit() {
    this.onGetHomeScreenApps();
  }

  onGetHomeScreenApps() {
    this._getsterService.onGetHomeScreenApps().subscribe((res) => {
      this.getHomeScreenApps = res.data;
    });
  }

  onAppClick(message: string, link: any) {
    // this.setTileService.setTitle(message);
    let body = {
      link: '',
      user_id: '1',
      customer_id: '1a23',
      access_token: localStorage.getItem('access_token'),
      dark: localStorage.getItem('dark'),
    };

    // this.iframeService.getIframeMessages(body);
    this.router.navigate(['/manage-app/' + link]).then(() => {});
  }

  onOpenApp(app_name: string, app_id: any) {
    // this.setTileService.setTitle(message);
    let body = {
      link: '',
      user_id: '1',
      customer_id: '1a23',
      access_token: localStorage.getItem('access_token'),
      dark: localStorage.getItem('dark'),
    };

    // this.iframeService.getIframeMessages(body);

    this.router.navigate(['/manage-app/app/', app_name, app_id]).then(() => {});
  }
}
