import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LoginComponent as LoginComponentDialog } from 'src/app/shared/dialogs/login/login.component';
import { GetsterRegisterService } from 'src/app/shared/services/app-development-console/getster-register.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { ForgetPasswordComponent } from '../forget-password/forget-password.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  errorMsg = '';
  hide: any;
  separateDialCode = true;
  loginForm!: FormGroup;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private _getsterRegisterService: GetsterRegisterService,
    private loader: CustomSpinnerService,
    private snackBar: SnackBarService,
    private formBuilder: FormBuilder,
    private http: HttpClient
  ) {
    // this.getIpAddress();
    this.loginForm = this.formBuilder.group({
      login_mobile_no: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    // this.dataSource.data = ELEMENT_DATA;
  }

  // country_code: any = null;
  // ip_address: any;
  // getIpAddress() {
  //   this.loader.open();
  //   this.loginService.getIpAddress().subscribe((res) => {
  //     this.ip_address = res['ip'];
  //     this.loginService.getGEOLocation(this.ip_address).subscribe((res) => {
  //       console.log(res);
  //       this.country_code = res['country_code2'];
  //       //   this.latitude = res['latitude'];
  //       //   this.longitude = res['longitude'];
  //       //  this.city = res['city'];
  //       //   this.country_code = res['country_code2'];
  //       //   this.isp = res['isp'];
  //       //   this.province = res['state_prov']
  //     });
  //     console.log(res);
  //   });
  //   this.loader.close();
  // }

  getEnteredPhoneNo: number;
  getSelectedCountry: number;
  selectedCountry(event) {
    this.getEnteredPhoneNo = event.phoneNumber;
    this.getSelectedCountry = event.selectedCountry.dialCode;
  }

  onGetsterLogin() {
    this._getsterRegisterService
      .loginWithRegisteredMobileNumber(
        this.getEnteredPhoneNo,
        this.getSelectedCountry
      )
      .subscribe((res) => {
        if (res.statusCode == 200) {
          const dialogRef = this.dialog.open(LoginComponentDialog, {
            width: '330px',
            height: '380px',
            data: { getster_id: res.data.getster_id },
            // position: {
            //   top: '72px',
            //   right: '21px'
            // }
          });

          dialogRef.afterClosed().subscribe((result) => {
            if (result?.token) {
              localStorage.setItem('access_token', result.token);
              this.router.navigate(['/manage-app/home']);

              // this.router.navigate(['/manage-app/home']).then(() => {
              //   localStorage.setItem('customer_id', '11');
              //   localStorage.setItem('country_code', 'in');
              //   localStorage.setItem('time_zone_iana_string', 'Asia/Kolkata');
              //   localStorage.setItem('getster_id', '1');
              //   window.location.reload();
              // });
            } else {
              return;
            }
          });
        }
      });

    //
    // let username = this.loginForm.value.login_mobile_no;
    // let password = this.loginForm.value.password;
    // if (username != null && password != '') {
    //   this.loader.open();
    //   let loginBody = {
    //     login_mobile_no: username,
    //     getster_password: password,
    //   };
    //   this.loginService.GETsterLogin(loginBody).subscribe(
    //     (res) => {
    //       this.loader.close();
    //       this.snackBar.open(res.message, 'OK', { duration: 4000 });
    //       localStorage.setItem(
    //         'getster_profile',
    //         res.data.face_recognition_file
    //       );
    //       localStorage.setItem(
    //         'getster_approval_status',
    //         res.data.getster_approval_status
    //       );
    //       localStorage.setItem('access_token', res.data.access_token);
    //       localStorage.setItem('customer_id', '1a23');
    //       localStorage.setItem('getster_id', res.data.getster_id);
    //       localStorage.setItem('country_code', 'in');
    //       this.router.navigate(['/manage-app/home']).then(() => {
    //         window.location.reload();
    //       });
    //     },
    //     (err) => {
    //       this.loader.close();
    //       this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
    //     }
    //   );
    // }
  }

  forgetPasswordDialog(): void {
    const dialogRef = this.dialog.open(ForgetPasswordComponent, {
      width: '666px',
      height: '353px',
      // data: { useCase: useCase },
      // position: {
      //   top: '72px',
      //   right: '21px'
      // }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'close') {
        // window.location.reload();
        // this.router.navigate(['/market-place/my-bag']);
      } else {
        return;
      }
    });
  }

  // @ViewChild(MatTable, { static: true }) table!: MatTable<any>;
  // selection = new SelectionModel<any>(false, []);

  // displayedColumns: string[] = ['selection', 'country_code', 'country_name'];
  // dataSource = new MatTableDataSource<any>();

  // selectRow($event: any, row: any) {
  //   console.log(row);
  // }
}

const ELEMENT_DATA: any[] = [
  {
    country_code: 'in',
    country_name: 'India',
  },
  {
    country_code: 'chn',
    country_name: 'China',
  },
];
