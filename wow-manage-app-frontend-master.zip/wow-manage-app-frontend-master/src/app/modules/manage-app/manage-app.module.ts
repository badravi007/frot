import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CKEditorModule } from 'ng2-ckeditor';
import { WebcamModule } from 'ngx-webcam';
import { SharedModule } from 'src/app/shared/shared.module';
import { GetsterAppReassignDialogComponent } from './app-development-console/apps-for-getsters/app-development-console-for-getster-apps/categorization-of-getster-app/getster-app-reassign-dialog/getster-app-reassign-dialog.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { AppCategoryAppSelectionComponent } from './getster-category-management/app-category-selection/app-category-selection.component';
import { AuditTrailGetsterCategoryManagementComponent } from './getster-category-management/audit-trail-getster-category-management/audit-trail-getster-category-management.component';
import {
  AddGetsterCategoryComponent,
  GETsterNewNodeDialogRadioButton,
} from './getster-category-management/categorization-of-getster/add-getster-category/add-getster-category.component';
import { CategorizationOfGetsterComponent } from './getster-category-management/categorization-of-getster/categorization-of-getster.component';
import { DeleteGetsterCategoryComponent } from './getster-category-management/categorization-of-getster/delete-getster-category/delete-getster-category.component';
import {
  EditGetsterCategoryComponent,
  GETsterEditDialogRadioButtonComponent,
} from './getster-category-management/categorization-of-getster/edit-getster-category/edit-getster-category.component';
import { UserReassignDialogComponent } from './getster-category-management/categorization-of-getster/user-reassign-dialog/user-reassign-dialog.component';
import { GetsterCategoryManagementComponent } from './getster-category-management/getster-category-management.component';
import { AppCategorySelectionComponent } from './getster-registration/app-category-selection/app-category-selection.component';
import { GetsterRegistrationStep1Component } from './getster-registration/getster-registration-step1/getster-registration-step1.component';
import { GetsterRegistrationStep2Component } from './getster-registration/getster-registration-step2/getster-registration-step2.component';
import { GetsterRegistrationStep3Component } from './getster-registration/getster-registration-step3/getster-registration-step3.component';
import { HomeComponent } from './home/home.component';
import { IframeAppLoaderComponent } from './iframe-app-loader/iframe-app-loader.component';
import { IframeComponent } from './iframe/iframe.component';
import { LoginComponent } from './login/login.component';
import { ManageAppRoutingModule } from './manage-app.routing';
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
  imports: [
    CommonModule,
    ManageAppRoutingModule,
    SharedModule,
    WebcamModule,
    CKEditorModule,
  ],
  // AgmCoreModule.forRoot({
  //   apiKey: 'AIzaSyA371p4svrnumOUHManPExnjs8s-jCrhA0',
  // }),],
  declarations: [
    NotFoundComponent,
    LoginComponent,
    GetsterRegistrationStep1Component,
    GetsterRegistrationStep2Component,
    GetsterRegistrationStep3Component,
    ForgetPasswordComponent,
    HomeComponent,
    GetsterCategoryManagementComponent,
    AddGetsterCategoryComponent,
    EditGetsterCategoryComponent,
    DeleteGetsterCategoryComponent,
    GETsterEditDialogRadioButtonComponent,
    GETsterNewNodeDialogRadioButton,
    GetsterAppReassignDialogComponent,
    CategorizationOfGetsterComponent,

    //
    AppCategoryAppSelectionComponent,
    UserReassignDialogComponent,
    AuditTrailGetsterCategoryManagementComponent,

    // Register
    AppCategorySelectionComponent,

    // Iframe
    IframeAppLoaderComponent,
    IframeComponent,
  ],
})
export class ManageAppModule {}
