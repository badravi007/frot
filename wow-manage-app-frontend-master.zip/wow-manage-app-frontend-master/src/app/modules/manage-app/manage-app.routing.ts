import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { UnsavedChangesGuard } from 'src/app/shared/guards/unsaved-changes/unsaved-changes.guard';
import { GetsterCategoryManagementComponent } from './getster-category-management/getster-category-management.component';
import { GetsterRegistrationStep1Component } from './getster-registration/getster-registration-step1/getster-registration-step1.component';
import { GetsterRegistrationStep2Component } from './getster-registration/getster-registration-step2/getster-registration-step2.component';
import { GetsterRegistrationStep3Component } from './getster-registration/getster-registration-step3/getster-registration-step3.component';
import { HomeComponent } from './home/home.component';
import { IframeAppLoaderComponent } from './iframe-app-loader/iframe-app-loader.component';
import { LoginComponent } from './login/login.component';

let routes: Routes = [
  { path: 'app/:app_name/:app_id', component: IframeAppLoaderComponent },
  { path: 'login', component: LoginComponent },

  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard],
  },

  {
    path: 'registration1',
    component: GetsterRegistrationStep1Component,
    canDeactivate: [UnsavedChangesGuard],
  },
  {
    path: 'registration2',
    component: GetsterRegistrationStep2Component,
    canDeactivate: [UnsavedChangesGuard],
  },
  {
    path: 'registration3',
    component: GetsterRegistrationStep3Component,
    canDeactivate: [UnsavedChangesGuard],
  },

  {
    path: 'getster-category-management',
    component: GetsterCategoryManagementComponent,
    canDeactivate: [UnsavedChangesGuard],
  },
  // {
  //   path: 'getster-category-management',
  //   component: UserCategoryAppManagementComponent,
  // },
  {
    path: 'app-development-console',
    loadChildren: () =>
      import('./app-development-console/app-development-console.module').then(
        (m) => m.AppDevelopmentConsoleModule
      ),
  },
  { path: '**', redirectTo: '/404' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManageAppRoutingModule {}
