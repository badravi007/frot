import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-iframe-app-loader',
  templateUrl: './iframe-app-loader.component.html',
  styleUrls: ['./iframe-app-loader.component.scss'],
})
export class IframeAppLoaderComponent implements OnInit {
  constructor(private _router: ActivatedRoute) {}

  iframeSource: string;
  ngOnInit(): void {
    this._router.params.subscribe((res) => {
      let appId = res['app_id'];
      this.iframeSource = `https://${appId}.getbiz.app/`;
      // this.iframeSource = `http://localhost:4300`;
    });
  }
}
