import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IframeAppLoaderComponent } from './iframe-app-loader.component';

describe('IframeAppLoaderComponent', () => {
  let component: IframeAppLoaderComponent;
  let fixture: ComponentFixture<IframeAppLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IframeAppLoaderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IframeAppLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
