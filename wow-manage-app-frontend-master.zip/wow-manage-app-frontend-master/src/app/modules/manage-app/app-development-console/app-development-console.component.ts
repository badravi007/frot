import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSidenav } from '@angular/material/sidenav';
import { Subscription } from 'rxjs';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';

@Component({
  selector: 'app-app-development-console',
  templateUrl: './app-development-console.component.html',
  styleUrls: ['./app-development-console.component.scss'],
})
export class AppDevelopmentConsoleComponent implements OnInit {
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  headerTitle$: Subscription;

  @ViewChild('sidenav')
  sidenav!: MatSidenav;

  menuName: any = 'APP CONFIGURATION';

  constructor(
    private _cdRef: ChangeDetectorRef,
    private _headerTitle: HeaderTitleService,
    media: MediaMatcher,
    public dialog: MatDialog
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 1000px)');
    this._mobileQueryListener = () => _cdRef.detectChanges();
    this.mobileQuery.addEventListener('change', this._mobileQueryListener);
  }

  ngOnInit(): void {
    this.sidenav;
  }

  ngAfterViewInit() {
    // this._headerTitle.setTitle(this.menuName);
    this.headerTitle$ = this._headerTitle.title.subscribe((title) => {
      this.menuName = title;
    });
    this._cdRef.detectChanges();

    // this._headerTitle.setTitle('hello');
  }

  sideOnclickClose() {
    if (this.sidenav.mode == 'side') {
      this.sidenav.open();
    } else {
      this.sidenav.close();
    }
  }

  menu = [
    {
      label: 'Country Wise Educational Institution Categories',
      link: '/manage-app/app-development-console/county-wise-educational-institution',
    },
    {
      label: 'PWA Apps for Users',
      link: '/manage-app/app-development-console/apps-for-all-users',
    },
    {
      label: 'Apps for GETSTERs',
      link: '/manage-app/app-development-console/apps-for-getster',
    },
    {
      label: 'Custom Apps',
      link: '/manage-app/app-development-console/custom-apps',
    },
    {
      label: 'Console Users',
      link: '/manage-app/app-development-console/console-user',
    },
    {
      label: 'Common Data for User Apps',
      link: '/manage-app/app-development-console/common-data-for-user-apps',
    },
  ];

  getName(data: any) {
    this.menuName = data;
    this._cdRef.detectChanges();

    // this._headerTitle.setAppConfigTitle(data);
  }

  ngOnDestroy(): void {
    if (this.headerTitle$) {
      this.headerTitle$.unsubscribe();
    }
    this.mobileQuery.removeEventListener('change', this._mobileQueryListener);
  }

  openAuditTrail(): void {
    // this.dialog.closeAll();
    // const dialogRef = this.dialog.open(AuditTrailAppConfigurationComponent, {
    //   panelClass: 'app-full-bleed-dialog',
    //   maxWidth: '80vw',
    //   maxHeight: '100vh',
    //   width: '80%',
    //   data: {},
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result === 'ok') {
    //     // window.location.reload();
    //   } else {
    //     return;
    //   }
    // });
  }
}
