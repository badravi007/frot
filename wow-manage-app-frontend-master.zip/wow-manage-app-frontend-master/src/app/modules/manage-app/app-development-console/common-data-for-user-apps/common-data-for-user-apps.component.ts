import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-data-for-user-apps',
  templateUrl: './common-data-for-user-apps.component.html',
  styleUrls: ['./common-data-for-user-apps.component.scss'],
})
export class CommonDataForUserAppsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
