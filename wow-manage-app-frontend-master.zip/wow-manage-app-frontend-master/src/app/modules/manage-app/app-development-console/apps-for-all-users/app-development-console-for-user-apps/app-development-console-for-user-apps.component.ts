import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { StepperOrientation } from '@angular/cdk/stepper';
import {
  ChangeDetectorRef,
  Component,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute } from '@angular/router';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { GlobalConstants } from 'src/app/shared/util/global-constants';

@Component({
  selector: 'app-app-development-console-for-user-apps',
  templateUrl: './app-development-console-for-user-apps.component.html',
  styleUrls: ['./app-development-console-for-user-apps.component.scss'],
})
export class AppDevelopmentConsoleForUserAppsComponent implements OnInit {
  isLinear = false;

  appFormGroup!: UntypedFormGroup;
  user_app_id: any = 1;
  user_app_name: any;
  user_app_type: any;

  selected_user_app_category_id: string = null;

  constructor(
    private _formBuilder: UntypedFormBuilder,
    private cdr: ChangeDetectorRef,
    private snackBar: SnackBarService,
    private _UserAppService: UserAppService,
    private loader: CustomSpinnerService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private _headerTitle: HeaderTitleService
  ) {
    this.appFormGroup = this._formBuilder.group({
      user_app_full_name: ['', Validators.required],
      user_app_icon_name: ['', Validators.required],
    });
    this.getScreenSize();

    this.user_app_id = this.route.snapshot.params['id'];
    // this.user_app_name = this.route.snapshot.params['name'];
    this.user_app_type = this.route.snapshot.params['type'];

    // console.log(this.user_app_type);

    if (this.user_app_type == 'edit') {
      this.getUserAppByID();
      this.getUserAppLaunchScreenDisplay();
    }
  }

  ngOnInit() {
    // this._headerTitle.setTitle('PWA Apps for Users');
  }

  scrHeight: any;
  scrWidth: any;
  orientation: StepperOrientation = 'vertical';
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?: any) {
    this.scrHeight = window.innerHeight;
    this.scrWidth = window.innerWidth;
    if (this.scrWidth <= '768') {
      this.orientation = 'vertical';
    } else {
      this.orientation = 'horizontal';
    }
  }

  fileToUpload: any;
  imageUrl: any = null;
  handleFileInput(event) {
    this.fileToUpload = event.target.files.item(0);
    //Show image preview
    let reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
      this.cdr.markForCheck();
    };
    reader.readAsDataURL(this.fileToUpload);
  }

  error_message: string = '';
  isValid() {
    if (!this.appFormGroup.valid) {
      return true;
    } else if (this.imageUrl == null) {
      this.error_message = 'App Icon Required.';
      return true;
    } else {
      this.error_message = '';
      return false;
    }
  }

  //Api Stepper 1
  getsterappImage;
  getsterAppList: any;
  getster_app_development_status: any = 0;
  userAppCategoryIds: string;
  getUserAppByID() {
    // this.loader.open();
    this._UserAppService.getUserAppByID(this.user_app_id).subscribe(
      (res) => {
        this.getsterAppList = res;

        this.appFormGroup.setValue({
          user_app_full_name: this.getsterAppList.data[0].user_app_full_name,
          user_app_icon_name: this.getsterAppList.data[0].user_app_icon_name,
        });

        this.userAppCategoryIds =
          this.getsterAppList.data[0].user_app_category_ids;

        this.getster_app_development_status =
          this.getsterAppList.data[0].user_app_development_status;

        this.getsterappImage = this.getsterAppList.data[0].user_app_icon_image;

        this.user_app_name = this.getsterAppList.data[0].user_app_icon_name;

        this.getFileUserAppMaster(
          this.getsterAppList.data[0].user_app_icon_image_path
        );

        this.snackBar.success(res.message);
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  constants: any = GlobalConstants;
  previewAppsList: any;
  categoryIdList: any[] = [];

  getAppsForPreviewLocation(ids) {
    if (this.categoryIdList.length == 0) this.categoryIdList.push(ids);
    else {
      let removeIndexValue = this.categoryIdList.indexOf(ids);
      if (removeIndexValue == -1) this.categoryIdList.push(ids);
      else this.categoryIdList.splice(removeIndexValue, 1);
    }
    this._UserAppService
      .userAppCategoryId(this.categoryIdList.toString())
      .subscribe(
        (res) => {
          this.previewAppsList = res.data;
          this.snackBar.success(res.message);
          this.loader.close();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  drop(event: CdkDragDrop<string[]>, data) {
    moveItemInArray(data, event.previousIndex, event.currentIndex);
    for (let i = 0; i < data.length; i++) {
      if (i == event.currentIndex) {
        console.log('data' + JSON.stringify(data[i]));
        // this.updatePreviewLocation(data[i], event.currentIndex);
      } else {
        console.log('data:');
      }
    }
  }

  categorySelection() {
    this.myStepper.next();
  }

  addEditGetsterApp() {
    if (this.user_app_type == 'add') {
      this.insertGETsterApp();
    } else if (this.user_app_type == 'edit') {
      this.updateGETsterApp();
    }
  }

  getFileUserAppMaster(file_name) {
    this.loader.open();
    this._UserAppService.getFileUserAppMaster(file_name).subscribe(
      async (res) => {
        this.imageUrl = await this.arrayBufferToBase64(res);
      },
      (err) => {
        this.snackBar.error(err.error);
      }
    );
  }

  insertGETsterApp() {
    let formData: FormData = new FormData();

    formData.append('user_app_id', '0');

    formData.append(
      'user_app_icon_name',
      this.appFormGroup.value.user_app_icon_name
    );
    formData.append(
      'user_app_full_name',
      this.appFormGroup.value.user_app_full_name
    );

    formData.append('getster_id', localStorage.getItem('getster_id'));

    formData.append(
      'user_app_activity_utc_date_time',
      localStorage.getItem('time_zone_iana_string')
    );

    formData.append(
      'user_app_development_status',
      this.getster_app_development_status
    );

    formData.append('image', this.fileToUpload);

    // formData.append(
    //   'time_zone_iana_string',
    //   localStorage.getItem('time_zone_iana_string')
    // );

    this.loader.open();
    this._UserAppService.addUserApp(formData).subscribe(
      (res) => {
        this.loader.close();
        if (res.data != null) {
          // console.log(res);
          this.user_app_id = res.data.user_app_id;
          this.user_app_name = res.data.user_app_icon_name;
          this.createCommentsCommunication(this.user_app_id);
          this.getUserAppByID();
          this.myStepper.next();
        } else {
          this.snackBar.success(res.message);
        }
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  createCommentsCommunication(user_app_id: number) {
    this._UserAppService
      .createCommentsCommunicationTable(user_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
        },
        (err) => {
          this.loader.close();
          this.snackBar.success(err.error);
        }
      );
  }

  updateGETsterApp() {
    let user_app_icon_name = this.appFormGroup.value.user_app_icon_name;
    let user_app_full_name = this.appFormGroup.value.user_app_full_name;
    let user_app_title_bar_name = this.appFormGroup.value.user_app_full_name;

    let formData: FormData = new FormData();
    formData.append('user_app_id', this.user_app_id);
    formData.append('user_app_icon_name', user_app_icon_name);
    formData.append('user_app_full_name', user_app_full_name);
    formData.append(
      'user_app_development_status',
      this.getster_app_development_status
    );
    formData.append('getster_id', localStorage.getItem('getster_id'));

    formData.append('image', this.fileToUpload);

    formData.append(
      'time_zone_iana_string',
      localStorage.getItem('time_zone_iana_string')
    );

    this.loader.open();
    this._UserAppService.updateUserApp(formData).subscribe(
      (res) => {
        this.getUserAppByID();

        this.snackBar.success(res.message);
        this.loader.close();
        this.myStepper.next();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  getSelectedGetsterCategoryID(event) {
    this.selected_user_app_category_id = event;

    this.getAppsForPreviewLocation(event);
  }
  getAssignCategory() {
    // console.log('call', this.categoryIdList);

    this.getAppsForPreviewLocation(this.categoryIdList);
  }
  // assignCategory() {
  //   if (this.selected_user_app_category_id != null) {
  //     let body = {
  //       getster_app_category_id: this.selected_user_app_category_id,
  //       getster_app_id: this.user_app_id,
  //       getster_app_location_within_the_category_id: 0,
  //     };
  //     this._UserAppService.AssignGetsterCategoryToGetsterApp(body).subscribe(
  //       (res) => {
  //         this.loader.close();
  //         // this.getAppCategoriesByID();
  //         this.snackBar.success(res.message);
  //         this.myStepper.next();
  //       },
  //       (err) => {
  //         this.loader.close();
  //         this.snackBar.error(err.error);
  //       }
  //     );
  //   }
  // }

  timeStampDetails: any;
  getTimeStampDetails(event) {
    this.timeStampDetails = event;
    // console.log(event);
  }

  addUserAppAboutDemoVideoDescription() {
    // this.loader.open();
    let finalData = { data: this.timeStampDetails };

    // let body = {
    //   user_app_id: this.user_app_id,
    //   user_app_demo_video_path:
    //     'https://www.youtube.com/watch?v=2OHbjep_WjQ&ab_channel=freeCodeCamp.org',
    //   user_app_attachments_path: 'user_app_attachments_path',
    //   user_app_time_stamp_description: JSON.stringify(finalData),
    // };

    let body = {
      user_app_id: this.user_app_id,
      user_app_demo_video_thumb_nail_path:
        'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg',
      user_app_demo_video_path:
        'http://media.w3.org/2010/05/sintel/trailer.mp4',
      user_app_datetime_description: JSON.stringify(finalData),
      user_app_attachments_path: [],
    };

    this._UserAppService.addUpdateUserAppAboutDemoVideo(body).subscribe(
      (res) => {
        this.snackBar.success(res.message);
        this.loader.close();
        this.myStepper.next();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  updateUserAppAboutDemoVideo() {
    let finalData = { data: this.timeStampDetails };
    // let body = {
    //   user_app_id: this.user_app_id,
    //   user_app_demo_video_path:
    //     'https://www.youtube.com/watch?v=2OHbjep_WjQ&ab_channel=freeCodeCamp.org',
    //   user_app_date_time_title: 'string',
    //   user_app_datetime_description: JSON.stringify(finalData),
    //   user_app_attachments_path: 'string',
    // };

    let body = {
      user_app_id: this.user_app_id,
      user_app_demo_video_thumb_nail_path:
        'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg',
      user_app_demo_video_path:
        'http://media.w3.org/2010/05/sintel/trailer.mp4',
      user_app_datetime_description: JSON.stringify(finalData),
      user_app_attachments_path: [],
    };

    this._UserAppService.updateUserAppAboutDemoVideo(body).subscribe(
      (res) => {
        this.snackBar.success(res.message);
        this.loader.close();
        this.myStepper.next();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  activeStepper = true;
  @ViewChild('stepper') private myStepper: MatStepper;

  // *--------------------------------------------------------------
  getText1: string;
  getText2: string;
  getText3: string;

  onNextHandle() {
    if (this.user_app_type == 'edit') {
      this.updateUserAppLaunchScreenDisplay();
      // About video
    } else {
      this.addUpdateUserAppLaunchScreenDisplay();
    }
  }

  // About video
  onNextHandleAboutVideo() {
    if (this.user_app_type == 'edit') {
      this.updateUserAppAboutDemoVideo();
    } else {
      this.addUserAppAboutDemoVideoDescription();
    }
  }

  addUpdateUserAppLaunchScreenDisplay() {
    if (this.isDisplayedInLaunchScreen) {
      const formData = new FormData();
      formData.append('user_app_id', this.user_app_id);
      formData.append(
        'user_app_launch_screen_mobile_image_file_name',
        this.mobileCoveImageFormData
      );
      formData.append(
        'user_app_launch_screen_desktop_image_file_name',
        this.desktopCoveImageFormData
      );
      formData.append('user_app_launch_screen_text1', this.getText1);
      formData.append('user_app_launch_screen_text2', this.getText2);
      formData.append('user_app_launch_screen_text3', this.getText3);
      formData.append('user_app_launch_screen_location', '0');
      this._UserAppService
        .addUpdateUserAppLaunchScreenDisplay(formData)
        .subscribe(
          (res) => {
            this.snackBar.success(res.message);
            this.loader.close();
            this.myStepper.next();
          },
          (err) => {
            this.loader.close();
            this.snackBar.error(err.error);
          }
        );
    } else {
      this.myStepper.next();
    }
  }

  updateUserAppLaunchScreenDisplay() {
    if (this.isDisplayedInLaunchScreen) {
      const formData = new FormData();
      formData.append('user_app_id', this.user_app_id);
      formData.append(
        'user_app_launch_screen_mobile_image_file_name',
        this.mobileCoveImageFormData
      );
      formData.append(
        'user_app_launch_screen_desktop_image_file_name',
        this.desktopCoveImageFormData
      );
      formData.append('user_app_launch_screen_text1', this.getText1);
      formData.append('user_app_launch_screen_text2', this.getText2);
      formData.append('user_app_launch_screen_text3', this.getText3);
      formData.append('user_app_launch_screen_location', '0');
      this._UserAppService.updateUserAppLaunchScreenDisplay(formData).subscribe(
        (res) => {
          this.snackBar.success(res.message);
          this.loader.close();
          this.myStepper.next();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error);
        }
      );
    } else {
      this.myStepper.next();
    }
  }

  mobileCoveImageBase64: any;
  mobileCoveImageFormData: any;
  async setMobileCoverBackground(event: any) {
    this.mobileCoveImageBase64 = await this.getBase64(event, 'base64');
    this.mobileCoveImageFormData = await this.getBase64(event, 'formData');
  }

  desktopCoveImageBase64: any;
  desktopCoveImageFormData: any;
  async setDesktopCoverBackground(event: any) {
    this.desktopCoveImageBase64 = await this.getBase64(event, 'base64');
    this.desktopCoveImageFormData = await this.getBase64(event, 'formData');
  }

  isDisplayedInLaunchScreen: boolean = false;
  onChangeIsDisplayedInLaunchScreen(value: boolean) {
    this.isDisplayedInLaunchScreen = value;
  }

  getUserAppLaunchScreenDisplay() {
    this._UserAppService
      .getUserAppLaunchScreenDisplay(this.user_app_id)
      .subscribe((res) => {
        if (res.data) {
          this.snackBar.success(res.message);
          this.getText1 = res.data.user_app_launch_screen_text1;
          this.getText2 = res.data.user_app_launch_screen_text2;
          this.getText3 = res.data.user_app_launch_screen_text3;

          this.getFileUserAppLaunchScreenMobileDisplay(
            res.data.user_app_launch_screen_mobile_image_file_name
          );
          this.getFileUserAppLaunchScreenDesktopDisplay(
            res.data.user_app_launch_screen_desktop_image_file_name
          );
        }
      });
  }

  getFileUserAppLaunchScreenMobileDisplay(file_name) {
    // this.loader.open();
    this._UserAppService.getFileUserAppLaunchScreenDisplay(file_name).subscribe(
      async (res) => {
        this.mobileCoveImageBase64 = await this.arrayBufferToBase64(res);
      },
      (err) => {
        this.snackBar.error(err.error);
      }
    );
  }
  getFileUserAppLaunchScreenDesktopDisplay(file_name) {
    // this.loader.open();
    this._UserAppService.getFileUserAppLaunchScreenDisplay(file_name).subscribe(
      async (res) => {
        this.desktopCoveImageBase64 = await this.arrayBufferToBase64(res);
      },
      (err) => {
        this.snackBar.error(err.error);
      }
    );
  }
  // ------------------------------- Helper Function --------------------
  getBase64(event, type) {
    let getFile = event.target.files.item(0);

    switch (type) {
      case 'base64': {
        return new Promise((resolve, reject) => {
          let reader = new FileReader();
          reader.onload = (event: any) => {
            resolve(event.target.result);
          };
          reader.readAsDataURL(getFile);
        });
      }

      case 'formData':
        return getFile;
    }
    // if (type == 'base64') {
    // } else if (type == 'formData') return getFile;
  }

  arrayBufferToBase64(buffer: ArrayBuffer) {
    var blob = new Blob([buffer], { type: 'blob' });
    var reader = new FileReader();
    let base64 = new Promise((reslove: any, reject: any) => {
      reader.onload = (evt: any) => {
        // let dataurl = evt.target.result;
        reslove(evt.target.result);
      };
    });
    reader.readAsDataURL(blob);
    return base64;
  }
  // !--------------------------- END ------------------------------
}
