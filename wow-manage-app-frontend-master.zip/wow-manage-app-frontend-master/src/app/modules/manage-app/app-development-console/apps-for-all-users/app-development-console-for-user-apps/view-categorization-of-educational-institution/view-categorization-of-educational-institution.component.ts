import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-categorization-of-educational-institution',
  templateUrl:
    './view-categorization-of-educational-institution.component.html',
  styleUrls: [
    './view-categorization-of-educational-institution.component.scss',
  ],
})
export class ViewCategorizationOfEducationalInstitutionComponent
  implements OnInit
{
  constructor() {}

  ngOnInit() {}
}
