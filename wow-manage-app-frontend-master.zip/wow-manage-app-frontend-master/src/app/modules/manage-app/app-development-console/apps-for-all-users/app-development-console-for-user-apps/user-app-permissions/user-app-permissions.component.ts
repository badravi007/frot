import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { GlobalConstants } from 'src/app/shared/util/global-constants';

@Component({
  selector: 'app-user-app-permissions',
  templateUrl: './user-app-permissions.component.html',
  styleUrls: ['./user-app-permissions.component.scss'],
})
export class UserAppPermissionsComponent implements OnInit {
  @Input() user_app_id: number;
  @Output() isDisplayedInLaunchScreen = new EventEmitter();

  cloudFileStorageFormGroup: FormGroup;

  additionalDataFormGroup: FormGroup;
  constants: any = GlobalConstants;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private userAppService: UserAppService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private elRef: ElementRef
  ) {
    this.cloudFileStorageFormGroup = this.fb.group({
      deleteFolder: false,
      deleteFiles: false,
      copyFiles: false,
    });
    this.additionalDataFormGroup = this.fb.group({
      can_this_user_app_be_blocked_by_app_administrator: false,
      can_this_app_be_displayed_in_customerbizapp_launch_screen: false,
      does_this_app_have_configuration_data_specific_to_this_app: false,
      is_the_app_suitable_to_be_displayed_in_launch_screen: false,
    });
  }

  // Cloud File Storage Permissions
  // deleteFolder: false;
  // deleteFiles: false;
  // copyFiles: false;

  ngOnInit() {
    this.getUserAppCloudStoragePermission();
    this.getAdditionalPermission();
    this.getAllUserCustomApps();
  }

  onCloudFileStoragePermissionChange() {
    let body = {
      user_app_id: this.user_app_id,
      delete_folder: this.cloudFileStorageFormGroup.value.deleteFolder,
      delete_files: this.cloudFileStorageFormGroup.value.deleteFiles,
      copy_files: this.cloudFileStorageFormGroup.value.copyFiles,
    };
    this.userAppService.addUpdateUserAppCloudStoragePermission(body).subscribe(
      (res) => {
        this.getUserAppCloudStoragePermission();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  onChangeIsDisplayedInLaunchScreen() {
    this.isDisplayedInLaunchScreen.emit(
      this.additionalDataFormGroup.value
        .is_the_app_suitable_to_be_displayed_in_launch_screen
    );
  }

  onUserAppAdditionalPermissionChange() {
    let body = {
      user_app_id: this.user_app_id,
      can_this_app_be_displayed_in_customerbizapp_launch_screen:
        this.additionalDataFormGroup.value
          .can_this_app_be_displayed_in_customerbizapp_launch_screen,
      can_this_user_app_be_blocked_by_app_administrator:
        this.additionalDataFormGroup.value
          .can_this_user_app_be_blocked_by_app_administrator,
      does_this_app_have_configuration_data_specific_to_this_app:
        this.additionalDataFormGroup.value
          .does_this_app_have_configuration_data_specific_to_this_app,
      is_the_app_suitable_to_be_displayed_in_launch_screen:
        this.additionalDataFormGroup.value
          .is_the_app_suitable_to_be_displayed_in_launch_screen,
    };

    this.userAppService.addUpdateUserAppAdditionalPermission(body).subscribe(
      (res) => {
        this.getAdditionalPermission();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  getUserAppCloudStoragePermission() {
    let cloudStorageFileList = null;
    this.userAppService
      .getUserAppCloudStoragePermission(this.user_app_id)
      .subscribe(
        (res) => {
          this.cloudFileStorageFormGroup.controls['deleteFolder'].setValue(
            res.data?.delete_folder ?? false
          );
          this.cloudFileStorageFormGroup.controls['deleteFiles'].setValue(
            res.data?.delete_files ?? false
          );
          this.cloudFileStorageFormGroup.controls['copyFiles'].setValue(
            res.data?.copy_files ?? false
          );
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.loader.close();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  getAdditionalPermission() {
    let additionalPermissionList = null;
    this.userAppService.getAdditionalPermission(this.user_app_id).subscribe(
      (res) => {
        additionalPermissionList = res;

        this.additionalDataFormGroup.controls[
          'can_this_app_be_displayed_in_customerbizapp_launch_screen'
        ].setValue(
          additionalPermissionList.data
            ?.can_this_app_be_displayed_in_customerbizapp_launch_screen ?? false
        );
        this.additionalDataFormGroup.controls[
          'can_this_user_app_be_blocked_by_app_administrator'
        ].setValue(
          additionalPermissionList.data
            ?.can_this_user_app_be_blocked_by_app_administrator ?? false
        );
        this.additionalDataFormGroup.controls[
          'does_this_app_have_configuration_data_specific_to_this_app'
        ].setValue(
          additionalPermissionList.data
            ?.does_this_app_have_configuration_data_specific_to_this_app ??
            false
        );
        this.additionalDataFormGroup.controls[
          'is_the_app_suitable_to_be_displayed_in_launch_screen'
        ].setValue(
          additionalPermissionList.data
            ?.is_the_app_suitable_to_be_displayed_in_launch_screen ?? false
        );

        this.onChangeIsDisplayedInLaunchScreen();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  getAllUserCustomAppList: any;
  getAllUserCustomApps() {
    // this.loader.open();
    this.userAppService.getAllUserCustomApps().subscribe(
      (res) => {
        this.getAllUserCustomAppList = res.data;
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  drop(event: CdkDragDrop<string[]>, data) {
    moveItemInArray(data, event.previousIndex, event.currentIndex);
    for (let i = 0; i < data.length; i++) {
      if (i == event.currentIndex) {
        console.log('data' + JSON.stringify(data[i]));
        this.updatePreviewLocation(data[i], event.currentIndex);
      } else {
        console.log('data:');
      }
    }
  }

  updatePreviewLocation(data, currentIndex) {
    // let body = {
    //   "id": "id:" + data.path,
    //   "path": data.path,
    //   "getster_app_id": data.getster_app_id,
    //   "getster_app_category_location": currentIndex,
    //   "getster_apps_and_categories_assignment_id": data.getster_apps_and_categories_assignment_id
    // };
    let body = {
      Orderid: currentIndex,
      getster_apps_and_categories_assignment_id:
        data.getster_apps_and_categories_assignment_id,
    };
    // this.userAppService.updatePreviewLocation(body).subscribe(res => {
    //   this.snackBar.open(res.message, 'OK', { duration: 4000 });
    //   this.loader.close();
    //   this.getAppCategoriesByID();
    // }, err => {
    //   this.loader.close();
    //   this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
    // });
  }

  fileToUpload: any;
  imageUrl: any;
  handleFileInput(event) {
    this.fileToUpload = event.target.files.item(0);
    //Show image preview
    let reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(this.fileToUpload);
  }
}
