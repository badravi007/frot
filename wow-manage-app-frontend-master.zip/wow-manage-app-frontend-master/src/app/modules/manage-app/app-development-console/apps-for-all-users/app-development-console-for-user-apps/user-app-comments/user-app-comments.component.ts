import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { UtcTimeService } from 'src/app/shared/util/utc-time.service';

@Component({
  selector: 'app-user-app-comments',
  templateUrl: './user-app-comments.component.html',
  styleUrls: ['./user-app-comments.component.scss'],
})
export class UserAppCommentsComponent implements OnInit {
  commentsFormGroup: FormGroup;
  constructor(
    private userAppService: UserAppService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private elRef: ElementRef,
    public utcTimeService: UtcTimeService
  ) {
    this.commentsFormGroup = this.fb.group({
      app_comments: new FormControl(''),
    });
  }

  @Input() user_app_id: number;

  ngOnInit() {
    this.getComments();
  }

  commentsList: any = [];
  getComments() {
    // this.loader.open();
    this.userAppService.getUserAppComments(this.user_app_id).subscribe(
      (res) => {
        this.loader.close();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.commentsList = res.data;
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  addComments() {
    let message = this.commentsFormGroup.value.app_comments;
    let body = {
      comment_utc_date_time: this.getUTC(),
      user_id: this.user_app_id,
      comment_text: message,
      is_the_comment_private: 0,
      comment_reply: '',
      comment_reply_by_user_id: 0,
    };

    this.loader.open();
    this.userAppService.addUserAppComments(this.user_app_id, body).subscribe(
      (res) => {
        this.loader.close();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.resetCommentsForm();
        this.getComments();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  originalMessage = '';
  comment_id: number = 0;
  replybtn: false;
  pos;
  checkedCommentsItem(message, comment_id, replybtn, pos) {
    this.pos = pos;
    this.replybtn = replybtn;
    this.originalMessage = message;
    this.comment_id = comment_id;
    // this.notificationFormGroup.controls['app_comments'].setValue(item);
  }

  updateComments(type: any) {
    let message = this.commentsFormGroup.value.app_comments;
    let body = {
      comment_timestamp: this.getUTC(),
      comment_text: this.originalMessage,
    };

    this.loader.open();
    this.userAppService
      .updateUserAppComments(this.user_app_id, this.comment_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.replybtn = false;
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.resetCommentsForm();
          this.originalMessage = '';
          this.comment_id = 0;
          this.getComments();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }
  updateUserAppCommentsType(is_the_comment_private: any) {
    let body = {
      comment_reply: this.commentsFormGroup.value.app_comments,
    };
    this.loader.open();
    this.userAppService
      .updateUserAppCommentsType(
        this.user_app_id,
        this.comment_id,
        is_the_comment_private,
        body
      )
      .subscribe(
        (res) => {
          this.loader.close();
          this.replybtn = false;
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.resetCommentsForm();
          this.originalMessage = '';
          this.comment_id = 0;
          this.getComments();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  deleteComments(comment_id: any) {
    this.loader.open();
    this.userAppService
      .deleteUserAppComments(comment_id, this.user_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.getComments();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  resetCommentsForm() {
    this.commentsFormGroup.reset();
  }

  public getUTCtoLocal(utcDateTime: any) {
    const date = new Date(utcDateTime);
    return new Date(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
  }

  private getUTC() {
    const now = new Date();
    return new Date(now.getTime() + now.getTimezoneOffset() * 60000);
  }
}
