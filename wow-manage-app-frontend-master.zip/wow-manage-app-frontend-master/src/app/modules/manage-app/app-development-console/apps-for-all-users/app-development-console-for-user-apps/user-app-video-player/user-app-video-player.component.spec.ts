import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAppVideoPlayerComponent } from './user-app-video-player.component';

describe('UserAppVideoPlayerComponent', () => {
  let component: UserAppVideoPlayerComponent;
  let fixture: ComponentFixture<UserAppVideoPlayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAppVideoPlayerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAppVideoPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
