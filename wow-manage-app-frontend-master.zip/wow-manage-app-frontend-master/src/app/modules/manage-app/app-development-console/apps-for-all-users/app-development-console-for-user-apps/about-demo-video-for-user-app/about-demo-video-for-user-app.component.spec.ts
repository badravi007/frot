import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutDemoVideoForUserAppComponent } from './about-demo-video-for-user-app.component';

describe('AboutDemoVideoForUserAppComponent', () => {
  let component: AboutDemoVideoForUserAppComponent;
  let fixture: ComponentFixture<AboutDemoVideoForUserAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AboutDemoVideoForUserAppComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AboutDemoVideoForUserAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
