import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import { UserAppCategoryData } from 'src/app/models/user-app.interface';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { DataSharingService } from 'src/app/shared/services/data-sharing/data-sharing.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';

@Component({
  selector: 'app-categorization-of-user-app',
  templateUrl: './categorization-of-user-app.component.html',
  styleUrls: ['./categorization-of-user-app.component.scss'],
})
export class CategorizationOfUserAppComponent implements OnInit {
  @ViewChild('tree') tree: ElementRef;

  @Input() user_app_id: any;
  @Input() userAppCategoryIds: string;

  @Output() getAssignedCategory = new EventEmitter();

  hiddenCategories: boolean = false;

  selected_users_list_val: any = null;
  selected_category_name_val: any = null;
  selected_category_val: any = [];

  constructor(
    private _apiService: UserAppService,
    private _headerTitle: HeaderTitleService,
    public dialog: MatDialog,
    public snackBarService: SnackBarService,
    public dataSharingService: DataSharingService,
    private loader: CustomSpinnerService
  ) {
    // this.loadAssignedCategoryData();
  }

  nestedTreeControl: NestedTreeControl<UserAppCategoryData>;
  nestedDataSource: MatTreeNestedDataSource<UserAppCategoryData>;
  treeNodeSelection = new SelectionModel<UserAppCategoryData>(
    true /* multiple */
  );

  apps_selection = new SelectionModel<UserAppCategoryData>(true /* multiple */);
  list_of_apps: any;
  ngOnInit() {
    this._headerTitle.setTitle('PWA Apps for Users');

    this.nestedTreeControl = new NestedTreeControl<UserAppCategoryData>(
      this._getChildren
    );
    this.nestedDataSource = new MatTreeNestedDataSource();

    this._apiService.getAllUserAppCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;

      let selected_user_app_category_ids = res.data;

      if (selected_user_app_category_ids.length > 0) {
        this.treeNodeSelection.clear(true);
        this.nestedDataSource.data.forEach((node) => {
          this.callRecursively(node);
        });
      } else {
        this.treeNodeSelection.clear(true);
        this.apps_selection.clear(true);
        this.list_of_apps = [];
      }
    });
  }

  callRecursively(node: any) {
    let userAppCategoryIds = this.userAppCategoryIds.split(',');
    if (userAppCategoryIds.length > 0) {
      userAppCategoryIds.map((data) => {
        if (node.user_app_category_id == data) {
          this.todoLeafItemSelectionToggle(node);
          this.expand(this.nestedDataSource.data, data);
        }
        if (node.children) {
          node.children.forEach((childNode: any) => {
            this.callRecursively(childNode);
          });
        }
      });
    }
  }

  expand(data: any[], uniqueId: string): any {
    data.forEach((node) => {
      if (
        node.children &&
        node.children.find((c: any) => c.user_app_category_id === uniqueId)
      ) {
        this.nestedTreeControl.expand(node);
        this.expand(this.nestedDataSource.data, node.user_app_category_id);
      } else if (node.children && node.children.find((c: any) => c.children)) {
        this.expand(node.children, uniqueId);
      }
    });
  }

  private _transformer = (node: UserAppCategoryData, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.user_app_category_name,
      level: level,
    };
  };

  private _getChildren = (node: UserAppCategoryData) => of(node.children);

  hasNestedChild = (_: string, nodeData: UserAppCategoryData) =>
    nodeData.children.length > 0;

  refreshUserAppCategoryData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  currentNodeVal: any;

  currentNodes(val: any) {
    console.log(val);

    this.currentNodeVal = val;
  }

  addNode(node: UserAppCategoryData) {
    // this.nestedTreeControl.isExpanded(node);
    let api_data: UserAppCategoryData = {
      user_app_category_id: node.user_app_category_id,
      parent_user_app_category_id: node.parent_user_app_category_id,
      user_app_category_name: node.user_app_category_name,
      is_the_user_app_category_hidden: '0',
      children: node.children,
      user_app_category_type: '0',
    };
    this._apiService.addUserAppCategory(api_data).subscribe((res) => {
      if (res['status'] === 200) {
        let data: UserAppCategoryData = {
          user_app_category_id: node.user_app_category_id,
          parent_user_app_category_id: node.parent_user_app_category_id,
          user_app_category_name: node.user_app_category_name,
          is_the_user_app_category_hidden: 0,
          children: node.children,
          user_app_category_type: '0',
        };
        this.nestedDataSource.data.push(data);
        this.refreshUserAppCategoryData();
      }
    });
  }

  addChildNode(childrenNodeData: {
    currentNode: { children: any[] };
    node: any;
  }) {
    this._apiService
      .checkUserAppIsAssignedUserAppCategory(
        childrenNodeData.node.user_app_category_id
      )
      .subscribe((res) => {
        console.log(res.userIsAssigned);
        const userIsAssigned = res.userIsAssigned;
        if (userIsAssigned) {
          if (
            confirm(
              'If you wish to create a sub category to the parent category where users / apps are assigned,the same shall be reassigned to this new sub category: ' +
                childrenNodeData.node.category_name +
                '. \nDo you wish to proceed ? '
            ) === true
          ) {
            this._apiService
              .addUserAppCategory(childrenNodeData.node)
              .subscribe((res) => {
                if (res['status'] === 200) {
                  let data = {
                    parent_data: childrenNodeData.currentNode,
                    child_data: childrenNodeData.node,
                  };
                  // this._apiService
                  //   .passingUsersParentToChild(data)
                  //   .subscribe((res) => {
                  //     if (res['status'] == 200) {
                  //       // res.OK call the refresh tree method
                  //       childrenNodeData.currentNode.children.push(
                  //         childrenNodeData.node
                  //       );
                  //       this.refreshUserAppCategoryData();
                  //       this.loadAssignedCategoryData();
                  //     }
                  //   });
                }
              });
          }
        } else {
          this._apiService
            .addUserAppCategory(childrenNodeData.node)
            .subscribe((res) => {
              if (res['status'] === 200) {
                childrenNodeData.currentNode.children.push(
                  childrenNodeData.node
                );
                this.refreshUserAppCategoryData();
              }
            });
        }
      });
  }

  editNode(nodeToBeEdited: {
    node: UserAppCategoryData;
    currentNode: { user_app_category_id: string };
  }) {
    console.log('edit node', nodeToBeEdited.node);

    this._apiService
      .updateUserAppCategory(nodeToBeEdited.node)
      .subscribe((res) => {
        if (res['status'] === 200) {
          const fatherElement: UserAppCategoryData | any = this.findFatherNode(
            nodeToBeEdited.currentNode.user_app_category_id,
            this.nestedDataSource.data
          );
          let elementPosition: number;
          if (fatherElement[0]) {
            fatherElement[0].children[fatherElement[1]] = nodeToBeEdited.node;
          } else {
            elementPosition = this.findPosition(
              nodeToBeEdited.currentNode.user_app_category_id,
              this.nestedDataSource.data
            );
            this.nestedDataSource.data[elementPosition] = nodeToBeEdited.node;
          }
          this.refreshUserAppCategoryData();
        }
      });
  }

  deleteNode(nodeToBeDeleted: UserAppCategoryData) {
    console.log('delete node', nodeToBeDeleted);

    const deletedElement: UserAppCategoryData | any = this.findFatherNode(
      nodeToBeDeleted.user_app_category_id,
      this.nestedDataSource.data
    );
    let elementPosition: number;

    if (nodeToBeDeleted.is_the_user_app_category_hidden == 1) {
      let confirm_text_1 =
        'Are you sure you want to Unhide \nParent Category: ' +
        nodeToBeDeleted.user_app_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Unhide \nSub Category: ' +
        nodeToBeDeleted.user_app_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_user_app_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: UserAppCategoryData = {
          user_app_category_id: nodeToBeDeleted.user_app_category_id,
          parent_user_app_category_id:
            nodeToBeDeleted.parent_user_app_category_id,
          user_app_category_name: nodeToBeDeleted.user_app_category_name,
          is_the_user_app_category_hidden: '0',
          children: nodeToBeDeleted.children,
          user_app_category_type: '0',
        };

        let data: UserAppCategoryData = {
          user_app_category_id: nodeToBeDeleted.user_app_category_id,
          parent_user_app_category_id:
            nodeToBeDeleted.parent_user_app_category_id,
          user_app_category_name: nodeToBeDeleted.user_app_category_name,
          is_the_user_app_category_hidden: 0,
          children: nodeToBeDeleted.children,
          user_app_category_type: '0',
        };

        this._apiService.hideUserAppCategory(apidata).subscribe((res) => {
          if (res['status'] === 200) {
            const fatherElement: UserAppCategoryData | any =
              this.findFatherNode(
                nodeToBeDeleted.user_app_category_id,
                this.nestedDataSource.data
              );
            let elementPosition: number;
            if (fatherElement[0]) {
              fatherElement[0].children[fatherElement[1]] = data;
            } else {
              elementPosition = this.findPosition(
                nodeToBeDeleted.user_app_category_id,
                this.nestedDataSource.data
              );
              this.nestedDataSource.data[elementPosition] = data;
            }
            this.refreshUserAppCategoryData();
          }
        });
      }
    } else if (nodeToBeDeleted.is_the_user_app_category_hidden == 0) {
      let confirm_text_1 =
        'Are you sure you want to Hide \nParent Category: ' +
        nodeToBeDeleted.user_app_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Hide \nSub Category: ' +
        nodeToBeDeleted.user_app_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_user_app_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: UserAppCategoryData = {
          user_app_category_id: nodeToBeDeleted.user_app_category_id,
          parent_user_app_category_id:
            nodeToBeDeleted.parent_user_app_category_id,
          user_app_category_name: nodeToBeDeleted.user_app_category_name,
          is_the_user_app_category_hidden: '1',
          children: nodeToBeDeleted.children,
          user_app_category_type: '0',
        };

        let data: UserAppCategoryData = {
          user_app_category_id: nodeToBeDeleted.user_app_category_id,
          parent_user_app_category_id:
            nodeToBeDeleted.parent_user_app_category_id,
          user_app_category_name: nodeToBeDeleted.user_app_category_name,
          is_the_user_app_category_hidden: 1,
          children: nodeToBeDeleted.children,
          user_app_category_type: '0',
        };

        // console.log(nodeToBeDeleted);
        this._apiService
          .checkUserAppIsAssignedUserAppCategory(nodeToBeDeleted)
          .subscribe((res) => {
            console.log(res.userIsAssigned);
            const userIsAssigned = res.userIsAssigned;
            if (userIsAssigned) {
              alert(
                'Users are present in this category! \n To hide kindly reassign the user to another category'
              );
              this.openUserReassignDialog(nodeToBeDeleted);
            } else {
              this._apiService.hideUserAppCategory(apidata).subscribe((res) => {
                if (res['status'] === 200) {
                  const fatherElement: UserAppCategoryData | any =
                    this.findFatherNode(
                      nodeToBeDeleted.user_app_category_id,
                      this.nestedDataSource.data
                    );
                  let elementPosition: number;
                  if (fatherElement[0]) {
                    fatherElement[0].children[fatherElement[1]] = data;
                  } else {
                    elementPosition = this.findPosition(
                      nodeToBeDeleted.user_app_category_id,
                      this.nestedDataSource.data
                    );
                    this.nestedDataSource.data[elementPosition] = data;
                  }
                  this.refreshUserAppCategoryData();
                }
              });
            }
          });

        // if (condition) {

        // }
      }
    }
  }

  openUserReassignDialog(nodeToBeDeleted: UserAppCategoryData) {
    // this.dialog.open(UserReassignDialogCheckboxComponent, {
    //   disableClose: true,
    //   width: '400px',
    //   minHeight: 'calc(100vh - 700px)',
    //   data: nodeToBeDeleted,
    // });
  }
  // Tree Functions
  flatJsonArray(
    flattenedAray: Array<UserAppCategoryData>,
    node: UserAppCategoryData[]
  ) {
    const array: Array<UserAppCategoryData> = flattenedAray;
    node.forEach((element) => {
      if (element.children) {
        array.push(element);
        this.flatJsonArray(array, element.children);
      }
    });
    return array;
  }

  findNodeMaxId(node: UserAppCategoryData[]) {
    const flatArray = this.flatJsonArray([], node);
    const flatArrayWithoutChildren: any[] = [];
    flatArray.forEach((element) => {
      flatArrayWithoutChildren.push(element.user_app_category_id);
    });
    return Math.max(...flatArrayWithoutChildren);
  }

  findPosition(id: string, data: UserAppCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      if (id === data[i].user_app_category_id) {
        return i;
      }
    }
    return null;
  }

  findFatherNode(user_app_category_id: string, data: UserAppCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      const currentFather = data[i];
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (
          user_app_category_id ===
          currentFather.children[z]['user_app_category_id']
        ) {
          return [currentFather, z];
        }
      }
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (
          user_app_category_id !==
          currentFather.children[z]['user_app_category_id']
        ) {
          const result: any = this.findFatherNode(
            user_app_category_id,
            currentFather.children
          );
          if (result !== false) {
            return result;
          }
        }
      }
    }
    return false;
  }

  radiobtnval(node: UserAppCategoryData) {
    console.log(node);
  }

  getLevel = (node: UserAppCategoryData) => node.level;

  isExpandable = (node: UserAppCategoryData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: UserAppCategoryData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) =>
      this.treeNodeSelection.isSelected(child)
    );
    return descAllSelected;
  }

  disableishidden(node: UserAppCategoryData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_the_user_app_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: UserAppCategoryData): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.treeNodeSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: UserAppCategoryData): void {
    this.treeNodeSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.treeNodeSelection.isSelected(node)
      ? this.treeNodeSelection.select(...descendants)
      : this.treeNodeSelection.deselect(...descendants);
    // console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.treeNodeSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
    this.selected_category_val = this.treeNodeSelection.selected;
  }

  @Output() getSelectedGetsterCategoryID = new EventEmitter();

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: UserAppCategoryData): void {
    // console.log(node.user_app_category_id);
    this.treeNodeSelection.toggle(node);
    this.checkAllParentsSelection(node);
    this.selected_category_val = this.treeNodeSelection.selected;

    this.getSelectedGetsterCategoryID.emit(node.user_app_category_id);
  }

  /* Checks all the parents when a leaf node is selected/unselected */

  checkAllParentsSelection(node: UserAppCategoryData): void {
    let parent: UserAppCategoryData | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: UserAppCategoryData): void {
    const nodeSelected = this.treeNodeSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.treeNodeSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.treeNodeSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.treeNodeSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: UserAppCategoryData): UserAppCategoryData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl.dataNodes.indexOf(node) - 1;
    console.log(startIndex);

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  assignCategory() {
    // console.log(this.selected_users_list_val);
    // console.log(this.selected_category_name_val);
    // let data = {
    //   user_app_category_id:
    //     this.selected_category_name_val.user_app_category_id,
    //   parent_user_app_category_id:
    //     this.selected_category_name_val.parent_user_app_category_id,
    //   user_app_category_name:
    //     this.selected_category_name_val.user_app_category_name,
    //   user_id: this.selected_users_list_val.user_id,
    //   user_name: this.selected_users_list_val.name,
    //   user_app_educational_institution_category_id: 'dfkjbk', // Todo: TEMP
    // };

    let selected_category_ids: any[] = [];
    this.selected_category_val.map((data) => {
      if (selected_category_ids.length == 0)
        selected_category_ids.push(data.user_app_category_id);
      else {
        let removeIndexValue = selected_category_ids.indexOf(
          data.user_app_category_id
        );
        if (removeIndexValue == -1)
          selected_category_ids.push(data.user_app_category_id);
        else selected_category_ids.splice(removeIndexValue, 1);
      }
    });

    let body = {
      user_app_country_code: 'in',
      user_app_educational_institution_category_id: 0, // Todo: TEMP
      user_app_category_ids: selected_category_ids.toString(),
      user_app_id: this.user_app_id,
      custom_app_id: null,
      user_app_category_location: 0,

      is_hidden: false,
    };

    this._apiService.AssignCategoryToUserApp(body).subscribe((res) => {
      console.log(res);
      this.snackBarService.success(res.message);

      this.getAssignedCategory.emit();

      // this.loadAssignedCategoryData();
    });
  }

  // loadAssignedCategoryData() {
  //   this._apiService.get_assigned_category().subscribe((res) => {
  //     this.dataSharingService.updateAssignedCategoryData(res[0]);
  //   });
  // }

  // ------------------------------- Helper Function --------------------

  arrayBufferToBase64(buffer: ArrayBuffer) {
    var blob = new Blob([buffer], { type: 'blob' });
    var reader = new FileReader();
    let base64 = new Promise((reslove: any, reject: any) => {
      reader.onload = (evt: any) => {
        // let dataurl = evt.target.result;
        reslove(evt.target.result);
      };
    });
    reader.readAsDataURL(blob);
    return base64;
  }
}
