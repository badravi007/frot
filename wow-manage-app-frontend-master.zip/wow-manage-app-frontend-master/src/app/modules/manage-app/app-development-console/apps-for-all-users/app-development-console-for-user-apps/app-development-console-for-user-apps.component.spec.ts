/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppDevelopmentConsoleForUserAppsComponent } from './app-development-console-for-user-apps.component';

describe('AppDevelopmentConsoleForUserAppsComponent', () => {
  let component: AppDevelopmentConsoleForUserAppsComponent;
  let fixture: ComponentFixture<AppDevelopmentConsoleForUserAppsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDevelopmentConsoleForUserAppsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDevelopmentConsoleForUserAppsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
