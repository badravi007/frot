import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { UtcTimeService } from 'src/app/shared/util/utc-time.service';

@Component({
  selector: 'app-user-app-communication',
  templateUrl: './user-app-communication.component.html',
  styleUrls: ['./user-app-communication.component.scss'],
})
export class UserAppCommunicationComponent implements OnInit {
  communicationFormGroup: FormGroup;
  constructor(
    private userAppService: UserAppService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private elRef: ElementRef,
    public utcTimeService: UtcTimeService
  ) {
    this.communicationFormGroup = this.fb.group({
      app_notification: new FormControl(''),
      app_comments: new FormControl(''),
    });
  }

  @Input() user_app_id: number;

  ngOnInit() {
    this.getUserAppCommunication();
  }

  communicationList: any = [];

  getUserAppCommunication() {
    // this.loader.open();
    this.userAppService.getUserAppCommunication(this.user_app_id).subscribe(
      (res) => {
        this.loader.close();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.resetCommentsForm();
        this.communicationList = res.data;
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  deleteUserAppCommunication(communication_id) {
    this.loader.open();
    this.userAppService
      .deleteUserAppCommunication(this.user_app_id, communication_id)
      .subscribe(
        (res) => {
          this.getUserAppCommunication();
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  addUserAppCommunication() {
    let message = this.communicationFormGroup.value.app_notification;
    let body = {
      communication_utc_date_time: this.utcTimeService.getUTC(),
      user_id: this.user_app_id,
      communication_text: message,
    };

    this.loader.open();
    this.userAppService
      .addUserAppCommunication(this.user_app_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.getUserAppCommunication();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  resetCommentsForm() {
    this.communicationFormGroup.reset();
  }
}
