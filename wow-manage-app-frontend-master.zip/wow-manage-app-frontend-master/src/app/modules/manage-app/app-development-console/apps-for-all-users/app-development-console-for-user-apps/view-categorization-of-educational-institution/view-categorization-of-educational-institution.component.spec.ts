/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ViewCategorizationOfEducationalInstitutionComponent } from './view-categorization-of-educational-institution.component';

describe('ViewCategorizationOfEducationalInstitutionComponent', () => {
  let component: ViewCategorizationOfEducationalInstitutionComponent;
  let fixture: ComponentFixture<ViewCategorizationOfEducationalInstitutionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCategorizationOfEducationalInstitutionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCategorizationOfEducationalInstitutionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
