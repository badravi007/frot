import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  UserAppCategoryData,
  UserAppDialogData,
} from 'src/app/models/user-app.interface';

@Component({
  selector: 'app-edit-custom-app-category',
  template: `
    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons edit-btn"
      (click)="openDialog()"
    >
      <mat-icon> edit </mat-icon>
    </button>
  `,
  styles: [
    `
      .edit-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 90%; */
        /* font-size: 18px; */
      }
      /* */
    `,
  ],
})
export class EditCustomAppCategoryComponent {
  @Input() isTop: boolean;
  @Input() currentNode: UserAppCategoryData;
  @Input() isDisabled: boolean;
  @Output() edittedNode = new EventEmitter();

  constructor(public dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(EditCustomAppDialogReassignCheckbox, {
      disableClose: true,
      width: '400px',
      minHeight: 'calc(100vh - 700px)',
      data: {
        user_app_category_name: this.currentNode.user_app_category_name,
        Component: 'Edit',
        parent: this.currentNode,
        isTop: this.isTop,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const node: UserAppCategoryData = {
          user_app_category_id: this.currentNode.user_app_category_id,
          parent_user_app_category_id:
            this.currentNode.parent_user_app_category_id,
          user_app_category_name: result.user_app_category_name,
          is_the_user_app_category_hidden:
            this.currentNode.is_the_user_app_category_hidden,
          children: this.currentNode.children,
          user_app_category_type: '0',
        };
        this.edittedNode.emit({ currentNode: this.currentNode, node: node });
      }
    });
  }
}

@Component({
  selector: 'user-app-edit-category-dialog',
  templateUrl:
    '../custom-app-category-dialog/custom-app-category-dialog.component.html',
})
export class EditCustomAppDialogReassignCheckbox {
  constructor(
    public dialogRef: MatDialogRef<EditCustomAppDialogReassignCheckbox>,
    @Inject(MAT_DIALOG_DATA) public data: UserAppDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
