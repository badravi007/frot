import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import videojs, { VideoJsPlayer, VideoJsPlayerOptions } from 'video.js';

@Component({
  selector: 'app-custom-app-video-player',
  templateUrl: './custom-app-video-player.component.html',
  styleUrls: ['./custom-app-video-player.component.scss'],
})
export class CustomAppVideoPlayerComponent implements OnInit, AfterViewInit {
  //* --------------------------  Start  -----------------------------------*//

  //* -----------------------  Decorated Methods  --------------------------*//
  @ViewChild('videoPlayer', { static: true }) videoPlayer: ElementRef;

  @Input() videoSource: any;
  @Input() posterSource: any;
  @Input() isVideoLoaded: boolean = false;

  @Input() isShowControls: boolean = false;
  @Input() isMuted: boolean = false;
  @Input() isAutoPlay: boolean = false;

  @Input() changeCurrentTimeStamp: number = 0;

  @Output() timeUpdate = new EventEmitter();
  @Output() pickTimeStamp = new EventEmitter();
  @Output() thumbNailImage = new EventEmitter();
  @Output() videoTotalDuration = new EventEmitter();
  // @Output() isValidResolution = new EventEmitter();
  //* -----------------------  Variable Declaration  -----------------------*//
  public video: HTMLVideoElement;
  public player: VideoJsPlayer;
  options: VideoJsPlayerOptions = {};
  isJumpTimeStamp: boolean = false;

  // @Input() poster: string;
  // source: string = 'http://media.w3.org/2010/05/sintel/trailer.mp4#t=15,19';
  source: string = 'http://media.w3.org/2010/05/sintel/trailer.mp4';
  poster: string =
    'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg';

  //* ---------------------------  Constructor  ----------------------------*//
  constructor() {}

  //* -------------------------  Lifecycle Hooks  --------------------------*//

  ngAfterViewInit(): void {
    // this.isVideoLoaded = true;
    // const reader = new FileReader();
    // reader.onload = (data: any) => {
    //   this.onVideoLoad(data.target.result);
    // };
    // reader.onerror = function () {
    //   console.log('there are some problems');
    // };
    // reader.readAsDataURL(this.videoSource);

    this.onVideoLoad(this.videoSource);
  }
  ngOnInit(): void {
    // throw new Error('Method not implemented.');
  }

  ngOnDestroy() {
    // destroy player
    if (this.player) {
      this.player.dispose();
    }
  }

  //* ----------------------------  APIs Methods  --------------------------*//

  //* --------------------------  Public methods  --------------------------*//
  onVideoLoad(source: string) {
    this.options = {
      aspectRatio: '16:9',
      controls: this.isShowControls,
      autoplay: false,
      muted: this.isMuted, //This not supported for set dynamic video source
      html5: {
        hls: {
          overrideNative: true,
        },
      },
      sources: [{ src: source, type: 'video/mp4' }],
      poster: this.posterSource,
    };

    // instantiate Video.js
    this.player = videojs(this.videoPlayer.nativeElement, this.options, () => {
      // this.player.currentTime(10);
      this.player.pause();
    });

    this.isVideoLoaded = false;

    // this.player.load

    // setTimeout(() => {
    //   this.videoTotalDuration.emit(this.player.duration());
    // }, 500);
  }

  onGetVideoTotalDuration(e: Event) {
    // let video = e.target as HTMLVideoElement;
    // if (video.videoWidth < 1280 && video.videoHeight < 720) {
    //   this.isValidResolution.emit(true);
    // } else {
    //   this.isValidResolution.emit(false);
    // }
    this.videoTotalDuration.emit(this.player.duration());
  }

  onTimeUpdate(e: Event) {
    this.timeUpdate.emit(e);
  }
  onPickTimeStamp(e: Event) {
    this.pickTimeStamp.emit(e);
    this.player.pause();

    // if (this.player.paused) this.player.play();
    // else this.player.pause();
  }

  onGetThumbnail() {
    const dataURL = this.captureImage();
    this.thumbNailImage.emit(dataURL);
    this.player.pause();
  }

  captureImage() {
    let video = this.videoPlayer.nativeElement as HTMLVideoElement;
    const canvasElement = <HTMLCanvasElement>document.createElement('CANVAS');
    const context = canvasElement.getContext('2d');
    let w: number, h: number;
    w = video.videoWidth;
    h = video.videoHeight;
    canvasElement.width = w;
    canvasElement.height = h;
    context.drawImage(video, 0, 0, w, h);
    const dataURL = canvasElement.toDataURL();

    // canvasElement.toBlob((blob: any) => {
    //   const img = new Image();
    //   img.src = window.URL.createObjectURL(blob);
    //   console.log(img.src);
    // });

    return dataURL;
  }

  onTimeStampChangeToPlay() {
    this.isJumpTimeStamp = true;
    this.player.currentTime(this.changeCurrentTimeStamp);
    setTimeout(() => {
      this.player.play();
      this.player.setTimeout(() => {
        this.player.play();
        this.player.setTimeout(() => {
          this.player.pause();
        }, 1000 * 5);
      }, 300);
    }, 0);
  }

  //! -------------------------------  End  --------------------------------!//
}
