import { Component, EventEmitter, Input, Output } from '@angular/core';
import { UserAppCategoryData } from 'src/app/models/user-app.interface';

@Component({
  selector: 'app-delete-custom-app-category',
  template: `
    <!-- {{ btnDisable }} -->
    <button
      [disabled]="btnDisable"
      color="primary"
      mat-icon-button
      class="material-icons delete-btn"
      (click)="deleteNode()"
    >
      <ng-container>
        <mat-icon>{{
          currentNode['is_the_user_app_category_hidden']
            ? 'visibility_off'
            : 'visibility'
        }}</mat-icon>
      </ng-container>
    </button>
  `,
  styles: [
    `
      .delete-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 85%; */
        /* font-size: 18px; */
      }
    `,
  ],
})
export class DeleteCustomAppCategoryComponent {
  @Output() deletedNode = new EventEmitter();
  @Input() currentNode: UserAppCategoryData;
  @Input() btnDisable: any;

  deleteNode() {
    this.deletedNode.emit(this.currentNode);
  }
  booleanCondition(val: any) {
    return val == 0 ? false : val == 1 ? true : null;
  }
}
