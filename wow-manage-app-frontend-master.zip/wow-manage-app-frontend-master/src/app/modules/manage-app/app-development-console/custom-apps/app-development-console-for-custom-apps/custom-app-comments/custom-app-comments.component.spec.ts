import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomAppCommentsComponent } from './custom-app-comments.component';

describe('CustomAppCommentsComponent', () => {
  let component: CustomAppCommentsComponent;
  let fixture: ComponentFixture<CustomAppCommentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomAppCommentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomAppCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
