import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CustomAppService } from 'src/app/shared/services/app-development-console/custom-app.service';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { GlobalConstants } from 'src/app/shared/util/global-constants';

@Component({
  selector: 'app-custom-apps',
  templateUrl: './custom-apps.component.html',
  styleUrls: ['./custom-apps.component.scss'],
})
export class CustomAppsComponent implements OnInit {
  userAppList: any;
  constants: any = GlobalConstants;
  constructor(
    private router: Router,
    private _customAppService: CustomAppService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private _userApp: UserAppService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getAllCustomApps();
  }
  getAllCustomApps() {
    this.loader.open();
    this._customAppService.getAllCustomApps().subscribe(
      (res) => {
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this.userAppList = res.data;
        this.getPublishedAppList(res.data);
        this.getUnPublishedAppList(res.data);
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  userAppUnPublishedList: AppDetails[] = [];
  getUnPublishedAppList(appList: AppDetails[]) {
    let appDetails: AppDetails[] = [];
    for (let i = 0; i < appList.length; i++) {
      const element = appList[i];
      let appData: AppData[] = [];
      for (let j = 0; j < appList[i].data.length; j++) {
        const element = appList[i].data[j];
        if (element.custom_app_development_status == 0) {
          appData.push(element);
        }
      }

      if (appData.length > 0) {
        appDetails.push({
          user_app_category_name: element.user_app_category_name,
          data: appData,
        });
      }
    }
    this.userAppUnPublishedList = [...appDetails];
  }

  userAppPublishedList: AppDetails[] = [];
  getPublishedAppList(appList: AppDetails[]) {
    let appDetails: AppDetails[] = [];
    for (let i = 0; i < appList.length; i++) {
      const element = appList[i];
      let appData: AppData[] = [];
      for (let j = 0; j < appList[i].data.length; j++) {
        const element = appList[i].data[j];
        if (element.custom_app_development_status == 1) {
          appData.push(element);
        }
      }

      if (appData.length > 0) {
        appDetails.push({
          user_app_category_name: element.user_app_category_name,
          data: appData,
        });
      }
    }
    this.userAppPublishedList = [...appDetails];
  }

  addEditUserApp() {
    this.router
      .navigate([
        '/manage-app/app-development-console/app-development-console-user-apps-add',
        'add',
      ])
      .then(() => {
        // window.location.reload();
      });
  }

  updateAppStatus(
    custom_app_id: number,
    custom_app_development_status: boolean
  ) {
    let body = {
      custom_app_id,
      custom_app_development_status,
    };
    this._customAppService.updateCustomAppDevelopmentStatus(body).subscribe(
      (res) => {
        this.getAllCustomApps();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
      },
      (err) => {
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  addEditCustomApp(id: any, name: any, type) {
    if (type == 'add') {
      this.router
        .navigate([
          '/manage-app/app-development-console/app-development-console-custom-add',
          'add',
        ])
        .then(() => {
          // window.location.reload();
        });
    } else if (type == 'edit') {
      this.router
        .navigate([
          '/manage-app/app-development-console/app-development-console-custom-edit',
          id,
          name,
          type,
        ])
        .then(() => {});
    }
  }
}

interface AppDetails {
  user_app_category_name: string;
  data: AppData[];
}

interface AppData {
  user_app_id?: number;
  custom_app_icon_name: string;
  custom_app_icon_image_path: string;
  custom_app_full_name: string;
  custom_app_development_status: number;
  user_app_category_location: number;
  user_app_educational_institution_category_id: string;
  user_app_country_code: string;
  custom_app_id?: any;
  CategoryName: string;
  user_app_category_name: string;
  parent_user_app_category_id: string;
  user_app_category_id: string;
}
