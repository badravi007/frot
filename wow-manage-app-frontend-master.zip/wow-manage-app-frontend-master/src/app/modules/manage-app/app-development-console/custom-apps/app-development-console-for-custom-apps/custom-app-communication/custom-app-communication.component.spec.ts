import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomAppCommunicationComponent } from './custom-app-communication.component';

describe('CustomAppCommunicationComponent', () => {
  let component: CustomAppCommunicationComponent;
  let fixture: ComponentFixture<CustomAppCommunicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomAppCommunicationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomAppCommunicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
