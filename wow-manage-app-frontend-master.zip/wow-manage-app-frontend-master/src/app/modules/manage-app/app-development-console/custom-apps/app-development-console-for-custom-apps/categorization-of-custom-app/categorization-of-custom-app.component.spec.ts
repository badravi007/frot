import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CategorizationOfCustomAppComponent } from './categorization-of-custom-app.component';

describe('CategorizationOfCustomAppComponent', () => {
  let component: CategorizationOfCustomAppComponent;
  let fixture: ComponentFixture<CategorizationOfCustomAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CategorizationOfCustomAppComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CategorizationOfCustomAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
