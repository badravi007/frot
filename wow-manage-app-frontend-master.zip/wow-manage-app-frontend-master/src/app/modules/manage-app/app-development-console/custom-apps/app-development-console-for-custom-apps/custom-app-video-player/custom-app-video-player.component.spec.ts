import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomAppVideoPlayerComponent } from './custom-app-video-player.component';

describe('CustomAppVideoPlayerComponent', () => {
  let component: CustomAppVideoPlayerComponent;
  let fixture: ComponentFixture<CustomAppVideoPlayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomAppVideoPlayerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomAppVideoPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
