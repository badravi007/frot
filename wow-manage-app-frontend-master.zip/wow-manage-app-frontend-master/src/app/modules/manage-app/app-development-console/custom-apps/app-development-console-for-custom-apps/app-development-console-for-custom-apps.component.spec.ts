/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppDevelopmentConsoleForCustomAppsComponent } from './app-development-console-for-custom-apps.component';

describe('AppDevelopmentConsoleForCustomAppsComponent', () => {
  let component: AppDevelopmentConsoleForCustomAppsComponent;
  let fixture: ComponentFixture<AppDevelopmentConsoleForCustomAppsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDevelopmentConsoleForCustomAppsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDevelopmentConsoleForCustomAppsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
