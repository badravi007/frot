import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  UserAppCategoryData,
  UserAppDialogData,
} from 'src/app/models/user-app.interface';
import { CustomIdGeneratorService } from 'src/app/shared/services/custom-id-generator/custom-id-generator.service';

@Component({
  selector: 'app-add-custom-app-category',
  template: `
    <button
      mat-raised-button
      class="primary-button"
      (click)="openDialog()"
      *ngIf="isTop"
    >
      Add Parent Category
    </button>

    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons add-btn"
      *ngIf="!isTop"
      (click)="openDialog()"
    >
      <mat-icon>add </mat-icon>
    </button>
  `,
  styles: [
    `
      /* .top-node {
      position: absolute;
      left: 12px;
      margin-left: 4px;
    }
    */

      .add-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 95%; */
        /* margin-top: -5px; */
      }
    `,
  ],
})
export class AddCustomAppCategoryComponent {
  @Input() isTop: boolean;
  @Input() currentNode: UserAppCategoryData;
  @Output() addedNode = new EventEmitter();
  @Input() isDisabled: boolean;
  name: string;
  description: string;

  constructor(
    public dialog: MatDialog,
    private customIdGenerate: CustomIdGeneratorService
  ) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(
      AddCustomAppCategoryReassignCheckboxDialog,
      {
        disableClose: true,
        width: '400px',
        minHeight: 'calc(100vh - 700px)',
        data: {
          user_app_category_name: this.name,
          Component: 'Add',
          parent: this.currentNode,
          isTop: this.isTop,
        },
      }
    );
    dialogRef.afterClosed().subscribe((result) => {
      // console.log(this.currentNode);
      if (result) {
        const node: UserAppCategoryData = {
          user_app_category_id: this.customIdGenerate.CustomNanoId(),
          parent_user_app_category_id: null,
          user_app_category_name: result.user_app_category_name,
          children: [],
          is_the_user_app_category_hidden: false,
          user_app_category_type: '0',
        };
        if (this.isTop) {
          this.addedNode.emit(node);
        } else {
          const node2: UserAppCategoryData = {
            user_app_category_id: this.customIdGenerate.CustomNanoId(),
            parent_user_app_category_id: this.currentNode.user_app_category_id,
            user_app_category_name: result.user_app_category_name,
            children: [],
            is_the_user_app_category_hidden: false,
            user_app_category_type: '0',
          };
          this.addedNode.emit({ currentNode: this.currentNode, node: node2 });
        }
      }
    });
  }
}

@Component({
  selector: 'user-app-new-category',
  templateUrl:
    '../custom-app-category-dialog/custom-app-category-dialog.component.html',
})
export class AddCustomAppCategoryReassignCheckboxDialog {
  constructor(
    public dialogRef: MatDialogRef<AddCustomAppCategoryReassignCheckboxDialog>,
    @Inject(MAT_DIALOG_DATA) public data: UserAppDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
