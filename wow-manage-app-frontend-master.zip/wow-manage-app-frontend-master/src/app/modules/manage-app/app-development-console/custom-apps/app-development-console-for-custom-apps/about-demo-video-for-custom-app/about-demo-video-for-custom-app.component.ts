import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { CKEditorComponent } from 'ng2-ckeditor';
import { CustomAppService } from 'src/app/shared/services/app-development-console/custom-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { VideoJsPlayer } from 'video.js';
import { UserAppVideoPlayerComponent } from '../../../apps-for-all-users/app-development-console-for-user-apps/user-app-video-player/user-app-video-player.component';

@Component({
  selector: 'app-about-demo-video-for-custom-app',
  templateUrl: './about-demo-video-for-custom-app.component.html',
  styleUrls: ['./about-demo-video-for-custom-app.component.scss'],
})
export class AboutDemoVideoForCustomAppComponent implements OnInit {
  @ViewChild('videoPlayer') videoPlayer: UserAppVideoPlayerComponent;

  isOpenEditTimeStampArea: boolean = false;
  isOpenViewTimeStampArea: boolean = true;

  pickTimeStamp: number = 0;
  pickTimeStampTitle: string = null;
  pickTimeStampDescription: string = null;

  posterSource: string =
    'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg';

  isVideoLoaded: boolean = false;

  getTimeStampIndex: number = 0;

  isEditable: boolean = false;

  videoTotalDuration: number = 0;

  playCurrentTime: number = 0;

  videoThumbnail: any = null;

  changeCurrentTimeStamp: number;

  isValidResolution: boolean;

  timeStampDetails: TimeLine[] = [];

  @Input() custom_app_id: number;
  @Input() set custom_app_type(value: 'add' | 'edit') {
    if (value == 'edit') {
      this.getUserAppAboutDemoVideo();
    }
  }
  @Output() getTimeStampDetails = new EventEmitter();

  //!------------ Editor-----------------
  // name = 'ng2-ckeditor';
  ckeConfig: CKEDITOR.config;
  // mycontent: string;
  // log: string = '';
  @ViewChild('myckeditor') ckeditor: CKEditorComponent;

  //!------------ Editor-----------------

  public player: VideoJsPlayer;

  constructor(
    private _cdr: ChangeDetectorRef,
    // private _userAppService: UserAppService,
    private _customAppService: CustomAppService,
    private loader: CustomSpinnerService,
    private snackBar: SnackBarService
  ) {}

  ngOnInit(): void {
    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: false,
      removePlugins: 'exportpdf',

      font_names: 'Arial;Times New Roman;Verdana',
      toolbarGroups: [
        {
          name: 'paragraph',
          groups: [
            'basicstyles',
            'cleanup',
            'list',
            'indent',
            'blocks',
            'align',
            'bidi',
            'paragraph',
            'spellchecker',
            'colors',
            'Select',
          ],
        },
      ],
      removeButtons:
        'Source,Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,Radio,TextField,Textarea,Button,ImageButton,HiddenField,CopyFormatting,RemoveFormat,Outdent,CreateDiv,Blockquote,BidiLtr,BidiRtl,Unlink,Anchor,Flash,orizontalRule,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Maximize,ShowBlocks,About',
    };

    // this.getGetsterAppAboutDemoVideoDescription();
  }

  getUserAppAboutDemoVideo() {
    this._customAppService
      .getCustomAppAboutDemoVideoDescription(this.custom_app_id)
      .subscribe(
        (res) => {
          if (res.data != null) {
            this.videoUrl = 'http://media.w3.org/2010/05/sintel/trailer.mp4';
            // this.videoUrl = res.data.user_app_demo_video_path;

            this.isValidResolution = true;
            this.isOpenViewTimeStampArea = true;
            this._cdr.detectChanges();

            let temp = res.data.custom_app_demo_video_datetime_description_file;

            for (let i = 0; i < temp.data.length; i++) {
              this.timeStampDetails.push(temp.data[i]);
            }
          }

          // doubt

          this.snackBar.success(res.message);
          this.loader.close();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  onChangeTimeStamp() {
    // this.player.currentTime(10);
    // this.player.play();
  }

  ngOnDestroy() {
    // destroy player
    // if (this.player) {
    //   this.player.dispose();
    // }
  }

  onPickTimeStamp(video: Event) {
    let e = video.target as HTMLVideoElement;
    this.pickTimeStamp = e.currentTime;
  }

  onTimeStampChangeToPlay(e: any) {
    this.changeCurrentTimeStamp = e;

    setTimeout(() => {
      this.videoPlayer.onTimeStampChangeToPlay();
    }, 0);
    // this.player.currentTime(e);
    // this.player.play();
    // this.player.setTimeout(() => {
    //   this.player.play();
    //   this.player.setTimeout(() => {
    //     this.player.pause();
    //   }, 1000 * 5);
    // }, 300);
  }

  getVideoTotalDuration(e: number) {
    this.videoTotalDuration = e;
  }
  onAddTimeStamp() {
    this.timeStampDetails.push({
      time_stamp: this.pickTimeStamp,
      title: this.pickTimeStampTitle,
      description: this.pickTimeStampDescription,
    });

    this.getTimeStampDetails.emit(this.timeStampDetails);

    this.pickTimeStamp = null;
    this.pickTimeStampTitle = null;
    this.pickTimeStampDescription = null;
  }

  onTimeUpdate(video: Event) {
    let e = video.target as HTMLVideoElement;
    // console.log(e.currentTime);
    this.playCurrentTime = e.currentTime;
  }

  onEditTimeStampDetails(_data: TimeLine, index: number) {
    // this.player.pause();
    this.pickTimeStamp = _data.time_stamp;
    this.pickTimeStampTitle = _data.title;
    this.pickTimeStampDescription = _data.description;
    this.isEditable = true;
    this.getTimeStampIndex = index;
  }

  onSaveTimeStampDetails() {
    this.timeStampDetails[this.getTimeStampIndex] = {
      description: this.pickTimeStampDescription,
      title: this.pickTimeStampTitle,
      time_stamp: this.pickTimeStamp,
    };
    this.getTimeStampDetails.emit(this.timeStampDetails);
    this.isEditable = false;
    this.pickTimeStamp = null;
    this.pickTimeStampTitle = null;
    this.pickTimeStampDescription = null;
    this.getTimeStampIndex = null;
  }

  onDeleteTimeStampDetails(index: number) {
    this.timeStampDetails.splice(index, 1);
    this.getTimeStampDetails.emit(this.timeStampDetails);
  }

  // validResolution(_data: any) {
  //   console.log(
  //     'file: user-video-player.component.ts ~ line 184 ~ _data',
  //     _data
  //   );
  // }

  //!------------ Editor-----------------

  onChange($event: any): void {
    console.log('onChange');
    //this.log += new Date() + "<br />";
  }

  onPaste($event: any): void {
    console.log('onPaste');
    //this.log += new Date() + "<br />";
  }
  //!------------ Editor-----------------

  // ----------------------- Helper function -----------------------------------

  changeTimeFormat(currentTime: number): string {
    let timestamp = currentTime;
    let hours = Math.floor(timestamp / 60 / 60);
    let minutes = Math.floor(timestamp / 60) - hours * 60;
    let seconds = Math.floor(timestamp % 60);

    let formatted =
      hours.toString().padStart(2, '0') +
      ':' +
      minutes.toString().padStart(2, '0') +
      ':' +
      seconds.toString().padStart(2, '0');
    return formatted;
  }

  arraySort(_data: any[]) {
    // if (!_data) return '';
    let sortKey = 'time_stamp';
    let value = _data;
    let SortOrder: 'asc' | 'desc' = 'asc';

    let numberArray = [];
    let stringArray = [];

    if (!sortKey) {
      numberArray = value?.filter((item) => typeof item === 'number').sort();
      stringArray = value?.filter((item) => typeof item === 'string').sort();
    } else {
      numberArray = value
        .filter((item) => typeof item[sortKey] === 'number')
        .sort((a, b) => a[sortKey] - b[sortKey]);
      stringArray = value
        .filter((item) => typeof item[sortKey] === 'string')
        .sort((a, b) => {
          if (a[sortKey] < b[sortKey]) return -1;
          else if (a[sortKey] > b[sortKey]) return 1;
          else return 0;
        });
    }

    const sorted = numberArray.concat(stringArray);

    return SortOrder === 'asc' ? sorted : sorted.reverse();
  }

  videoUrl: any = null;
  public browseVideo(event: any) {
    this.isVideoLoaded = true;
    let e = event.target as HTMLInputElement;
    if (e.files && e.files[0]) {
      const reader = new FileReader();
      reader.onload = (data: any) => {
        // this.playVideo(data.target.result);
        this.isVideoLoaded = false;

        let video = document.createElement('video');

        video.setAttribute('src', data.target.result);

        video.onloadedmetadata = () => {
          if (video.videoWidth <= 854 && video.videoHeight <= 480) {
            // 16:9 -//480p - 854×480  //720p - 1280×720p
            this.videoUrl = data.target.result;
            this.isValidResolution = true;
            this.isOpenViewTimeStampArea = true;
            this._cdr.detectChanges();
            // this.isValidResolution.emit(true);
          } else {
            this.isValidResolution = false;
            this._cdr.detectChanges();
            // this.isValidResolution.emit(false);
          }
        };
      };
      reader.onerror = function () {
        console.log('there are some problems');
      };
      reader.readAsDataURL(e.files[0]);
    }
  }

  captureImage(e: any) {
    this.videoThumbnail = e;
  }
}

interface TimeLine {
  // time: string;
  title: string;
  description: string;
  time_stamp?: number;
}
