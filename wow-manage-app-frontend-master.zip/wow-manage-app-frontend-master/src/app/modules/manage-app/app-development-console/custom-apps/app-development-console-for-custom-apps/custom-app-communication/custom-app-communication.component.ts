import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CustomAppService } from 'src/app/shared/services/app-development-console/custom-app.service';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { UtcTimeService } from 'src/app/shared/util/utc-time.service';

@Component({
  selector: 'app-custom-app-communication',
  templateUrl: './custom-app-communication.component.html',
  styleUrls: ['./custom-app-communication.component.scss'],
})
export class CustomAppCommunicationComponent implements OnInit {
  communicationFormGroup: FormGroup;
  constructor(
    private userAppService: UserAppService,
    private _customAppService: CustomAppService,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private elRef: ElementRef,
    public utcTimeService: UtcTimeService
  ) {
    this.communicationFormGroup = this.fb.group({
      app_notification: new FormControl(''),
      app_comments: new FormControl(''),
    });
  }

  @Input() custom_app_id: number;

  ngOnInit() {
    this.getCustomAppCommunication();
  }

  communicationList: any = [];

  getCustomAppCommunication() {
    // this.loader.open();
    this._customAppService
      .getCustomAppCommunication(this.custom_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.resetCommentsForm();
          this.communicationList = res.data;
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  deleteCustomAppCommunication(communication_id) {
    this.loader.open();
    this._customAppService
      .deleteCustomAppCommunication(this.custom_app_id, communication_id)
      .subscribe(
        (res) => {
          this.getCustomAppCommunication();
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  addCustomAppCommunication() {
    let message = this.communicationFormGroup.value.app_notification;

    let body = {
      communication_id: 0,
      communication_utc_date_time: this.utcTimeService.getUTC(),
      user_id: this.custom_app_id,
      communication_text: message,
    };

    this.loader.open();
    this._customAppService
      .addCustomAppCommunication(this.custom_app_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.open(res.message, 'OK', { duration: 4000 });
          this.getCustomAppCommunication();
        },
        (err) => {
          this.loader.close();
          this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
        }
      );
  }

  resetCommentsForm() {
    this.communicationFormGroup.reset();
  }
}
