import { ComponentFixture, TestBed } from '@angular/core/testing';
import { beforeEach } from 'node:test';

import { CustomAppPermissionsComponent } from './custom-app-permissions.component';

describe('CustomAppPermissionsComponent', () => {
  let component: CustomAppPermissionsComponent;
  let fixture: ComponentFixture<CustomAppPermissionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomAppPermissionsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CustomAppPermissionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
