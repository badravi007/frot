import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CKEditorModule } from 'ng2-ckeditor';
import { WebcamModule } from 'ngx-webcam';
import { DummyHeaderComponent } from 'src/app/layout/dummy-header/dummy-header.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { AppDevelopmentConsoleComponent } from './app-development-console.component';
import { AppDevelopmentConsoleRoutingModule } from './app-development-console.routing';
import { AboutDemoVideoForUserAppComponent } from './apps-for-all-users/app-development-console-for-user-apps/about-demo-video-for-user-app/about-demo-video-for-user-app.component';
import { AppDevelopmentConsoleForUserAppsComponent } from './apps-for-all-users/app-development-console-for-user-apps/app-development-console-for-user-apps.component';
import {
  AddCategoryReassignCheckboxDialog,
  AddUserAppCategoryComponent,
} from './apps-for-all-users/app-development-console-for-user-apps/categorization-of-user-app/add-user-app-category/add-user-app-category.component';
import { CategorizationOfUserAppComponent } from './apps-for-all-users/app-development-console-for-user-apps/categorization-of-user-app/categorization-of-user-app.component';
import { DeleteUserAppCategoryComponent } from './apps-for-all-users/app-development-console-for-user-apps/categorization-of-user-app/delete-user-app-category/delete-user-app-category.component';
import {
  EditUserAppCategoryComponent,
  EditUserAppDialogReassignCheckbox,
} from './apps-for-all-users/app-development-console-for-user-apps/categorization-of-user-app/edit-user-app-category/edit-user-app-category.component';
import { UserAppCommentsComponent } from './apps-for-all-users/app-development-console-for-user-apps/user-app-comments/user-app-comments.component';
import { UserAppCommunicationComponent } from './apps-for-all-users/app-development-console-for-user-apps/user-app-communication/user-app-communication.component';
import { UserAppPermissionsComponent } from './apps-for-all-users/app-development-console-for-user-apps/user-app-permissions/user-app-permissions.component';
import { UserAppVideoPlayerComponent } from './apps-for-all-users/app-development-console-for-user-apps/user-app-video-player/user-app-video-player.component';
import { ViewCategorizationOfEducationalInstitutionComponent } from './apps-for-all-users/app-development-console-for-user-apps/view-categorization-of-educational-institution/view-categorization-of-educational-institution.component';
import { AppsForAllUsersComponent } from './apps-for-all-users/apps-for-all-users.component';
import { AboutDemoVideoForGetsterAppComponent } from './apps-for-getsters/app-development-console-for-getster-apps/about-demo-video-for-getster-app/about-demo-video-for-getster-app.component';
import { AppDevelopmentConsoleForGetsterAppsComponent } from './apps-for-getsters/app-development-console-for-getster-apps/app-development-console-for-getster-apps.component';
import {
  AddGetsterAppCategoryComponent,
  GETsterAppNewNodeDialogRadioButton,
} from './apps-for-getsters/app-development-console-for-getster-apps/categorization-of-getster-app/add-getster-app-category/add-getster-app-category.component';
import { CategorizationOfGetsterAppComponent } from './apps-for-getsters/app-development-console-for-getster-apps/categorization-of-getster-app/categorization-of-getster-app.component';
import { DeleteGetsterAppCategoryComponent } from './apps-for-getsters/app-development-console-for-getster-apps/categorization-of-getster-app/delete-getster-app-category/delete-getster-app-category.component';
import {
  EditGetsterAppCategoryComponent,
  GETsterAppEditDialogRadioButtonComponent,
} from './apps-for-getsters/app-development-console-for-getster-apps/categorization-of-getster-app/edit-getster-app-category/edit-getster-app-category.component';
import { GetsterAppCommentsComponent } from './apps-for-getsters/app-development-console-for-getster-apps/getster-app-comments/getster-app-comments.component';
import { GetsterAppCommunicationComponent } from './apps-for-getsters/app-development-console-for-getster-apps/getster-app-communication/getster-app-communication.component';
import { GetsterAppVideoPlayerComponent } from './apps-for-getsters/app-development-console-for-getster-apps/getster-app-video-player/getster-app-video-player.component';
import { ReassignGetsterAppCategoryComponent } from './apps-for-getsters/app-development-console-for-getster-apps/reassign-getster-app-category/reassign-getster-app-category.component';
import { AppsForGetstersComponent } from './apps-for-getsters/apps-for-getsters.component';
import { CommonDataForUserAppsComponent } from './common-data-for-user-apps/common-data-for-user-apps.component';
import { ApproveGetWOWeducationAdministratorPrivilegeComponent } from './console-users/approve-get-woweducation-administrator-privilege/approve-get-woweducation-administrator-privilege.component';
import { ConsoleUsersComponent } from './console-users/console-users.component';
import { DenyGetWOWeducationAdministratorPrivilegeComponent } from './console-users/deny-get-woweducation-administrator-privilege/deny-get-woweducation-administrator-privilege.component';
import {
  AddEducationalInstitutionCategoryComponent,
  AddInstitutionCategoryReassignCheckboxDialog,
} from './country-wise-educational-institution/categorization-of-educational-institution-category/add-educational-institution-category/add-educational-institution-category.component';
import { CategorizationOfEducationalInstitutionCategoryComponent } from './country-wise-educational-institution/categorization-of-educational-institution-category/categorization-of-educational-institution-category.component';
import { DeleteEducationalInstitutionCategoryComponent } from './country-wise-educational-institution/categorization-of-educational-institution-category/delete-educational-institution-category/delete-educational-institution-category.component';
import {
  EditEducationalInstitutionCategoryComponent,
  EditInstitutionCategoryReassignCheckboxDialog,
} from './country-wise-educational-institution/categorization-of-educational-institution-category/edit-educational-institution-category/edit-educational-institution-category.component';
import { CountryWiseEducationalInstitutionComponent } from './country-wise-educational-institution/country-wise-educational-institution.component';
import { EducationalInstitutionVideoPlayerComponent } from './country-wise-educational-institution/educational-institution-video-player/educational-institution-video-player.component';
import { UploadEducationalInstitutionVideoComponent } from './country-wise-educational-institution/upload-educational-institution-video/upload-educational-institution-video.component';
import { AboutDemoVideoForCustomAppComponent } from './custom-apps/app-development-console-for-custom-apps/about-demo-video-for-custom-app/about-demo-video-for-custom-app.component';
import { AppDevelopmentConsoleForCustomAppsComponent } from './custom-apps/app-development-console-for-custom-apps/app-development-console-for-custom-apps.component';
import {
  AddCustomAppCategoryComponent,
  AddCustomAppCategoryReassignCheckboxDialog,
} from './custom-apps/app-development-console-for-custom-apps/categorization-of-custom-app/add-custom-app-category/add-custom-app-category.component';
import { CategorizationOfCustomAppComponent } from './custom-apps/app-development-console-for-custom-apps/categorization-of-custom-app/categorization-of-custom-app.component';
import { DeleteCustomAppCategoryComponent } from './custom-apps/app-development-console-for-custom-apps/categorization-of-custom-app/delete-custom-app-category/delete-custom-app-category.component';
import {
  EditCustomAppCategoryComponent,
  EditCustomAppDialogReassignCheckbox,
} from './custom-apps/app-development-console-for-custom-apps/categorization-of-custom-app/edit-custom-app-category/edit-custom-app-category.component';
import { CustomAppCommentsComponent } from './custom-apps/app-development-console-for-custom-apps/custom-app-comments/custom-app-comments.component';
import { CustomAppCommunicationComponent } from './custom-apps/app-development-console-for-custom-apps/custom-app-communication/custom-app-communication.component';
import { CustomAppPermissionsComponent } from './custom-apps/app-development-console-for-custom-apps/custom-app-permissions/custom-app-permissions.component';
import { CustomAppVideoPlayerComponent } from './custom-apps/app-development-console-for-custom-apps/custom-app-video-player/custom-app-video-player.component';
import { CustomAppsComponent } from './custom-apps/custom-apps.component';

@NgModule({
  imports: [
    CommonModule,
    AppDevelopmentConsoleRoutingModule,
    SharedModule,
    WebcamModule,
    CKEditorModule,
  ],
  declarations: [
    AppDevelopmentConsoleComponent,
    AppDevelopmentConsoleForUserAppsComponent,
    CustomAppsComponent,
    DummyHeaderComponent,
    //GetsterApp
    CategorizationOfGetsterAppComponent,
    AppsForGetstersComponent,
    AppDevelopmentConsoleForGetsterAppsComponent,
    AboutDemoVideoForGetsterAppComponent,
    GetsterAppCommentsComponent,
    GetsterAppCommunicationComponent,
    ReassignGetsterAppCategoryComponent,
    GetsterAppVideoPlayerComponent,
    AddGetsterAppCategoryComponent,
    EditGetsterAppCategoryComponent,
    GETsterAppEditDialogRadioButtonComponent,
    DeleteGetsterAppCategoryComponent,
    GETsterAppNewNodeDialogRadioButton,
    // UserApp
    AppsForAllUsersComponent,
    CategorizationOfUserAppComponent,
    ViewCategorizationOfEducationalInstitutionComponent,
    AddUserAppCategoryComponent,
    EditUserAppCategoryComponent,
    DeleteUserAppCategoryComponent,
    AddCategoryReassignCheckboxDialog,
    EditUserAppDialogReassignCheckbox,
    UserAppPermissionsComponent,
    UserAppCommentsComponent,
    UserAppCommunicationComponent,
    // Educational Institution Category
    CategorizationOfEducationalInstitutionCategoryComponent,
    AddEducationalInstitutionCategoryComponent,
    DeleteEducationalInstitutionCategoryComponent,
    EditEducationalInstitutionCategoryComponent,
    AddInstitutionCategoryReassignCheckboxDialog,
    EditInstitutionCategoryReassignCheckboxDialog,
    UploadEducationalInstitutionVideoComponent,
    EducationalInstitutionVideoPlayerComponent,

    // Others
    CountryWiseEducationalInstitutionComponent,
    ConsoleUsersComponent,
    CommonDataForUserAppsComponent,
    AboutDemoVideoForUserAppComponent,
    UserAppVideoPlayerComponent,

    // Custom App
    AppDevelopmentConsoleForCustomAppsComponent,
    AboutDemoVideoForCustomAppComponent,
    CategorizationOfCustomAppComponent,
    CustomAppCommentsComponent,
    CustomAppCommunicationComponent,
    CustomAppPermissionsComponent,
    CustomAppVideoPlayerComponent,
    AddCustomAppCategoryComponent,
    DeleteCustomAppCategoryComponent,
    EditCustomAppCategoryComponent,
    EditCustomAppDialogReassignCheckbox,
    AddCustomAppCategoryReassignCheckboxDialog,
    ApproveGetWOWeducationAdministratorPrivilegeComponent,
    DenyGetWOWeducationAdministratorPrivilegeComponent,
  ],
})
export class AppDevelopmentConsoleModule {}
