import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DenyGetWOWeducationAdministratorPrivilegeComponent } from './deny-get-woweducation-administrator-privilege.component';

describe('DenyGetWOWeducationAdministratorPrivilegeComponent', () => {
  let component: DenyGetWOWeducationAdministratorPrivilegeComponent;
  let fixture: ComponentFixture<DenyGetWOWeducationAdministratorPrivilegeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DenyGetWOWeducationAdministratorPrivilegeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DenyGetWOWeducationAdministratorPrivilegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
