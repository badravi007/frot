import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-console-users',
  templateUrl: './console-users.component.html',
  styleUrls: ['./console-users.component.scss'],
})
export class ConsoleUsersComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
