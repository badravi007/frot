import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveGetWOWeducationAdministratorPrivilegeComponent } from './approve-get-woweducation-administrator-privilege.component';

describe('ApproveGetWOWeducationAdministratorPrivilegeComponent', () => {
  let component: ApproveGetWOWeducationAdministratorPrivilegeComponent;
  let fixture: ComponentFixture<ApproveGetWOWeducationAdministratorPrivilegeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApproveGetWOWeducationAdministratorPrivilegeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApproveGetWOWeducationAdministratorPrivilegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
