import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-get-woweducation-administrator-privilege',
  templateUrl: './approve-get-woweducation-administrator-privilege.component.html',
  styleUrls: ['./approve-get-woweducation-administrator-privilege.component.scss']
})
export class ApproveGetWOWeducationAdministratorPrivilegeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
