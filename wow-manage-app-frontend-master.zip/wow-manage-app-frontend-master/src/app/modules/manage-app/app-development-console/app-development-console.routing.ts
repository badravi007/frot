import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { AppDevelopmentConsoleComponent } from './app-development-console.component';
import { AppDevelopmentConsoleForUserAppsComponent } from './apps-for-all-users/app-development-console-for-user-apps/app-development-console-for-user-apps.component';
import { AppsForAllUsersComponent } from './apps-for-all-users/apps-for-all-users.component';
import { AppDevelopmentConsoleForGetsterAppsComponent } from './apps-for-getsters/app-development-console-for-getster-apps/app-development-console-for-getster-apps.component';
import { AppsForGetstersComponent } from './apps-for-getsters/apps-for-getsters.component';
import { CommonDataForUserAppsComponent } from './common-data-for-user-apps/common-data-for-user-apps.component';
import { ConsoleUsersComponent } from './console-users/console-users.component';
import { CountryWiseEducationalInstitutionComponent } from './country-wise-educational-institution/country-wise-educational-institution.component';
import { AppDevelopmentConsoleForCustomAppsComponent } from './custom-apps/app-development-console-for-custom-apps/app-development-console-for-custom-apps.component';
import { CustomAppsComponent } from './custom-apps/custom-apps.component';

const routes: Routes = [
  {
    path: '',
    component: AppDevelopmentConsoleComponent,
    canActivate: [AuthGuard],

    children: [
      { path: '', component: CountryWiseEducationalInstitutionComponent },

      {
        path: 'county-wise-educational-institution',
        component: CountryWiseEducationalInstitutionComponent,
      },
      { path: 'apps-for-all-users', component: AppsForAllUsersComponent },
      { path: 'custom-apps', component: CustomAppsComponent },
      { path: 'apps-for-getster', component: AppsForGetstersComponent },
      { path: 'console-user', component: ConsoleUsersComponent },
      {
        path: 'common-data-for-user-apps',
        component: CommonDataForUserAppsComponent,
      },
      {
        path: 'app-development-console-user-apps-add/:type',
        component: AppDevelopmentConsoleForUserAppsComponent,
      },
      {
        path: 'app-development-console-user-apps-edit/:id/:name/:type',
        component: AppDevelopmentConsoleForUserAppsComponent,
      },

      {
        path: 'app-development-console-getster-apps-add/:type',
        component: AppDevelopmentConsoleForGetsterAppsComponent,
      },
      {
        path: 'app-development-console-getster-apps-edit/:id/:name/:type',
        component: AppDevelopmentConsoleForGetsterAppsComponent,
      },
      {
        path: 'app-development-console-custom-add/:type',
        component: AppDevelopmentConsoleForCustomAppsComponent,
      },
      {
        path: 'app-development-console-custom-edit/:id/:name/:type',
        component: AppDevelopmentConsoleForCustomAppsComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AppDevelopmentConsoleRoutingModule {}
