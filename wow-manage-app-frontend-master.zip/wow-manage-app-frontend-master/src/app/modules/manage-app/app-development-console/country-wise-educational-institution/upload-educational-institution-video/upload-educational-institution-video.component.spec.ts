/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { UploadEducationalInstitutionVideoComponent } from './upload-educational-institution-video.component';

describe('UploadEducationalInstitutionVideoComponent', () => {
  let component: UploadEducationalInstitutionVideoComponent;
  let fixture: ComponentFixture<UploadEducationalInstitutionVideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadEducationalInstitutionVideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadEducationalInstitutionVideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
