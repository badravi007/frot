import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
  NgForm,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { EducationalInstitutionsCategoryService } from 'src/app/shared/services/app-development-console/educational-institutions-category.service';
import { CountryStateCityService } from 'src/app/shared/services/country-state-city/country-state-city.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';

interface Country {
  shortName: string;
  name: string;
  native: string;
  phone: string;
  continent: string;
  capital: string;
  currency: string;
  languages: string[];
  emoji: string;
  emojiU: string;
}

@Component({
  selector: 'app-country-wise-educational-institution',
  templateUrl: './country-wise-educational-institution.component.html',
  styleUrls: ['./country-wise-educational-institution.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CountryWiseEducationalInstitutionComponent implements OnInit {
  @ViewChild('contactForm') public contactForm: NgForm;

  institutionForm: UntypedFormGroup;
  countries: Country[];
  states: string[];
  cities: string[];
  formValues: any;

  filteredCountries: any;
  filteredStates: any;

  selectedCategoryIds: any;
  timestampDescription: any;

  constructor(
    private countryService: CountryStateCityService,
    private _formBuilder: UntypedFormBuilder,
    private _headerTitle: HeaderTitleService,
    public spinner: CustomSpinnerService,
    public snackBar: SnackBarService,
    private _apiService: EducationalInstitutionsCategoryService
  ) {
    this.filteredCountries = this.countryService.getCountries();
    this.institutionForm = this._formBuilder.group({
      country: ['', Validators.required],
    });

    this.institutionForm.controls['country'].valueChanges.subscribe(
      (data: any) => {
        this.countries = this.countryService.getCountries();
        if (data !== undefined) {
          this.filteredCountries = this.countries.filter((d: any) => {
            if (d.name)
              return d?.name?.toLowerCase().includes(data.toLowerCase());
          });
        }

        if (this.institutionForm.controls['country'].valid) {
          let country = this.institutionForm.get('country').value;
          this.states = this.countryService.getStatesByCountry(country);
          this.filteredStates = this.countryService.getStatesByCountry(country);
        }
      }
    );
  }

  ngOnInit() {
    this._headerTitle.setTitle(
      'Country Wise Educational Institution Categories'
    );
  }

  // getval(selectedVal: any) {
  //   let val = selectedVal.name;
  //   debugger;
  //   this.institutionForm.setValue({
  //     country: val,
  //   });
  // }

  selected_user_app_educational_institution_category_id: any = null;
  selected_user_app_educational_institution_category_name: any = null;
  getSelectedEducationalInstitutionCategoryId(event) {
    this.selected_user_app_educational_institution_category_id =
      event.user_app_educational_institution_category_id;
    console.log(this.selected_user_app_educational_institution_category_id);
    this.selected_user_app_educational_institution_category_name =
      event.user_app_educational_institution_category_name;
  }

  selected_country_code: string;
  selected_country_name: string;
  getval(selectedVal: any) {
    this.selected_country_code = selectedVal.shortName;
    this.selected_country_name = selectedVal.name;
    this.institutionForm.controls['country'].setValue(selectedVal.name);
  }

  timeStampDetails: any;
  getTimeStampDetails(event) {
    this.timeStampDetails = event;
  }

  previewAppsList: any;
  getAppsForPreviewLocation(ids) {
    // this._apiService.getAllEducationalInstitutionCategory(ids).subscribe(
    //   (res) => {
    //     this.previewAppsList = res.data;
    //     this.snackBar.success(res.message);
    //     this.loader.close();
    //   },
    //   (err) => {
    //     this.loader.close();
    //     this.snackBar.error(err.error.text);
    //   }
    // );
  }

  error_message: string = '';
  isValid() {
    if (!this.institutionForm.valid) {
      return true;
    } else if (
      this.selected_user_app_educational_institution_category_id == null
    ) {
      this.error_message = 'App Icon Required.';
      return true;
    } else if (this.selected_country_code == null) {
      this.error_message = 'App Icon Required.';
      return true;
    } else {
      this.error_message = '';
      return false;
    }
  }

  onSubmit() {
    let formData: FormData = new FormData();
    formData.append('country_code', this.selected_country_code);

    formData.append(
      'user_app_educational_institution_category_id',
      this.selected_user_app_educational_institution_category_id
    );
    formData.append(
      'file_name_of_video',
      this.timeStampDetails.fileNameOfVideo
    );
    formData.append(
      'user_app_educational_institution_category_demo_video_file',
      this.timeStampDetails
        .user_app_educational_institution_category_demo_video_file
    );

    formData.append(
      'user_app_educational_institution_category_description_datetime',
      JSON.stringify(
        this.timeStampDetails
          .user_app_educational_institution_category_description_datetime
      )
    );

    this.spinner.open();
    this._apiService
      .addDemoVideoForEducationalInstitutionsCategory(formData)
      .subscribe(
        (res) => {
          if (res['status'] === 200) {
            this.snackBar.success(res.message);
            this.spinner.close();
          }
        },
        (err) => {
          this.spinner.close();
          this.snackBar.error(err.error);
        }
      );
  }
}
