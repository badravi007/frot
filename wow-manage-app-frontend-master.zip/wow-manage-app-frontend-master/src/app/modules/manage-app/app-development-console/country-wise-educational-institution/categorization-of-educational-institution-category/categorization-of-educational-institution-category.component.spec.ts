/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CategorizationOfEducationalInstitutionCategoryComponent } from './categorization-of-educational-institution-category.component';

describe('CategorizationOfEducationalInstitutionCategoryComponent', () => {
  let component: CategorizationOfEducationalInstitutionCategoryComponent;
  let fixture: ComponentFixture<CategorizationOfEducationalInstitutionCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategorizationOfEducationalInstitutionCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategorizationOfEducationalInstitutionCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
