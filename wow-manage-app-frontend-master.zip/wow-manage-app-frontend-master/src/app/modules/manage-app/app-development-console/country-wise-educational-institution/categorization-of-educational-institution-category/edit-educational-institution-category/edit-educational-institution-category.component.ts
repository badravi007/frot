import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';

import {
  EducationalInstitutionsCategoryDialogData,
  EducationalInstitutionsCategoryData,
} from 'src/app/models/educational-institutions-category.interface';

@Component({
  selector: 'app-edit-educational-institution-category',
  template: `
    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons edit-btn"
      (click)="openDialog()"
    >
      <mat-icon> edit </mat-icon>
    </button>
  `,
  styles: [
    `
      .edit-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 90%; */
        /* font-size: 18px; */
      }
      /* */
    `,
  ],
})
export class EditEducationalInstitutionCategoryComponent {
  @Input() isTop: boolean;
  @Input() currentNode: EducationalInstitutionsCategoryData;
  @Input() isDisabled: boolean;
  @Output() edittedNode = new EventEmitter();

  constructor(public dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(
      EditInstitutionCategoryReassignCheckboxDialog,
      {
        disableClose: true,
        width: '400px',
        minHeight: 'calc(100vh - 700px)',
        data: {
          user_app_educational_institution_category_name:
            this.currentNode.user_app_educational_institution_category_name,
          Component: 'Edit',
          parent: this.currentNode,
          isTop: this.isTop,
        },
      }
    );
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const node: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            this.currentNode.user_app_educational_institution_category_id,
          parent_user_app_educational_institution_category_id:
            this.currentNode
              .parent_user_app_educational_institution_category_id,
          user_app_educational_institution_category_name:
            result.user_app_educational_institution_category_name,
          is_user_app_educational_institution_category_hidden:
            this.currentNode
              .is_user_app_educational_institution_category_hidden,
          children: this.currentNode.children,
          user_app_educational_institution_category_type: '0',
        };
        this.edittedNode.emit({ currentNode: this.currentNode, node: node });
      }
    });
  }
}

@Component({
  selector: 'edit-educational-institution-category-dialog',
  templateUrl:
    '../educational-institution-category-dialog/educational-institution-category-dialog.component.html',
})
export class EditInstitutionCategoryReassignCheckboxDialog {
  constructor(
    public dialogRef: MatDialogRef<EditInstitutionCategoryReassignCheckboxDialog>,
    @Inject(MAT_DIALOG_DATA)
    public data: EducationalInstitutionsCategoryDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
