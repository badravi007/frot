import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  EducationalInstitutionsCategoryDialogData,
  EducationalInstitutionsCategoryData,
} from 'src/app/models/educational-institutions-category.interface';
import { CustomIdGeneratorService } from 'src/app/shared/services/custom-id-generator/custom-id-generator.service';

@Component({
  selector: 'app-add-educational-institution-category',
  template: `
    <button
      mat-raised-button
      class="primary-button"
      (click)="openDialog()"
      *ngIf="isTop"
    >
      Add Parent Category
    </button>

    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons add-btn"
      *ngIf="!isTop"
      (click)="openDialog()"
    >
      <mat-icon>add </mat-icon>
    </button>
  `,
  styles: [
    `
      /* .top-node {
      position: absolute;
      left: 12px;
      margin-left: 4px;
    }
    */

      .add-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 95%; */
        /* margin-top: -5px; */
      }
    `,
  ],
})
export class AddEducationalInstitutionCategoryComponent {
  @Input() isTop: boolean;
  @Input() currentNode: EducationalInstitutionsCategoryData;
  @Output() addedNode = new EventEmitter();
  @Input() isDisabled: boolean;
  name: string;
  description: string;

  constructor(
    public dialog: MatDialog,
    private customIdGenerate: CustomIdGeneratorService
  ) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(
      AddInstitutionCategoryReassignCheckboxDialog,
      {
        disableClose: true,
        width: '400px',
        minHeight: 'calc(100vh - 700px)',
        data: {
          user_app_educational_institution_category_name: this.name,
          Component: 'Add',
          parent: this.currentNode,
          isTop: this.isTop,
        },
      }
    );
    dialogRef.afterClosed().subscribe((result) => {
      // console.log(this.currentNode);
      if (result) {
        const node: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            this.customIdGenerate.CustomNanoId(),
          parent_user_app_educational_institution_category_id: null,
          user_app_educational_institution_category_name:
            result.user_app_educational_institution_category_name,
          children: [],
          is_user_app_educational_institution_category_hidden: false,
          user_app_educational_institution_category_type: '0',
        };
        if (this.isTop) {
          this.addedNode.emit(node);
        } else {
          const node2: EducationalInstitutionsCategoryData = {
            country_code: 'in',
            user_app_educational_institution_category_id:
              this.customIdGenerate.CustomNanoId(),
            parent_user_app_educational_institution_category_id:
              this.currentNode.user_app_educational_institution_category_id,
            user_app_educational_institution_category_name:
              result.user_app_educational_institution_category_name,
            children: [],
            is_user_app_educational_institution_category_hidden: false,
            user_app_educational_institution_category_type: '0',
          };
          this.addedNode.emit({ currentNode: this.currentNode, node: node2 });
        }
      }
    });
  }
}

@Component({
  selector: 'add-educational-institution-category-dialog',
  templateUrl:
    '../educational-institution-category-dialog/educational-institution-category-dialog.component.html',
})
export class AddInstitutionCategoryReassignCheckboxDialog {
  constructor(
    public dialogRef: MatDialogRef<AddInstitutionCategoryReassignCheckboxDialog>,
    @Inject(MAT_DIALOG_DATA)
    public data: EducationalInstitutionsCategoryDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
