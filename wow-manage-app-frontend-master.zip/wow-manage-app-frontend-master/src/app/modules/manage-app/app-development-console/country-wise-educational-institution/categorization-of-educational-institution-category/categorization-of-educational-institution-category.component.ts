import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  EventEmitter,
  Inject,
  Input,
  Output,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import {
  EducationalInstitutionsCategoryDialogData,
  EducationalInstitutionsCategoryData,
} from 'src/app/models/educational-institutions-category.interface';
import { EducationalInstitutionsCategoryService } from 'src/app/shared/services/app-development-console/educational-institutions-category.service';
import { UserAppService } from 'src/app/shared/services/app-development-console/user-app.service';
import { DataSharingService } from 'src/app/shared/services/data-sharing/data-sharing.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';

@Component({
  selector: 'app-categorization-of-educational-institution-category',
  templateUrl:
    './categorization-of-educational-institution-category.component.html',
  styleUrls: [
    './categorization-of-educational-institution-category.component.scss',
  ],
})
export class CategorizationOfEducationalInstitutionCategoryComponent
  implements OnInit
{
  @ViewChild('tree') tree: ElementRef;

  hiddenCategories: boolean = false;

  users_list: any[] = [];
  selected_users_list_val: any = null;
  selected_category_name_val: any = null;

  constructor(
    private _apiService: EducationalInstitutionsCategoryService,
    private _headerTitle: HeaderTitleService,
    public dialog: MatDialog,
    public snackBarService: SnackBarService,
    public dataSharingService: DataSharingService
  ) {}

  nestedTreeControl: NestedTreeControl<EducationalInstitutionsCategoryData>;
  nestedDataSource: MatTreeNestedDataSource<EducationalInstitutionsCategoryData>;
  treeNodeSelection = new SelectionModel<EducationalInstitutionsCategoryData>(
    true /* multiple */
  );

  ngOnInit() {
    this._headerTitle.setTitle(
      'Country Wise Educational Institution Categories'
    );

    this.nestedTreeControl =
      new NestedTreeControl<EducationalInstitutionsCategoryData>(
        this._getChildren
      );
    this.nestedDataSource = new MatTreeNestedDataSource();

    this._apiService.getAllEducationalInstitutionCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;
    });
  }

  private _transformer = (
    node: EducationalInstitutionsCategoryData,
    level: number
  ) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.user_app_educational_institution_category_name,
      level: level,
    };
  };

  private _getChildren = (node: EducationalInstitutionsCategoryData) =>
    of(node.children);

  hasNestedChild = (_: string, nodeData: EducationalInstitutionsCategoryData) =>
    nodeData.children.length > 0;

  refreshEducationalInstitutionsCategoryData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  currentNodeVal: any;

  currentNodes(val: any) {
    console.log(val);

    this.currentNodeVal = val;
  }

  @Output() getSelectedEducationalInstitutionCategoryId = new EventEmitter();
  onCategorySelection() {
    this.getSelectedEducationalInstitutionCategoryId.emit(
      this.selected_category_name_val
    );
  }

  addNode(node: EducationalInstitutionsCategoryData) {
    // this.nestedTreeControl.isExpanded(node);

    let api_data: EducationalInstitutionsCategoryData = {
      country_code: 'in',
      user_app_educational_institution_category_id:
        node.user_app_educational_institution_category_id,
      parent_user_app_educational_institution_category_id:
        node.parent_user_app_educational_institution_category_id,
      user_app_educational_institution_category_name:
        node.user_app_educational_institution_category_name,
      is_user_app_educational_institution_category_hidden: '0',
      children: node.children,
      user_app_educational_institution_category_type: '0',
    };
    this._apiService
      .addEducationalInstitutionCategory(api_data)
      .subscribe((res) => {
        if (res['status'] === 200) {
          let data: EducationalInstitutionsCategoryData = {
            country_code: 'in',
            user_app_educational_institution_category_id:
              node.user_app_educational_institution_category_id,
            parent_user_app_educational_institution_category_id:
              node.parent_user_app_educational_institution_category_id,
            user_app_educational_institution_category_name:
              node.user_app_educational_institution_category_name,
            is_user_app_educational_institution_category_hidden: 0,
            children: node.children,
            user_app_educational_institution_category_type: '0',
          };
          this.nestedDataSource.data.push(data);
          this.refreshEducationalInstitutionsCategoryData();
        }
      });
  }

  addChildNode(childrenNodeData: {
    currentNode: { children: any[] };
    node: any;
  }) {
    this._apiService
      .checkIsAssignedUserAppCategory(
        childrenNodeData.node.user_app_educational_institution_category_id
      )
      .subscribe((res) => {
        console.log(res.userIsAssigned);
        const userIsAssigned = res.userIsAssigned;
        if (userIsAssigned) {
          if (
            confirm(
              'If you wish to create a sub category to the parent category where users / apps are assigned,the same shall be reassigned to this new sub category: ' +
                childrenNodeData.node
                  .user_app_educational_institution_category_name +
                '. \nDo you wish to proceed ? '
            ) === true
          ) {
            this._apiService
              .addEducationalInstitutionCategory(childrenNodeData.node)
              .subscribe((res) => {
                if (res['status'] === 200) {
                  let data = {
                    parent_data: childrenNodeData.currentNode,
                    child_data: childrenNodeData.node,
                  };
                  // this._apiService
                  //   .passingUsersParentToChild(data)
                  //   .subscribe((res) => {
                  //     if (res['status'] == 200) {
                  //       // res.OK call the refresh tree method
                  //       childrenNodeData.currentNode.children.push(
                  //         childrenNodeData.node
                  //       );
                  //       this.refreshEducationalInstitutionsCategoryData();
                  //       this.loadAssignedCategoryData();
                  //     }
                  //   });
                }
              });
          }
        } else {
          this._apiService
            .addEducationalInstitutionCategory(childrenNodeData.node)
            .subscribe((res) => {
              if (res['status'] === 200) {
                childrenNodeData.currentNode.children.push(
                  childrenNodeData.node
                );
                this.refreshEducationalInstitutionsCategoryData();
              }
            });
        }
      });
  }

  editNode(nodeToBeEdited: {
    node: EducationalInstitutionsCategoryData;
    currentNode: { category_id: string };
  }) {
    console.log('edit node', nodeToBeEdited.node);

    this._apiService
      .updateEducationalInstitutionCategory(nodeToBeEdited.node)
      .subscribe((res) => {
        if (res['status'] === 200) {
          const fatherElement: EducationalInstitutionsCategoryData | any =
            this.findFatherNode(
              nodeToBeEdited.currentNode.category_id,
              this.nestedDataSource.data
            );
          let elementPosition: number;
          if (fatherElement[0]) {
            fatherElement[0].children[fatherElement[1]] = nodeToBeEdited.node;
          } else {
            elementPosition = this.findPosition(
              nodeToBeEdited.currentNode.category_id,
              this.nestedDataSource.data
            );
            this.nestedDataSource.data[elementPosition] = nodeToBeEdited.node;
          }
          this.refreshEducationalInstitutionsCategoryData();
        }
      });
  }

  deleteNode(nodeToBeDeleted: EducationalInstitutionsCategoryData) {
    console.log('delete node', nodeToBeDeleted);

    const deletedElement: EducationalInstitutionsCategoryData | any =
      this.findFatherNode(
        nodeToBeDeleted.user_app_educational_institution_category_id,
        this.nestedDataSource.data
      );
    let elementPosition: number;

    if (
      nodeToBeDeleted.is_user_app_educational_institution_category_hidden == 1
    ) {
      let confirm_text_1 =
        'Are you sure you want to Unhide \nParent Category: ' +
        nodeToBeDeleted.user_app_educational_institution_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Unhide \nSub Category: ' +
        nodeToBeDeleted.user_app_educational_institution_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_user_app_educational_institution_category_id ==
            null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            nodeToBeDeleted.user_app_educational_institution_category_id,
          parent_user_app_educational_institution_category_id:
            nodeToBeDeleted.parent_user_app_educational_institution_category_id,
          user_app_educational_institution_category_name:
            nodeToBeDeleted.user_app_educational_institution_category_name,
          is_user_app_educational_institution_category_hidden: '0',
          children: nodeToBeDeleted.children,
          user_app_educational_institution_category_type: '0',
        };

        let data: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            nodeToBeDeleted.user_app_educational_institution_category_id,
          parent_user_app_educational_institution_category_id:
            nodeToBeDeleted.parent_user_app_educational_institution_category_id,
          user_app_educational_institution_category_name:
            nodeToBeDeleted.user_app_educational_institution_category_name,
          is_user_app_educational_institution_category_hidden: 0,
          children: nodeToBeDeleted.children,
          user_app_educational_institution_category_type: '0',
        };

        this._apiService
          .hideEducationalInstitutionCategory(apidata)
          .subscribe((res) => {
            if (res['status'] === 200) {
              const fatherElement: EducationalInstitutionsCategoryData | any =
                this.findFatherNode(
                  nodeToBeDeleted.user_app_educational_institution_category_id,
                  this.nestedDataSource.data
                );
              let elementPosition: number;
              if (fatherElement[0]) {
                fatherElement[0].children[fatherElement[1]] = data;
              } else {
                elementPosition = this.findPosition(
                  nodeToBeDeleted.user_app_educational_institution_category_id,
                  this.nestedDataSource.data
                );
                this.nestedDataSource.data[elementPosition] = data;
              }
              this.refreshEducationalInstitutionsCategoryData();
            }
          });
      }
    } else if (
      nodeToBeDeleted.is_user_app_educational_institution_category_hidden == 0
    ) {
      let confirm_text_1 =
        'Are you sure you want to Hide \nParent Category: ' +
        nodeToBeDeleted.user_app_educational_institution_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Hide \nSub Category: ' +
        nodeToBeDeleted.user_app_educational_institution_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_user_app_educational_institution_category_id ==
            null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            nodeToBeDeleted.user_app_educational_institution_category_id,
          parent_user_app_educational_institution_category_id:
            nodeToBeDeleted.parent_user_app_educational_institution_category_id,
          user_app_educational_institution_category_name:
            nodeToBeDeleted.user_app_educational_institution_category_name,
          is_user_app_educational_institution_category_hidden: '1',
          children: nodeToBeDeleted.children,
          user_app_educational_institution_category_type: '0',
        };

        let data: EducationalInstitutionsCategoryData = {
          country_code: 'in',
          user_app_educational_institution_category_id:
            nodeToBeDeleted.user_app_educational_institution_category_id,
          parent_user_app_educational_institution_category_id:
            nodeToBeDeleted.parent_user_app_educational_institution_category_id,
          user_app_educational_institution_category_name:
            nodeToBeDeleted.user_app_educational_institution_category_name,
          is_user_app_educational_institution_category_hidden: 1,
          children: nodeToBeDeleted.children,
          user_app_educational_institution_category_type: '0',
        };

        // console.log(nodeToBeDeleted);
        this._apiService
          .checkIsAssignedUserAppCategory(nodeToBeDeleted)
          .subscribe((res) => {
            console.log(res.userIsAssigned);
            const userIsAssigned = res.userIsAssigned;
            if (userIsAssigned) {
              alert(
                'Users are present in this category! \n To hide kindly reassign the user to another category'
              );
              this.openUserReassignDialog(nodeToBeDeleted);
            } else {
              this._apiService
                .hideEducationalInstitutionCategory(apidata)
                .subscribe((res) => {
                  if (res['status'] === 200) {
                    const fatherElement:
                      | EducationalInstitutionsCategoryData
                      | any = this.findFatherNode(
                      nodeToBeDeleted.user_app_educational_institution_category_id,
                      this.nestedDataSource.data
                    );
                    let elementPosition: number;
                    if (fatherElement[0]) {
                      fatherElement[0].children[fatherElement[1]] = data;
                    } else {
                      elementPosition = this.findPosition(
                        nodeToBeDeleted.user_app_educational_institution_category_id,
                        this.nestedDataSource.data
                      );
                      this.nestedDataSource.data[elementPosition] = data;
                    }
                    this.refreshEducationalInstitutionsCategoryData();
                  }
                });
            }
          });

        // if (condition) {

        // }
      }
    }
  }

  openUserReassignDialog(nodeToBeDeleted: EducationalInstitutionsCategoryData) {
    // this.dialog.open(UserReassignDialogComponent, {
    //   disableClose: true,
    //   width: '400px',
    //   minHeight: 'calc(100vh - 700px)',
    //   data: nodeToBeDeleted,
    // });
  }
  // Tree Functions
  flatJsonArray(
    flattenedAray: Array<EducationalInstitutionsCategoryData>,
    node: EducationalInstitutionsCategoryData[]
  ) {
    const array: Array<EducationalInstitutionsCategoryData> = flattenedAray;
    node.forEach((element) => {
      if (element.children) {
        array.push(element);
        this.flatJsonArray(array, element.children);
      }
    });
    return array;
  }

  findNodeMaxId(node: EducationalInstitutionsCategoryData[]) {
    const flatArray = this.flatJsonArray([], node);
    const flatArrayWithoutChildren: any[] = [];
    flatArray.forEach((element) => {
      flatArrayWithoutChildren.push(
        element.user_app_educational_institution_category_id
      );
    });
    return Math.max(...flatArrayWithoutChildren);
  }

  findPosition(id: string, data: EducationalInstitutionsCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      if (id === data[i].user_app_educational_institution_category_id) {
        return i;
      }
    }
    return null;
  }

  findFatherNode(
    user_app_educational_institution_category_id: string,
    data: EducationalInstitutionsCategoryData[]
  ) {
    for (let i = 0; i < data.length; i += 1) {
      const currentFather = data[i];
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (
          user_app_educational_institution_category_id ===
          currentFather.children[z][
            'user_app_educational_institution_category_id'
          ]
        ) {
          return [currentFather, z];
        }
      }
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (
          user_app_educational_institution_category_id !==
          currentFather.children[z][
            'user_app_educational_institution_category_id'
          ]
        ) {
          const result: any = this.findFatherNode(
            user_app_educational_institution_category_id,
            currentFather.children
          );
          if (result !== false) {
            return result;
          }
        }
      }
    }
    return false;
  }

  radiobtnval(node: EducationalInstitutionsCategoryData) {
    console.log(node);
  }

  getLevel = (node: EducationalInstitutionsCategoryData) => node.level;

  isExpandable = (node: EducationalInstitutionsCategoryData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: EducationalInstitutionsCategoryData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_user_app_educational_institution_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(
    node: EducationalInstitutionsCategoryData
  ): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.treeNodeSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: EducationalInstitutionsCategoryData): void {
    this.treeNodeSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.treeNodeSelection.isSelected(node)
      ? this.treeNodeSelection.select(...descendants)
      : this.treeNodeSelection.deselect(...descendants);
    console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.treeNodeSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: EducationalInstitutionsCategoryData): void {
    console.log(node);
    this.treeNodeSelection.toggle(node);
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: EducationalInstitutionsCategoryData): void {
    let parent: EducationalInstitutionsCategoryData | null =
      this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: EducationalInstitutionsCategoryData): void {
    const nodeSelected = this.treeNodeSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.treeNodeSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.treeNodeSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.treeNodeSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(
    node: EducationalInstitutionsCategoryData
  ): EducationalInstitutionsCategoryData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl.dataNodes.indexOf(node) - 1;
    console.log(startIndex);

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  assignCategory() {
    if (this.selected_category_name_val && this.selected_users_list_val) {
      // console.log(this.selected_users_list_val);
      // console.log(this.selected_category_name_val);
      let data = {
        user_app_educational_institution_category_id:
          this.selected_category_name_val
            .user_app_educational_institution_category_id,
        category_parent_id:
          this.selected_category_name_val
            .parent_user_app_educational_institution_category_id,
        category_name: this.selected_category_name_val.category_name,
        user_id: this.selected_users_list_val.user_id,
        user_name: this.selected_users_list_val.name,
      };
      // this._apiService.assign_category(data).subscribe((res) => {
      //   // console.log(res);
      //   this.snackBarService.success(res.message);
      //   this.loadAssignedCategoryData();
      // });
    }
  }

  // loadAssignedCategoryData() {
  //   this._apiService.get_assigned_category().subscribe((res) => {
  //     this.dataSharingService.updateAssignedCategoryData(res[0]);
  //   });
  // }
}
