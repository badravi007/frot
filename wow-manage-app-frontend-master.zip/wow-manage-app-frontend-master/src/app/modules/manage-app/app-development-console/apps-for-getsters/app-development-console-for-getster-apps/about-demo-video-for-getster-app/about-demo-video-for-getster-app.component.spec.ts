/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AboutDemoVideoForGetsterAppComponent } from './about-demo-video-for-getster-app.component';

describe('AboutDemoVideoForGetsterAppComponent', () => {
  let component: AboutDemoVideoForGetsterAppComponent;
  let fixture: ComponentFixture<AboutDemoVideoForGetsterAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutDemoVideoForGetsterAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutDemoVideoForGetsterAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
