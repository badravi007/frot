import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { UtcTimeService } from 'src/app/shared/util/utc-time.service';

@Component({
  selector: 'app-getster-app-communication',
  templateUrl: './getster-app-communication.component.html',
  styleUrls: ['./getster-app-communication.component.scss'],
})
export class GetsterAppCommunicationComponent implements OnInit {
  communicationFormGroup: FormGroup;
  constructor(
    private _GETsterAppService: GetsterAppService,
    private loader: CustomSpinnerService,
    private snackBar: SnackBarService,
    private fb: FormBuilder
  ) {}

  @Input() getster_app_id: number;

  ngOnInit() {
    this.communicationFormGroup = this.fb.group({
      app_notification: new FormControl(''),
      app_comments: new FormControl(''),
    });
    this.getGetsterAppCommunication();
  }

  communicationList: any = [];

  getGetsterAppCommunication() {
    this._GETsterAppService
      .getGetsterAppCommunication(this.getster_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.success(res.message);
          this.resetCommentsForm();
          this.communicationList = res.data;
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  deleteGetsterAppCommunication(communication_id) {
    this._GETsterAppService
      .deleteGetsterAppCommunication(this.getster_app_id, communication_id)
      .subscribe(
        (res) => {
          this.getGetsterAppCommunication();
          this.loader.close();
          this.snackBar.success(res.message);
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  addGetsterAppCommunication() {
    let message = this.communicationFormGroup.value.app_notification;
    let body = {
      getster_id: localStorage.getItem('getster_id'),
      communication_text: message,
    };

    this._GETsterAppService
      .addGetsterAppCommunication(this.getster_app_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.success(res.message);
          this.getGetsterAppCommunication();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  resetCommentsForm() {
    this.communicationFormGroup.reset();
  }
}
