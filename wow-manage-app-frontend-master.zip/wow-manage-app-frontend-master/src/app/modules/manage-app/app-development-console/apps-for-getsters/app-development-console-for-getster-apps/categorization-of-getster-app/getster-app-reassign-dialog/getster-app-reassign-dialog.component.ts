import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
// import * as _ from 'lodash';
import { DataSharingService } from 'src/app/shared/services/data-sharing/data-sharing.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
// import { UserCategoryManagementService } from 'src/app/shared/services/user-category-management/user-category-management.service';

@Component({
  selector: 'app-user-reassign-dialog',
  template: `<div class="custom-dialog-header-body">
    <mat-toolbar
      class="component--dialog-box__custom-toolbar component--mat-dialog-heading"
    >
      <mat-label class="text-sm font-[550]">
        <span
          class="sm:block gt-sm:hidden"
          matTooltip="Reassign user from one category to another"
          >{{
            'Reassign user from one category to another' | ellipsis : 30
          }}</span
        >
        <span class="gt-sm:block lt-sm:hidden"
          >Reassign category to another</span
        >
      </mat-label>
      <span class="example-spacer"></span>
      <button mat-icon-button class="flex items-center justify-center">
        <mat-icon (click)="onNoClick()">close</mat-icon>
      </button>
    </mat-toolbar>
    <!-- Content -->
    <section
      class="px-[10px] py-0 flex flex-col overflow-hidden"
      mat-dialog-content
    >
      <div>
        <div>
          {{ data?.nodeToBeDeleted?.getster_app_category_name }} is assigned in
          this category
        </div>
        <div class="flex justify-center">
          <mat-form-field
            appearance="outline"
            class="w-full gt-sm:w-[70%] component--mat-form-field__custom-input"
          >
            <mat-select
              placeholder="Select Category"
              [(ngModel)]="selected_catgory_val"
              name="item"
            >
              <ng-container *ngFor="let item of categories_list">
                <mat-option
                  *ngIf="item.is_the_getster_app_category_hidden == 0"
                  [value]="item"
                >
                  {{ item.getster_app_category_name }}
                </mat-option>
              </ng-container>
            </mat-select>
          </mat-form-field>
        </div>
        <div class="flex justify-center">
          <button
            mat-raised-button
            class="text-white rounded-[15px] bg-[#ff3333]"
            color="warn"
            (click)="onNoClick()"
            style="position: relative; right: 15px"
          >
            Cancel
          </button>
          <button
            mat-raised-button
            class="text-white rounded-[15px] bg-[#3366ff]"
            [disabled]="!selected_catgory_val"
            style="position: relative; left: 20px"
            (click)="reassignCategory()"
          >
            Reassign Category
          </button>
        </div>
      </div>
    </section>
  </div> `,
  styles: [],
})
export class GetsterAppReassignDialogComponent {
  user_details: any;
  categories_list: any[] = [];
  selected_catgory_val: any;
  constructor(
    public dialogRef: MatDialogRef<GetsterAppReassignDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    // private _apiService: UserCategoryManagementService,
    private _apiService: GetsterAppService,
    public snackBarService: SnackBarService,
    private datasharingService: DataSharingService
  ) {
    data.tree_data.forEach((node: any) => {
      this.callRecursively(node);
    });
  }

  callRecursively(node: any) {
    if (node.children.length === 0) {
      if (
        node.getster_app_category_id !==
        this.data.nodeToBeDeleted.getster_app_category_id
      ) {
        this.categories_list.push(node);
      }
      // // this.todoLeafItemSelectionToggle(node);
      // this.expand(this.nestedDataSource.data, this.search_user_app_category_id);
    }
    if (node.children) {
      node.children.forEach((childNode: any) => {
        this.callRecursively(childNode);
      });
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  reassignCategory() {
    if (this.selected_catgory_val) {
      // console.log(this.data.nodeToBeDeleted.getster_category_id);
      // console.log(this.selected_catgory_val.getster_category_id);

      let existing_getster_app_category_id =
        this.data.nodeToBeDeleted.getster_app_category_id;
      let new_getster_app_category_id =
        this.selected_catgory_val.getster_app_category_id;
      this._apiService
        .reassignGetsterAppCategory(
          existing_getster_app_category_id,
          new_getster_app_category_id
        )
        .subscribe((res) => {
          this.dialogRef.close(true);
        });
    }
  }
}
