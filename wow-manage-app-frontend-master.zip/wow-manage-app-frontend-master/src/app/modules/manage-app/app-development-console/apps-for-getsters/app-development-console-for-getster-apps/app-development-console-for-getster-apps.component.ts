import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { StepperOrientation } from '@angular/cdk/stepper';
import {
  ChangeDetectorRef,
  Component,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { GlobalConstants } from 'src/app/shared/util/global-constants';
import { CategorizationOfGetsterAppComponent } from './categorization-of-getster-app/categorization-of-getster-app.component';

@Component({
  selector: 'app-app-development-console-for-getster-apps',
  templateUrl: './app-development-console-for-getster-apps.component.html',
  styleUrls: ['./app-development-console-for-getster-apps.component.scss'],
})
export class AppDevelopmentConsoleForGetsterAppsComponent implements OnInit {
  @ViewChild('getsterCategory')
  getsterCategory: CategorizationOfGetsterAppComponent;
  isLinear = false;

  appFormGroup!: UntypedFormGroup;

  getster_app_id: any;
  getster_app_name: string;
  getster_app_type: string;

  selected_getster_app_category_id: string = null;

  constructor(
    private _formBuilder: UntypedFormBuilder,
    private cdr: ChangeDetectorRef,
    private _GETsterAppService: GetsterAppService,
    private router: Router,
    private loader: CustomSpinnerService,
    private snackBar: SnackBarService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private _headerTitle: HeaderTitleService
  ) {
    this.appFormGroup = this._formBuilder.group({
      getster_app_full_name: ['', Validators.required],
      getster_app_icon_name: ['', Validators.required],
    });
    this.getScreenSize();

    this.getster_app_id = this.route.snapshot.params['id'];
    this.getster_app_name = this.route.snapshot.params['name'];
    this.getster_app_type = this.route.snapshot.params['type'];

    // console.log(this.getster_app_type);

    if (this.getster_app_type == 'Add') {
    } else if (this.getster_app_type == 'Edit') {
      this.getGetsterAppById();
    }
  }

  ngOnInit() {
    this._headerTitle.setTitle('Apps for GETSTERs');
  }

  scrHeight: any;
  scrWidth: any;
  orientation: StepperOrientation = 'vertical';
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?: any) {
    this.scrHeight = window.innerHeight;
    this.scrWidth = window.innerWidth;
    if (this.scrWidth <= '768') {
      this.orientation = 'vertical';
    } else {
      this.orientation = 'horizontal';
    }
  }

  fileToUpload: any;
  imageUrl: any = null;
  handleFileInput(event) {
    this.fileToUpload = event.target.files.item(0);
    //Show image preview
    let reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
      this.cdr.markForCheck();
    };
    reader.readAsDataURL(this.fileToUpload);
  }

  error_message: string = '';
  isValid() {
    if (!this.appFormGroup.valid) {
      return true;
    } else if (this.imageUrl == null) {
      this.error_message = 'App Icon Required.';
      return true;
    } else {
      this.error_message = '';
      return false;
    }
  }

  //Api Stepper 1
  getsterappImage;
  getsterAppList: any;
  getster_app_development_status: any = 0;
  userAppCategoryId: string;
  getGetsterAppById() {
    // this.loader.open();
    this._GETsterAppService.getGetsterAppById(this.getster_app_id).subscribe(
      (res) => {
        this.getsterAppList = res;
        this.appFormGroup.setValue({
          getster_app_full_name:
            this.getsterAppList.data[0].getster_app_full_name,
          getster_app_icon_name:
            this.getsterAppList.data[0].getster_app_icon_name,
        });

        this.getster_app_development_status =
          this.getsterAppList.data[0].getster_app_development_status;

        this.getsterappImage =
          this.getsterAppList.data[0].getster_app_icon_image;

        // this.userAppCategoryId = this.getsterAppList.data[0]?.userAppCategoryId;

        this.getFileGetsterAppMaster(
          this.getsterAppList.data[0].getster_app_icon_image
        );
        this.snackBar.success(res.message);
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  constants: any = GlobalConstants;
  previewAppsList: any;
  getAppsForPreviewLocation(ids) {
    this._GETsterAppService.getAllGetsterAppByIds(ids).subscribe(
      (res) => {
        this.previewAppsList = res.data;
        this.snackBar.success(res.message);
        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error.text);
      }
    );
  }

  drop(event: CdkDragDrop<string[]>, data) {
    moveItemInArray(data, event.previousIndex, event.currentIndex);
    for (let i = 0; i < data.length; i++) {
      if (i == event.currentIndex) {
        console.log('data' + JSON.stringify(data[i]));
        // this.updatePreviewLocation(data[i], event.currentIndex);
      } else {
        console.log('data:');
      }
    }
  }

  categorySelection() {
    this.myStepper.next();
  }

  addEditGetsterApp() {
    if (this.getster_app_type == 'Add') {
      this.insertGETsterApp();
    } else if (this.getster_app_type == 'Edit') {
      this.updateGETsterApp();
    }
  }

  insertGETsterApp() {
    let formData: FormData = new FormData();

    formData.append(
      'getster_app_icon_name',
      this.appFormGroup.value.getster_app_icon_name
    );

    formData.append(
      'getster_app_full_name',
      this.appFormGroup.value.getster_app_full_name
    );

    // formData.append(
    //   'getster_app_title_bar_name',
    //   this.appFormGroup.value.getster_app_full_name
    // );

    formData.append(
      'getster_app_development_status',
      this.getster_app_development_status
    );

    formData.append('image', this.fileToUpload);

    this.loader.open();
    this._GETsterAppService.addGetsterApp(formData).subscribe(
      (res) => {
        // console.log(res);
        this.loader.close();
        if (res.data != null) {
          this.getster_app_id = res.data.getster_app_id;
          this.getster_app_name = res.data.getster_app_icon_name;
          this.createCommentsCommunication(this.getster_app_id);
          this.getGetsterAppById();
          this.myStepper.next();
        } else {
          this.snackBar.success(res.message);
        }
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  createCommentsCommunication(user_app_id: number) {
    this._GETsterAppService
      .createCommentsCommunicationTable(user_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
        },
        (err) => {
          this.loader.close();
          this.snackBar.success(err.error);
        }
      );
  }

  updateGETsterApp() {
    let getster_app_icon_name = this.appFormGroup.value.getster_app_icon_name;
    let getster_app_full_name = this.appFormGroup.value.getster_app_full_name;
    let getster_app_title_bar_name =
      this.appFormGroup.value.getster_app_full_name;

    let formData: FormData = new FormData();
    formData.append('getster_app_id', this.getster_app_id);
    formData.append('getster_app_icon_name', getster_app_icon_name);
    formData.append('getster_app_full_name', getster_app_full_name);
    // formData.append('getster_app_title_bar_name', getster_app_title_bar_name);
    formData.append(
      'getster_app_development_status',
      this.getster_app_development_status
    );

    formData.append('image', this.fileToUpload);

    this.loader.open();
    this._GETsterAppService.updateGetsterApp(formData).subscribe(
      (res) => {
        this.snackBar.success(res.message);
        this.loader.close();
        this.myStepper.next();
      },
      (err) => {
        this.loader.close();
        this.snackBar.error(err.error);
      }
    );
  }

  getSelectedGetsterCategoryID(event) {
    // console.log(event);
    this.selected_getster_app_category_id = event;

    this.getAppsForPreviewLocation(event);
  }

  assignCategory() {
    if (this.selected_getster_app_category_id != null) {
      let body = {
        getster_app_category_id: this.selected_getster_app_category_id,
        getster_app_id: this.getster_app_id,
        getster_app_location_within_the_category_id: 0,
      };
      this._GETsterAppService.AssignGetsterCategoryToGetsterApp(body).subscribe(
        (res) => {
          this.loader.close();

          // this.getAppCategoriesByID();
          this.snackBar.success(res.message);
          this.myStepper.next();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error);
        }
      );
    }
  }

  timeStampDetails: any;
  getTimeStampDetails(event) {
    this.timeStampDetails = event;
    // console.log(event);
  }

  addGETsterAppAboutDemoVideoDescription() {
    // this.loader.open();
    let finalData = { data: this.timeStampDetails };

    let body = {
      getster_app_id: this.getster_app_id,
      getster_app_demo_video_thumb_nail_path:
        'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg',
      getster_app_demo_video_path:
        'http://media.w3.org/2010/05/sintel/trailer.mp4',
      getster_app_datetime_description: JSON.stringify(finalData),
      getster_app_attachments_path: [],
    };
    this._GETsterAppService
      .addGetsterAppAboutDemoVideoDescription(body)
      .subscribe(
        (res) => {
          this.snackBar.success(res.message);
          this.loader.close();
          this.myStepper.next();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error);
        }
      );
  }

  updateGETsterAppAboutDemoVideoDescription() {
    // this.loader.open();
    let finalData = { data: this.timeStampDetails };

    let body = {
      getster_app_id: this.getster_app_id,
      getster_app_demo_video_thumb_nail_path:
        'https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/webm.jpg',
      getster_app_demo_video_path:
        'http://media.w3.org/2010/05/sintel/trailer.mp4',
      getster_app_datetime_description: JSON.stringify(finalData),
      getster_app_attachments_path: [],
    };

    this._GETsterAppService
      .updateGetsterAppAboutDemoVideoDescription(body)
      .subscribe(
        (res) => {
          this.snackBar.success(res.message);
          this.loader.close();
          this.myStepper.next();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error);
        }
      );
  }

  activeStepper = true;
  @ViewChild('stepper') private myStepper: MatStepper;

  // *-------------------------------------------------------------------------
  getFileGetsterAppMaster(file_name) {
    this._GETsterAppService.getFileGetsterAppMaster(file_name).subscribe(
      async (res) => {
        this.imageUrl = await this.arrayBufferToBase64(res);
      },
      (err) => {
        this.snackBar.error(err.error);
      }
    );
  }

  // About video
  onNextHandleAboutVideo() {
    if (this.getster_app_type == 'Edit') {
      this.updateGETsterAppAboutDemoVideoDescription();
    } else {
      this.addGETsterAppAboutDemoVideoDescription();
    }
  }

  // ------------------------------- Helper Function --------------------
  getBase64(event, type) {
    let getFile = event.target.files.item(0);

    switch (type) {
      case 'base64': {
        return new Promise((resolve, reject) => {
          let reader = new FileReader();
          reader.onload = (event: any) => {
            resolve(event.target.result);
          };
          reader.readAsDataURL(getFile);
        });
      }

      case 'formData':
        return getFile;
    }
    // if (type == 'base64') {
    // } else if (type == 'formData') return getFile;
  }

  arrayBufferToBase64(buffer: ArrayBuffer) {
    var blob = new Blob([buffer], { type: 'blob' });
    var reader = new FileReader();
    let base64 = new Promise((reslove: any, reject: any) => {
      reader.onload = (evt: any) => {
        // let dataurl = evt.target.result;
        reslove(evt.target.result);
      };
    });
    reader.readAsDataURL(blob);
    return base64;
  }
  // !-------------------------------------------------------------------------
}
