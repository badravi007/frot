import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reassign-getster-app-category',
  templateUrl: './reassign-getster-app-category.component.html',
  styleUrls: ['./reassign-getster-app-category.component.scss'],
})
export class ReassignGetsterAppCategoryComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
