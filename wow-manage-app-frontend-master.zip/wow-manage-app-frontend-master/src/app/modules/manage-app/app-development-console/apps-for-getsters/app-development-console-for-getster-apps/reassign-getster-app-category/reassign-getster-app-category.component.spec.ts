/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ReassignGetsterAppCategoryComponent } from './reassign-getster-app-category.component';

describe('ReassignGetsterAppCategoryComponent', () => {
  let component: ReassignGetsterAppCategoryComponent;
  let fixture: ComponentFixture<ReassignGetsterAppCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReassignGetsterAppCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReassignGetsterAppCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
