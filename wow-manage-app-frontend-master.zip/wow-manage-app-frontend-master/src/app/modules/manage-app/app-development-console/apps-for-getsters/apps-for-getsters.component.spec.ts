/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppsForGetstersComponent } from './apps-for-getsters.component';

describe('AppsForGetstersComponent', () => {
  let component: AppsForGetstersComponent;
  let fixture: ComponentFixture<AppsForGetstersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppsForGetstersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppsForGetstersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
