import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  GETsterAppDialogData,
  GETsterAppCategoryData,
} from 'src/app/models/getster-app.interface';
import { CustomIdGeneratorService } from 'src/app/shared/services/custom-id-generator/custom-id-generator.service';

@Component({
  selector: 'app-delete-getster-app-category',
  template: `
    <!-- {{ btnDisable }} -->
    <button
      [disabled]="btnDisable"
      color="primary"
      mat-icon-button
      class="material-icons delete-btn"
      (click)="deleteNode()"
    >
      <ng-container>
        <mat-icon>{{
          currentNode['is_the_getster_app_category_hidden']
            ? 'visibility_off'
            : 'visibility'
        }}</mat-icon>
      </ng-container>
    </button>
  `,
  styles: [
    `
      .delete-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 85%; */
        /* font-size: 18px; */
      }
    `,
  ],
})
export class DeleteGetsterAppCategoryComponent implements OnInit {
  @Output() deletedNode = new EventEmitter();
  @Input() currentNode: GETsterAppCategoryData;
  @Input() btnDisable: any;

  ngOnInit() {}

  deleteNode() {
    this.deletedNode.emit(this.currentNode);
  }
  booleanCondition(val: any) {
    return val == 0 ? false : val == 1 ? true : null;
  }
}
