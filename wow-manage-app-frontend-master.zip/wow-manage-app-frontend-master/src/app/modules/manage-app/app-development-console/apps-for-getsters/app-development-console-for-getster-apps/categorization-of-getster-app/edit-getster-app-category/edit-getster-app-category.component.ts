import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import {
  GETsterAppDialogData,
  GETsterAppCategoryData,
} from 'src/app/models/getster-app.interface';
import { CustomIdGeneratorService } from 'src/app/shared/services/custom-id-generator/custom-id-generator.service';

@Component({
  selector: 'app-edit-getster-app-category',
  template: `
    <button
      [disabled]="isDisabled"
      color="primary"
      mat-icon-button
      class="material-icons edit-btn"
      (click)="openDialog()"
    >
      <mat-icon> edit </mat-icon>
    </button>
  `,
  styles: [
    `
      .edit-btn {
        cursor: pointer;
        /* position: fixed; */
        /* left: 90%; */
        /* font-size: 18px; */
      }
      /* */
    `,
  ],
})
export class EditGetsterAppCategoryComponent implements OnInit {
  @Input() isTop: boolean;
  @Input() currentNode: GETsterAppCategoryData;
  @Input() isDisabled: boolean;
  @Output() edittedNode = new EventEmitter();

  constructor(public dialog: MatDialog) {}

  ngOnInit() {}

  openDialog(): void {
    const dialogRef = this.dialog.open(
      GETsterAppEditDialogRadioButtonComponent,
      {
        disableClose: true,
        width: '400px',
        minHeight: 'calc(100vh - 700px)',
        data: {
          getster_app_category_name: this.currentNode.getster_app_category_name,
          Component: 'Edit',
          parent: this.currentNode,
          isTop: this.isTop,
        },
      }
    );
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const node: GETsterAppCategoryData = {
          getster_app_category_id: this.currentNode.getster_app_category_id,
          parent_getster_app_category_id:
            this.currentNode.parent_getster_app_category_id,
          getster_app_category_name: result.getster_app_category_name,
          is_the_getster_app_category_hidden:
            this.currentNode.is_the_getster_app_category_hidden,
          children: this.currentNode.children,
          getster_app_category_type: '0',
        };
        this.edittedNode.emit({ currentNode: this.currentNode, node: node });
      }
    });
  }
}

@Component({
  selector: 'getster-app-new-node-checkbox',
  templateUrl:
    '../getster-app-category-dialog/getster-app-category-dialog.component.html',
})
export class GETsterAppEditDialogRadioButtonComponent {
  constructor(
    public dialogRef: MatDialogRef<GETsterAppEditDialogRadioButtonComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GETsterAppDialogData
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
