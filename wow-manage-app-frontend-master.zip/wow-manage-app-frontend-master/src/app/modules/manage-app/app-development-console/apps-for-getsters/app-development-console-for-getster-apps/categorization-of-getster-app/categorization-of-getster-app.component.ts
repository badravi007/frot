import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { of } from 'rxjs';
import { GETsterAppCategoryData } from 'src/app/models/getster-app.interface';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { DataSharingService } from 'src/app/shared/services/data-sharing/data-sharing.service';
import { HeaderTitleService } from 'src/app/shared/services/header-title/header-title.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';
import { GetsterAppReassignDialogComponent } from './getster-app-reassign-dialog/getster-app-reassign-dialog.component';

@Component({
  selector: 'app-categorization-of-getster-app',
  templateUrl: './categorization-of-getster-app.component.html',
  styleUrls: ['./categorization-of-getster-app.component.scss'],
})
export class CategorizationOfGetsterAppComponent implements OnInit {
  @ViewChild('tree') tree: ElementRef;

  @Input() selected_getster_app_category_id: string;
  @Input() userAppCategoryId: string;

  hiddenCategories: boolean = false;

  users_list: any[] = [];
  selected_users_list_val: any = null;
  selected_category_name_val: any = null;

  constructor(
    private _apiService: GetsterAppService,
    private _headerTitle: HeaderTitleService,
    public dialog: MatDialog,
    public snackBarService: SnackBarService,
    public dataSharingService: DataSharingService,
    private fb: FormBuilder
  ) {}

  nestedTreeControl: NestedTreeControl<GETsterAppCategoryData>;
  nestedDataSource: MatTreeNestedDataSource<GETsterAppCategoryData>;
  treeNodeSelection = new SelectionModel<GETsterAppCategoryData>(
    true /* multiple */
  );

  apps_selection = new SelectionModel<any>(true /* multiple */);
  list_of_apps: any;
  ngOnInit() {
    this.nestedTreeControl = new NestedTreeControl<GETsterAppCategoryData>(
      this._getChildren
    );
    this.nestedDataSource = new MatTreeNestedDataSource();
    this.getAllGetsterAppCategory();
  }

  getAllGetsterAppCategory() {
    this._apiService.getAllGetsterAppCategory().subscribe((res) => {
      this.nestedDataSource.data = res.data;
      this.nestedTreeControl.dataNodes = res.data;

      // let selected_user_app_category_ids = res.data;

      // if (selected_user_app_category_ids.length > 0) {
      //   this.treeNodeSelection.clear(true);
      //   this.nestedDataSource.data.forEach((node) => {
      //     this.callRecursively(node);
      //   });
      // } else {
      //   this.treeNodeSelection.clear(true);
      //   this.apps_selection.clear(true);
      //   this.list_of_apps = [];
      // }
    });
  }

  callRecursively(node: any) {
    let userAppCategoryIds = this.userAppCategoryId.split(',');

    if (userAppCategoryIds.length > 0) {
      userAppCategoryIds.map((data) => {
        if (node.getster_app_category_id == data) {
          console.log(node.getster_app_category_id, data);
          this.todoLeafItemSelectionToggle(node);
          this.expand(this.nestedDataSource.data, data);
        }
        if (node.children) {
          node.children.forEach((childNode: any) => {
            this.callRecursively(childNode);
          });
        }
      });
    }
  }

  expand(data: any[], uniqueId: string): any {
    data.forEach((node) => {
      if (
        node.children &&
        node.children.find((c: any) => c.user_app_category_id === uniqueId)
      ) {
        this.nestedTreeControl.expand(node);
        this.expand(this.nestedDataSource.data, node.user_app_category_id);
      } else if (node.children && node.children.find((c: any) => c.children)) {
        this.expand(node.children, uniqueId);
      }
    });
  }

  //
  private _getChildren = (node: GETsterAppCategoryData) => of(node.children);

  hasNestedChild = (_: string, nodeData: GETsterAppCategoryData) =>
    nodeData.children.length > 0;

  refreshTreeData() {
    const data = this.nestedDataSource.data;
    this.nestedDataSource.data = null;
    this.nestedDataSource.data = data;
  }

  currentNodeVal: any;

  currentNodes(val: any) {
    console.log(val);

    this.currentNodeVal = val;
  }

  addNode(node: GETsterAppCategoryData) {
    let api_data: GETsterAppCategoryData = {
      getster_app_category_id: node.getster_app_category_id,
      parent_getster_app_category_id: node.parent_getster_app_category_id,
      getster_app_category_name: node.getster_app_category_name,
      is_the_getster_app_category_hidden: '0',
      getster_app_category_type: node.getster_app_category_type,
      children: node.children,
    };
    this._apiService.addGetsterAppCategory(api_data).subscribe((res) => {
      if (res['status'] === 200) {
        let data: GETsterAppCategoryData = {
          getster_app_category_id: node.getster_app_category_id,
          parent_getster_app_category_id: node.parent_getster_app_category_id,
          getster_app_category_name: node.getster_app_category_name,
          is_the_getster_app_category_hidden: 0,
          getster_app_category_type: node.getster_app_category_type,
          children: node.children,
        };
        this.nestedDataSource.data.push(data);
        this.refreshTreeData();
      }
    });
  }

  addChildNode(childrenNodeData: {
    currentNode: { children: any[] };
    node: any;
  }) {
    this._apiService
      .checkGetsterIsAssignedGetsterAppCategory(
        childrenNodeData.currentNode['getster_app_category_id']
      )
      .subscribe((res) => {
        const userIsAssigned = res.userIsAssigned;
        if (userIsAssigned) {
          if (
            confirm(
              'If you wish to create a sub category to the parent category where users / apps are assigned,the same shall be reassigned to this new sub category: ' +
                childrenNodeData.node.category_name +
                '. \nDo you wish to proceed ? '
            ) === true
          ) {
            this._apiService
              .addGetsterAppCategory(childrenNodeData.node)
              .subscribe((res) => {
                if (res['status'] === 200) {
                  let parent_data = childrenNodeData.currentNode;
                  let child_data = childrenNodeData.node;

                  this._apiService
                    .reassignGetsterAppCategory(parent_data, child_data)
                    .subscribe((res) => {
                      if (res['statusCode'] == 200) {
                        // res.OK call the refresh tree method
                        // childrenNodeData.currentNode.children.push(
                        //   childrenNodeData.node
                        // );
                        // this.refreshTreeData();

                        this.getAllGetsterAppCategory();
                      }
                    });
                  // this._apiService
                  //   .passingUsersParentToChild(data)
                  //   .subscribe((res) => {
                  //     if (res['status'] == 200) {
                  //       // res.OK call the refresh tree method
                  //       childrenNodeData.currentNode.children.push(
                  //         childrenNodeData.node
                  //       );
                  //       this.refreshTreeData();
                  //       this.loadAssignedCategoryData();
                  //     }
                  //   });
                }
              });
          }
        } else {
          this._apiService
            .addGetsterAppCategory(childrenNodeData.node)
            .subscribe((res) => {
              if (res['status'] === 200) {
                childrenNodeData.currentNode.children.push(
                  childrenNodeData.node
                );
                this.refreshTreeData();
              }
            });
        }
      });
  }

  editNode(nodeToBeEdited: {
    node: GETsterAppCategoryData;
    currentNode: { category_id: string };
  }) {
    this._apiService
      .updateGetsterAppCategory(nodeToBeEdited.node)
      .subscribe((res) => {
        if (res['status'] === 200) {
          const fatherElement: GETsterAppCategoryData | any =
            this.findFatherNode(
              nodeToBeEdited.currentNode.category_id,
              this.nestedDataSource.data
            );

          let elementPosition: number;
          if (fatherElement[0]) {
            fatherElement[0].children[fatherElement[1]] = nodeToBeEdited.node;
          } else {
            elementPosition = this.findPosition(
              nodeToBeEdited.currentNode.category_id,
              this.nestedDataSource.data
            );
            this.nestedDataSource.data[elementPosition] = nodeToBeEdited.node;
          }

          this.refreshTreeData();
        }
      });
  }

  deleteNode(nodeToBeDeleted: GETsterAppCategoryData) {
    const deletedElement: GETsterAppCategoryData | any = this.findFatherNode(
      nodeToBeDeleted.getster_app_category_id,
      this.nestedDataSource.data
    );
    let elementPosition: number;

    if (nodeToBeDeleted.is_the_getster_app_category_hidden == 1) {
      let confirm_text_1 =
        'Are you sure you want to Unhide \nParent Category: ' +
        nodeToBeDeleted.getster_app_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Unhide \nSub Category: ' +
        nodeToBeDeleted.getster_app_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_getster_app_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: '0',
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        let data: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: 0,
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        this._apiService.hideGETsterAppCategory(apidata).subscribe((res) => {
          if (res['status'] === 200) {
            const fatherElement: GETsterAppCategoryData | any =
              this.findFatherNode(
                nodeToBeDeleted.getster_app_category_id,
                this.nestedDataSource.data
              );
            let elementPosition: number;
            if (fatherElement[0]) {
              fatherElement[0].children[fatherElement[1]] = data;
            } else {
              elementPosition = this.findPosition(
                nodeToBeDeleted.getster_app_category_id,
                this.nestedDataSource.data
              );
              this.nestedDataSource.data[elementPosition] = data;
            }
            this.refreshTreeData();
          }
        });
      }
    } else if (nodeToBeDeleted.is_the_getster_app_category_hidden == 0) {
      let confirm_text_1 =
        'Are you sure you want to Hide \nParent Category: ' +
        nodeToBeDeleted.getster_app_category_name +
        ' ?';

      let confirm_text_2 =
        'Are you sure you want to Hide \nSub Category: ' +
        nodeToBeDeleted.getster_app_category_name +
        ' ?';

      if (
        window.confirm(
          nodeToBeDeleted.parent_getster_app_category_id == null
            ? confirm_text_1
            : confirm_text_2
        )
      ) {
        let apidata: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: '1',
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        let data: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: 1,
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        this._apiService
          .checkGetsterIsAssignedGetsterAppCategory(
            nodeToBeDeleted.getster_app_category_id
          )
          .subscribe((res) => {
            console.log(res.userIsAssigned);
            const userIsAssigned = res.userIsAssigned;
            if (userIsAssigned) {
              alert(
                'Users are present in this category! \n To hide kindly reassign the user to another category'
              );
              this.openUserReassignDialog(nodeToBeDeleted);
            } else {
              this._apiService
                .hideGETsterAppCategory(apidata)
                .subscribe((res) => {
                  if (res['status'] === 200) {
                    const fatherElement: GETsterAppCategoryData | any =
                      this.findFatherNode(
                        nodeToBeDeleted.getster_app_category_id,
                        this.nestedDataSource.data
                      );
                    let elementPosition: number;
                    if (fatherElement[0]) {
                      fatherElement[0].children[fatherElement[1]] = data;
                    } else {
                      elementPosition = this.findPosition(
                        nodeToBeDeleted.getster_app_category_id,
                        this.nestedDataSource.data
                      );
                      this.nestedDataSource.data[elementPosition] = data;
                    }
                    this.refreshTreeData();
                  }
                });
            }
          });

        // if (condition) {

        // }
      }
    }
    this.refreshTreeData();
  }

  @Output() reAssignedGetsterAppCategoryID = new EventEmitter();

  openUserReassignDialog(nodeToBeDeleted: GETsterAppCategoryData) {
    let dialogRef = this.dialog.open(GetsterAppReassignDialogComponent, {
      disableClose: true,
      width: '400px',
      minHeight: 'calc(100vh - 700px)',
      data: {
        nodeToBeDeleted: nodeToBeDeleted,
        tree_data: this.nestedDataSource.data,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        let apidata: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: '1',
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        let data: GETsterAppCategoryData = {
          getster_app_category_id: nodeToBeDeleted.getster_app_category_id,
          parent_getster_app_category_id:
            nodeToBeDeleted.parent_getster_app_category_id,
          getster_app_category_name: nodeToBeDeleted.getster_app_category_name,
          is_the_getster_app_category_hidden: 1,
          children: nodeToBeDeleted.children,
          getster_app_category_type: '0',
        };

        this._apiService.hideGETsterAppCategory(apidata).subscribe((res) => {
          if (res['status'] === 200) {
            const fatherElement: GETsterAppCategoryData | any =
              this.findFatherNode(
                nodeToBeDeleted.getster_app_category_id,
                this.nestedDataSource.data
              );
            let elementPosition: number;
            if (fatherElement[0]) {
              fatherElement[0].children[fatherElement[1]] = data;
            } else {
              elementPosition = this.findPosition(
                nodeToBeDeleted.getster_app_category_id,
                this.nestedDataSource.data
              );
              this.nestedDataSource.data[elementPosition] = data;
            }
            this.refreshTreeData();
          }
        });
        this.reAssignedGetsterAppCategoryID.emit();
        this.selected_category_name_val = false;

        // this.selected_user_app_category_ids_data = [];
        // this.selected_user_category_wise_app_access_data = [];
        // this.removeFormFields();
        // this.myForm = this.fb.group({
        //   dynamicForm: this.fb.array([this.createDefaultDynamicItem()]),
        // });
      }
    });
  }
  // Tree Functions
  flatJsonArray(
    flattenedAray: Array<GETsterAppCategoryData>,
    node: GETsterAppCategoryData[]
  ) {
    const array: Array<GETsterAppCategoryData> = flattenedAray;
    node.forEach((element) => {
      if (element.children) {
        array.push(element);
        this.flatJsonArray(array, element.children);
      }
    });
    return array;
  }

  findNodeMaxId(node: GETsterAppCategoryData[]) {
    const flatArray = this.flatJsonArray([], node);
    const flatArrayWithoutChildren: any[] = [];
    flatArray.forEach((element) => {
      flatArrayWithoutChildren.push(element.getster_app_category_id);
    });
    return Math.max(...flatArrayWithoutChildren);
  }

  findPosition(id: string, data: GETsterAppCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      if (id === data[i].getster_app_category_id) {
        return i;
      }
    }
    return null;
  }

  findFatherNode(category_id: string, data: GETsterAppCategoryData[]) {
    for (let i = 0; i < data.length; i += 1) {
      const currentFather = data[i];
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (category_id === currentFather.children[z]['category_id']) {
          return [currentFather, z];
        }
      }
      for (let z = 0; z < currentFather.children.length; z += 1) {
        if (category_id !== currentFather.children[z]['category_id']) {
          const result: any = this.findFatherNode(
            category_id,
            currentFather.children
          );
          if (result !== false) {
            return result;
          }
        }
      }
    }
    return false;
  }

  radiobtnval(node: GETsterAppCategoryData) {
    console.log(node);
  }

  getLevel = (node: GETsterAppCategoryData) => node.level;

  isExpandable = (node: GETsterAppCategoryData) => node.expandable;

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: GETsterAppCategoryData): any {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected = descendants.every((child) => {
      child;
    });
    return descendants.map((val) => {
      let temp: any = val.is_the_getster_app_category_hidden;
      let a: any[] = temp;
      return a;
    });
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: GETsterAppCategoryData): boolean {
    const descendants = this.nestedTreeControl.getDescendants(node);
    const result = descendants.some((child) =>
      this.treeNodeSelection.isSelected(child)
    );
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: GETsterAppCategoryData): void {
    this.treeNodeSelection.toggle(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    this.treeNodeSelection.isSelected(node)
      ? this.treeNodeSelection.select(...descendants)
      : this.treeNodeSelection.deselect(...descendants);
    console.log(node);
    // Force update for the parent
    descendants.forEach((child) => {
      this.treeNodeSelection.isSelected(child);
      console.log(child);
    });
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: GETsterAppCategoryData): void {
    console.log(node);
    this.treeNodeSelection.toggle(node);
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: GETsterAppCategoryData): void {
    let parent: GETsterAppCategoryData | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: GETsterAppCategoryData): void {
    const nodeSelected = this.treeNodeSelection.isSelected(node);
    const descendants = this.nestedTreeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every((child) => {
        return this.treeNodeSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.treeNodeSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.treeNodeSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: GETsterAppCategoryData): GETsterAppCategoryData | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.nestedTreeControl.dataNodes.indexOf(node) - 1;
    console.log(startIndex);

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.nestedTreeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  @Output() getSelectedGetsterCategoryID = new EventEmitter();
  onCategorySelection() {
    this.getSelectedGetsterCategoryID.emit(
      this.selected_category_name_val.getster_app_category_id
    );
  }

  assignCategory() {
    if (this.selected_category_name_val && this.selected_users_list_val) {
      // console.log(this.selected_category_name_val);
      let data = {
        category_id: this.selected_category_name_val.category_id,
        category_parent_id: this.selected_category_name_val.parent_category_id,
        getster_app_category_name:
          this.selected_category_name_val.getster_app_category_name,
        user_id: this.selected_users_list_val.user_id,
        user_name: this.selected_users_list_val.name,
      };
      // this._apiService.assign_category(data).subscribe((res) => {
      //   // console.log(res);
      //   this.snackBarService.success(res.message);
      //   this.loadAssignedCategoryData();
      // });
    }
  }

  // loadAssignedCategoryData() {
  //   this._apiService.get_assigned_category().subscribe((res) => {
  //     this.dataSharingService.updateAssignedCategoryData(res[0]);
  //   });
  // }
}
