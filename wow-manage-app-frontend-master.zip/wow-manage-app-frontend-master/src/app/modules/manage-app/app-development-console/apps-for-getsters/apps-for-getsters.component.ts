import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { GlobalConstants } from 'src/app/shared/util/global-constants';

@Component({
  selector: 'app-apps-for-getsters',
  templateUrl: './apps-for-getsters.component.html',
  styleUrls: ['./apps-for-getsters.component.scss'],
})
export class AppsForGetstersComponent implements OnInit {
  _GETsterAppList: any;
  constants: any = GlobalConstants;
  constructor(
    private router: Router,
    private loader: CustomSpinnerService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private _GETsterAppService: GetsterAppService
  ) {}

  ngOnInit(): void {
    this.getAllGETsterAppByCategoryWise();
  }

  getAllGETsterAppByCategoryWise() {
    this.loader.open();
    this._GETsterAppService.getAllGETsterAppByCategoryWise().subscribe(
      (res) => {
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
        this._GETsterAppList = res.data;
        this.getPublishedAppList(res.data);
        this.getUnPublishedAppList(res.data);

        this.loader.close();
      },
      (err) => {
        this.loader.close();
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  updateAppStatus(
    getster_app_id: number,
    getster_app_development_status: boolean
  ) {
    let body = {
      getster_app_id: getster_app_id,
      getster_app_development_status,
    };
    this._GETsterAppService.updateGETsterAppStatus(body).subscribe(
      (res) => {
        this.getAllGETsterAppByCategoryWise();
        this.snackBar.open(res.message, 'OK', { duration: 4000 });
      },
      (err) => {
        this.snackBar.open(err.error.text, 'OK', { duration: 4000 });
      }
    );
  }

  addEditGETsterApp(id: any, name: any, type) {
    if (type == 'Add') {
      this.router
        .navigate([
          '/manage-app/app-development-console/app-development-console-getster-apps-add',
          type,
        ])
        .then(() => {});
    } else if (type == 'Edit') {
      this.router
        .navigate([
          '/manage-app/app-development-console/app-development-console-getster-apps-edit',
          id,
          name,
          type,
        ])
        .then(() => {});
    }
  }

  getsterAppUnPublishedList: AppDetails[] = [];
  getUnPublishedAppList(appList: AppDetails[]) {
    let appDetails: AppDetails[] = [];
    for (let i = 0; i < appList.length; i++) {
      const element = appList[i];
      let appData: AppData[] = [];
      for (let j = 0; j < appList[i].data.length; j++) {
        const element = appList[i].data[j];
        if (element.getster_app_development_status == 0) {
          appData.push(element);
        }
      }

      if (appData.length > 0) {
        appDetails.push({
          getster_app_category_name: element.getster_app_category_name,
          data: appData,
        });
      }
    }
    this.getsterAppUnPublishedList = [...appDetails];
  }

  getsterAppPublishedList: AppDetails[] = [];
  getPublishedAppList(appList: AppDetails[]) {
    let appDetails: AppDetails[] = [];
    for (let i = 0; i < appList.length; i++) {
      const element = appList[i];
      let appData: AppData[] = [];
      for (let j = 0; j < appList[i].data.length; j++) {
        const element = appList[i].data[j];
        if (element.getster_app_development_status == 1) {
          appData.push(element);
        }
      }

      if (appData.length > 0) {
        appDetails.push({
          getster_app_category_name: element.getster_app_category_name,
          data: appData,
        });
      }
    }
    this.getsterAppPublishedList = [...appDetails];
  }
}

interface AppDetails {
  getster_app_category_name: string;
  data: AppData[];
}

interface AppData {
  getster_app_id: number;
  getster_app_icon_name: string;
  getster_app_icon_image_path: string;
  getster_app_full_name: string;
  getster_app_development_status: number;
  getster_app_category_location: number;
  getster_app_educational_institution_category_id: string;
  getster_app_country_code: string;
  custom_app_id?: any;
  CategoryName: string;
  getster_app_category_name: string;
  parent_user_app_category_id: string;
  getster_app_category_id: string;
}
