import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { GetsterAppService } from 'src/app/shared/services/app-development-console/getster-app.service';
import { CustomSpinnerService } from 'src/app/shared/services/custom-spinner/custom-spinner.service';
import { SnackBarService } from 'src/app/shared/services/snackbar/snackbar.service';

@Component({
  selector: 'app-getster-app-comments',
  templateUrl: './getster-app-comments.component.html',
  styleUrls: ['./getster-app-comments.component.scss'],
})
export class GetsterAppCommentsComponent implements OnInit {
  commentsFormGroup: FormGroup;
  constructor(
    private _GETsterAppService: GetsterAppService,
    private loader: CustomSpinnerService,
    private snackBar: SnackBarService,
    private fb: FormBuilder
  ) {}

  @Input() getster_app_id: number;

  ngOnInit() {
    this.commentsFormGroup = this.fb.group({
      app_comments: new FormControl(''),
    });
    this.getComments();
  }

  commentsList: any = [];
  getComments() {
    // this.loader.open();
    this._GETsterAppService
      .getGetsterAppComments(this.getster_app_id)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.success(res.message);
          this.commentsList = res.data;
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.message);
        }
      );
  }

  addComments() {
    let message = this.commentsFormGroup.value.app_comments;
    let body = {
      getster_id: localStorage.getItem('getster_id'),
      comment_text: message,
      is_the_comment_private: 0,
      comment_reply: null,
      comment_reply_by_getster_id: null,
    };

    this.loader.open();
    this._GETsterAppService
      .addGetsterAppComments(this.getster_app_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.success(res.message);
          this.resetCommentsForm();
          this.getComments();
        },
        (err) => {
          this.loader.close();
          // debugger;
          this.snackBar.error(err.error.message);
        }
      );
  }

  originalMessage = '';
  comment_id: number = 0;
  replybtn: false;
  pos;
  checkedCommentsItem(message, comment_id, replybtn, pos) {
    this.pos = pos;
    this.replybtn = replybtn;
    this.originalMessage = message;
    this.comment_id = comment_id;
    // this.notificationFormGroup.controls['app_comments'].setValue(item);
  }

  updateUserAppCommentsType(is_the_comment_private: any, getster_id: any) {
    let body = {
      is_the_comment_private: is_the_comment_private,
      comment_reply: this.commentsFormGroup.value.app_comments,
      comment_reply_by_getster_id: getster_id,
    };
    // this.loader.open();
    this._GETsterAppService
      .updateGetsterAppCommentsType(this.getster_app_id, this.comment_id, body)
      .subscribe(
        (res) => {
          this.loader.close();
          this.replybtn = false;
          this.snackBar.success(res.message);
          this.resetCommentsForm();
          this.originalMessage = '';
          this.comment_id = 0;
          this.getComments();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.text);
        }
      );
  }

  deleteGetsterAppComments(comment_id: any) {
    // this.loader.open();
    this._GETsterAppService
      .deleteGetsterAppComments(this.getster_app_id, comment_id)
      .subscribe(
        (res) => {
          this.loader.close();
          this.snackBar.success(res.message);
          this.getComments();
        },
        (err) => {
          this.loader.close();
          this.snackBar.error(err.error.message);
        }
      );
  }

  resetCommentsForm() {
    this.commentsFormGroup.reset();
  }
}
