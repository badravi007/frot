/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppDevelopmentConsoleForGetsterAppsComponent } from './app-development-console-for-getster-apps.component';

describe('AppDevelopmentConsoleForGetsterAppsComponent', () => {
  let component: AppDevelopmentConsoleForGetsterAppsComponent;
  let fixture: ComponentFixture<AppDevelopmentConsoleForGetsterAppsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDevelopmentConsoleForGetsterAppsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDevelopmentConsoleForGetsterAppsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
