import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent implements OnInit {
  constructor(private _router: Router, private _route: ActivatedRoute) {
    // _router.events.subscribe((res: ActivationEnd | any) => {
    //   console.log(res.snapshot.routeConfig.path);
    // });
    // let subPath = _router.url.toString().split('/')[2];
    // console.log('file: layout.component.ts:12 ~ subPath', subPath);
    let subPath = this._router.url.toString().split('/')[2];

    this.isLoginPage = subPath == 'login' ? true : false;
  }
  headerPosition: boolean = false;
  isLoginPage: boolean = false;

  @HostListener('window:scroll', ['$event'])
  onScroll(event: any) {
    if (document.body.scrollTop > 0 || document.documentElement.scrollTop > 0) {
      this.headerPosition = true;
    } else {
      this.headerPosition = false;
    }
  }

  // eslint-disable-next-line @angular-eslint/no-empty-lifecycle-method
  ngOnInit(): void {
    // window.location.reload();
  }
}
