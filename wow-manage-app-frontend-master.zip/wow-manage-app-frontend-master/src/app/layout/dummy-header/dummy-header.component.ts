import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy-header',
  templateUrl: './dummy-header.component.html',
  styleUrls: ['./dummy-header.component.scss'],
})
export class DummyHeaderComponent implements OnInit {
  @Input() imageUrl: number;
  constructor() {}

  ngOnInit() {}
}
