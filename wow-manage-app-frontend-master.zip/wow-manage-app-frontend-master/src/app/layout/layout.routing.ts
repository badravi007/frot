import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from '../modules/manage-app/not-found/not-found.component';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'manage-app',
        loadChildren: () =>
          import('../modules/manage-app/manage-app.module').then(
            (m) => m.ManageAppModule
          ),
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: '/manage-app/login',
      },
      {
        path: '404',
        component: NotFoundComponent,
      },
      { path: '**', redirectTo: '/404' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LayoutRoutingModule {}
