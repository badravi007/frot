import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout.component';
import { HeaderComponent } from './header/header.component';
import { SharedModule } from '../shared/shared.module';
import { Router } from '@angular/router';
import { LayoutRoutingModule } from './layout.routing';
import { FooterComponent } from './footer/footer.component';
import { PreviewHeaderComponent } from './preview-header/preview-header.component';
import { DummyHeaderComponent } from './dummy-header/dummy-header.component';
const COMPONENTS = [
  LayoutComponent,
  HeaderComponent,
  FooterComponent,
  PreviewHeaderComponent,
];

@NgModule({
  declarations: [COMPONENTS],
  imports: [CommonModule, SharedModule, LayoutRoutingModule],
})
export class LayoutModule {}
