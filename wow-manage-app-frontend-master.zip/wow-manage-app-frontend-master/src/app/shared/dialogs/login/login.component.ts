import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { GetsterRegisterService } from '../../services/app-development-console/getster-register.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  country_no: any = 'in';
  customer_id: any = '12';
  loginForm: FormGroup;

  isAuthError: boolean = false;

  getsterId: number;
  constructor(
    public dialogRef: MatDialogRef<LoginComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private formBuilder: FormBuilder,
    private _getsterRegisterService: GetsterRegisterService
  ) {
    this.loginForm = this.formBuilder.group({
      getster_password: ['', Validators.required],
    });
  }

  // eslint-disable-next-line @angular-eslint/no-empty-lifecycle-method
  ngOnInit() {
    // localStorage.setItem('country_no', this.country_no);
    // localStorage.setItem('customer_id', this.customer_id);

    this.getsterId = this.data.getster_id;
  }

  loginWithGetsterPassword() {
    let getster_password = this.loginForm.controls['getster_password'].value;
    this._getsterRegisterService
      .loginWithGetsterPassword(this.getsterId, getster_password)
      .subscribe((res) => {
        this.isAuthError = false;
        if (res.statusCode == 200) {
          this.dialogRef.close({
            token: res.data,
          });
        }
        if (res.statusCode == 401) {
          this.isAuthError = true;
        }
      });
  }

  onsubmit() {}
}
