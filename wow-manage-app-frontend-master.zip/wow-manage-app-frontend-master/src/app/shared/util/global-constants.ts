export const GlobalConstants = {
  user_app_image_base_url: 'https://api.getbiz.app/user-app/Userapp_Icon/',
  custom_app_image_base_url:
    'https://api.getbiz.app/custom-app/Customapp_Icon/',
  getster_app_image_base_url:
    'https://api.getbiz.app/getster-app/Getsterapp_Icon/',
};
