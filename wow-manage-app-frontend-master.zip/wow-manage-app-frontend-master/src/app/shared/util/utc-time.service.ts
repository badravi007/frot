import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root',
})
export class UtcTimeService {
  constructor() {}

  getUTC() {
    const now = new Date();
    return new Date(now.getTime() + now.getTimezoneOffset() * 60000);
  }

  // UTC Time Resived to convert
  getUTCtoLocal(utcDateTime: any): Date {
    if (utcDateTime === undefined || utcDateTime === null) {
      return utcDateTime;
    }
    const date = new Date(utcDateTime);
    return new Date(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
  }

  timestampToDate(timestamp: any) {
    return moment(timestamp).utc().format('DD MMMM YYYY');
  }

  utcToDate(utc: any) {
    return moment(utc).format('DD MMMM YYYY');
  }

  utcToDateTime(utc: any) {
    return moment(utc).format('DD MMMM YYYY HH:mm A');
  }
}
