import { Injectable } from '@angular/core';
import { v4 as uuidv4 } from 'uuid';
import { nanoid } from 'nanoid';
import { customAlphabet } from 'nanoid';

@Injectable({
  providedIn: 'root',
})
export class CustomIdGeneratorService {
  constructor() {}

  UuId() {
    return uuidv4();
  }

  NanoId() {
    return nanoid();
  }

  CustomNanoId() {
    const char =
      '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const customNanoid = customAlphabet(char, 15);
    return customNanoid();
  }
}
