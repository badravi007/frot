import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class CustomAppService {
  constructor(
    private http: HttpClient,
    private jwtAutService: JwtAuthService
  ) {}
  //*----------------------------------------------------------------------------

  getCustomAppByID(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_by_id}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  addCustomApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  updateCustomApp(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_custom_app}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getFileCustomAppMaster(file_name: string): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders({
      Accept: 'text/html, application/xhtml+xml, */*',
      'Content-Type': 'text/plain; charset=utf-8',
      observe: 'body',
    });

    let options: any = { headers: headers, responseType: 'arraybuffer' };
    return this.http.get<any>(
      `${environment.get_file_custom_app_master}?file_name=${file_name}`,
      options
      // this.jwtAutService.getJwtToken()
    );
  }
  updateCustomAppDevelopmentStatus(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_custom_app_development_status}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  createCommentsCommunicationTable(custom_app_id: number): Observable<any> {
    return this.http.post<any>(
      `${environment.create_custom_app_comments_communication_table}?custom_app_id=${custom_app_id}`,
      ''
      // this.jwtAutService.getJwtToken()
    );
  }

  // cloud_file_storage_permission
  addCustomAppCloudFileStoragePermission(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app_cloud_file_storage_permission}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  getCustomAppCloudFileStoragePermission(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_cloud_file_storage_permission}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  // additional_data
  addCustomAppAdditionalPermission(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app_additional_data}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  getAdditionalPermission(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_additional_data}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  // Demo Video
  addCustomAppAboutDemoVideoDescription(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app_about_demo_video_description}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  // Demo Video
  updateCustomAppAboutDemoVideoDescription(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_custom_app_about_demo}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  getCustomAppAboutDemoVideoDescription(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_about_demo_video_description}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  // communication
  getCustomAppCommunication(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_communication}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }
  addCustomAppCommunication(custom_app_id: number, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app_communication}?custom_app_id=${custom_app_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteCustomAppCommunication(
    custom_app_id: any,
    communication_id: any
  ): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_custom_app_communication}?custom_app_id=${custom_app_id}&communication_id=${communication_id}`,
      this.jwtAutService.getJwtToken()
    );
  }

  // comments
  getCustomAppComments(custom_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_custom_app_comments}?custom_app_id=${custom_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }
  addCustomAppComments(custom_app_id: number, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_custom_app_comments}?custom_app_id=${custom_app_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteCustomAppComments(
    custom_app_id: number,
    comment_id: number
  ): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_custom_app_comments}?custom_app_id=${custom_app_id}&comment_id=${comment_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  updateCustomAppCommentsType(
    custom_app_id: number,
    comment_id: any,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.update_custom_app_comments_type}?custom_app_id=${custom_app_id}&comment_id=${comment_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  // Category
  getAllUserCustomAppsByCategoryIds(
    user_app_category_id: string
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_custom_apps_by_category_ids}?user_app_category_id=${user_app_category_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  getAllCustomApps(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_custom_apps}`
      // this.jwtAutService.getJwtToken()
    );
  }
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  //!----------------------------------------------------------------------------
  // get_customer_list(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_customer_list}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // get_customer_apps(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_customer_app}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // add_customer_apps(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.add_customer_app}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // delete_customer_apps(customer_id: any): Observable<any> {
  //   return this.http.delete<any>(
  //     `${environment.delete_customer_app}?customer_id=${customer_id}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // getAllCustomAppsByCategoryWise(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_custom_apps_by_category_wise}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // getAllUserApp(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_user_apps}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // // Category

  // getUserAppCategories(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_user_app_category}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // getUserAppCategoriesByID(appId: any): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_user_app_by_category_id}?user_app_category_id=${appId}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // addUserAppCategory(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.add_user_app_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // assignCustomAppToUserCategory(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.assign_custom_app_to_user_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // updateUserAppCategory(body: any): Observable<any> {
  //   return this.http.put<any>(
  //     `${environment.update_user_app_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // deleteUserAppsFromCategory(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.delete_user_apps_from_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // deleteUserAppCategory(UserCategoryId: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.delete_user_app_category}?UserCategoryId=${UserCategoryId}`,
  //     '',
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // reassignUserCategory(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.reassign_user_app_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // updateUserAppPreviewLocation(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.update_assign_user_apps_category}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // //

  // updateCustomAppCloudFileStoragePermission(body: any): Observable<any> {
  //   return this.http.put<any>(
  //     `${environment.update_custom_app_cloud_file_storage_permission}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // updateCustomAppAdditionalPermission(body: any): Observable<any> {
  //   return this.http.put<any>(
  //     `${environment.update_custom_app_additional_data}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // //

  // addLaunchScreenDisplay(body: any, type: any): Observable<any> {
  //   let request = '';
  //   // if (type == 'Add') {
  //   //   request = environment.add_launch_screen_display;
  //   // } else if (type == 'Edit') {
  //   //   request = environment.update_launch_screen_display;
  //   // }
  //   return this.http.post<any>(
  //     `${request}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // getLaunchScreenDisplay(user_app_id: any): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_user_custom_apps}?user_app_id=${user_app_id}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // //

  // updateCustomAppNotification(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.update_custom_app_comments_type}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }
  // //

  // updateCustomAppComments(
  //   custom_app_id: number,
  //   comment_id: any,
  //   body: any
  // ): Observable<any> {
  //   return this.http.put<any>(
  //     `${environment.update_custom_app_comments}?custom_app_id=${custom_app_id}&comment_id=${comment_id}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  // //

  // getAllCustomAppAuditTrail(): Observable<any> {
  //   return this.http.get<any>(
  //     `${environment.get_all_custom_app_audit_trail}`,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }
}
