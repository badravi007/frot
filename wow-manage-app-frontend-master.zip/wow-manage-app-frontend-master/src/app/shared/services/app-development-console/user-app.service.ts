import { HttpBackend, HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class UserAppService {
  getster_id: any;
  customer_id: any;
  country_code: any;
  timeZoneIanaString: any;

  private httpClient: HttpClient;

  constructor(
    private http: HttpClient,
    private handler: HttpBackend,
    private jwtAutService: JwtAuthService
  ) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }
  getValues() {
    this.getster_id = localStorage.getItem('getster_id');
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
    this.timeZoneIanaString = localStorage.getItem('time_zone_iana_string');
  }

  // ---- Start -----
  // Screen Name: Apps for GETSTERs
  getAllGETsterAppByCategoryWise(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_app_by_category_wise}`
    );
  }

  updateGETsterAppStatus(body: any): Observable<any> {
    return this.http.put<any>(`${environment.update_getster_app_status}`, body);
  }

  // Screen Name: ADD/EDIT Apps for GETSTERs
  getGetsterAppById(getster_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_app_by_id}?getster_app_id=${getster_app_id}`
    );
  }

  addUserApp(body: any): Observable<any> {
    return this.http.post<any>(`${environment.add_user_app}`, body);
  }

  updateUserApp(body: any): Observable<any> {
    return this.http.put<any>(`${environment.update_user_app}`, body);
  }

  createCommentsCommunicationTable(user_app_id: number): Observable<any> {
    return this.http.post<any>(
      `${environment.create_user_app_comments_communication_table}?user_app_id=${user_app_id}`,
      ' '
    );
  }

  // Getster App Category

  getAllUserAppCategory(): Observable<any> {
    return this.http.get<any>(`${environment.get_all_user_app_category}`);
  }

  getAllUserAppByIds(ids: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_app_by_ids}?getster_app_category_id=${ids}`
    );
  }

  addUserAppCategory(body: any): Observable<any> {
    return this.http.post<any>(`${environment.add_user_app_category}`, body);
  }

  updateUserAppCategory(body: any): Observable<any> {
    return this.http.put<any>(`${environment.update_user_app_category}`, body);
  }

  hideUserAppCategory(body: any): Observable<any> {
    return this.http.put<any>(`${environment.hide_user_app_category}`, body);
  }

  checkUserAppIsAssignedUserAppCategory(
    user_app_category_id: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.check_user_app_is_assigned_user_app_category}?user_app_category_id=${user_app_category_id}`
    );
  }
  userAppCategoryId(user_app_category_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.user_app_category_id}?user_app_category_id=${user_app_category_id}`
    );
  }

  AssignGetsterCategoryToGetsterApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.assign_getster_category_to_getster_app}`,
      body
    );
  }
  // end

  getAllUserApps(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_apps}`
      // this.jwtAutService.getJwtToken()
    );
  }
  getFileUserAppMaster(file_name: string): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders({
      Accept: 'text/html, application/xhtml+xml, */*',
      'Content-Type': 'text/plain; charset=utf-8',
      observe: 'body',
    });

    let options: any = { headers: headers, responseType: 'arraybuffer' };
    return this.http.get<any>(
      `${environment.get_file_user_app_master}?file_name=${file_name}`,
      options
      // this.jwtAutService.getJwtToken()
    );
  }

  getFileUserAppLaunchScreenDisplay(file_name: string): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders({
      Accept: 'text/html, application/xhtml+xml, */*',
      'Content-Type': 'text/plain; charset=utf-8',
      observe: 'body',
    });

    let options: any = { headers: headers, responseType: 'arraybuffer' };
    return this.http.get<any>(
      `${environment.get_file_user_app_launch_screen_display}?file_name=${file_name}`,
      options
      // this.jwtAutService.getJwtToken()
    );
  }

  getAllUserCustomApps(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_custom_apps}`
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppByID(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_by_id}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  addUserAppData(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_app}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppDevelopmentStatus(body: any): Observable<any> {
    // let body = {
    //   user_app_id: user_app_id,
    //   user_app_development_status: user_app_development_status,
    // };
    return this.http.put<any>(
      `${environment.update_user_app_development_status}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  // Category

  getAllUserAppCategories(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_app_category}`
      // this.jwtAutService.getJwtToken()
    );
  }

  getAllUserAppByCategoryID(appId: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_app_by_category_id}?user_app_category_id=${appId}`
      // this.jwtAutService.getJwtToken()
    );
  }

  AssignCategoryToUserApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.assign_category_to_user_app}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteUserAppsFromCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.delete_user_apps_from_category}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteUserAppCategory(user_app_category_id: string): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_user_app_category}?user_app_category_id=${user_app_category_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  reassignUserAppCategory(
    user_app_category_id,
    getster_id: any,
    user_app_activity_utc_date_time: any,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.reassign_user_app_category}?user_app_category_id=${user_app_category_id}&getster_id=${getster_id}&user_app_activity_utc_date_time=${user_app_activity_utc_date_time}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  reassignUserAppBusinessCategory(
    user_app_business_category_id,
    getster_id: any,
    user_app_activity_utc_date_time: any,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.reassign_user_app_business_category}?user_app_business_category_id=${user_app_business_category_id}&getster_id=${getster_id}&user_app_activity_utc_date_time=${user_app_activity_utc_date_time}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppPreviewLocation(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.update_assign_user_apps_category}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  addUpdateUserAppCloudStoragePermission(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_update_user_app_cloud_file_storage_permission}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppCloudStoragePermission(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_cloud_storage_permission}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  addUpdateUserAppAdditionalPermission(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_app_additional_data}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getAdditionalPermission(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_additional_data}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  addUpdateUserAppLaunchScreenDisplay(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_update_user_app_launch_screen_display}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }
  updateUserAppLaunchScreenDisplay(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_user_app_launch_screen_display}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppLaunchScreenDisplay(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_launch_screen_display}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  addUpdateUserAppAboutDemoVideo(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_update_user_app_about_demo_video}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppAboutDemoVideo(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_user_app_about_demo}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppAboutDemoVideo(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_about_demo_video}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  addUserAppCommunication(user_app_id: any, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_app_communication}?user_app_id=${user_app_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppCommunication(
    user_app_id: number,
    communication_id: number,
    body: any
  ): Observable<any> {
    return this.http.post<any>(
      `${environment.update_user_app_comments_type}?user_app_id=${user_app_id}&communication_id=${communication_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppCommunication(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_communication}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteUserAppCommunication(
    user_app_id: any,
    communication_id: any
  ): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_user_app_communication}?user_app_id=${user_app_id}&communication_id=${communication_id}`
      // this.jwtAutService.getJwtToken()
    );
  }
  //

  addUserAppComments(user_app_id: number, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_app_comments}?user_app_id=${user_app_id}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppCommentsType(
    user_app_id: number,
    comment_id: number,
    is_the_comment_private: any,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.update_user_app_comments_type}?user_app_id=${user_app_id}&comment_id=${comment_id}&is_the_comment_private=${is_the_comment_private}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  updateUserAppComments(
    user_app_id: number,
    comment_id: number,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.update_user_app_comments}?user_app_id=${user_app_id}&comment_id=${comment_id}]`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  getUserAppComments(user_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_app_comments}?user_app_id=${user_app_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  deleteUserAppComments(comment_id: any, user_app_id: any): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_user_app_comments}?user_app_id=${user_app_id}&comment_id=${comment_id}`
      // this.jwtAutService.getJwtToken()
    );
  }

  //

  getAllUserAppAuditTrail(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_user_app_audit_trail}`
      // this.jwtAutService.getJwtToken()
    );
  }
}
