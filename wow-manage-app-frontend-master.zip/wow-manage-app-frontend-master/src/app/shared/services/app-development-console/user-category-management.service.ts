// import { HttpBackend, HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { map, Observable } from 'rxjs';
// import { environment } from 'src/environments/environment';

// @Injectable({
//   providedIn: 'root',
// })
// export class UserCategoryManagementService {
//   customer_id: any;
//   country_code: any;

//   private httpClient: HttpClient;

//   constructor(private http: HttpClient, private handler: HttpBackend) {
//     this.getValues();
//     this.httpClient = new HttpClient(handler);
//   }
//   getValues() {
//     this.customer_id = localStorage.getItem('customer_id');
//     this.country_code = localStorage.getItem('country_code');
//   }

//   post_category(body: any): Observable<any> {
//     return this.http.post<any>(
//       `${environment.add_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   get_category(): Observable<any> {
//     return this.http
//       .get<any>(
//         `${environment.get_categories}?country_code=${this.country_code}&customer_id=${this.customer_id}`
//       )
//       .pipe(
//         map((m) => {
//           let data = m.data;
//           let msg = m.message;
//           return [data, msg];
//         })
//       );
//   }

//   update_category(body: any): Observable<any> {
//     return this.http.put<any>(
//       `${environment.update_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   hide_category(body: any): Observable<any> {
//     return this.http.put<any>(
//       `${environment.hide_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   assign_category(body: any) {
//     return this.http.post<any>(
//       `${environment.assign_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   get_users() {
//     return this.http
//       .get<any>(
//         `${environment.get_users}?country_code=${this.country_code}&customer_id=${this.customer_id}`
//       )
//       .pipe(
//         map((m) => {
//           let data = m.data;
//           let msg = m.message;
//           return [data, msg];
//         })
//       );
//   }

//   get_assigned_category() {
//     return this.http
//       .get<any>(
//         `${environment.get_assigned_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`
//       )
//       .pipe(
//         map((m) => {
//           let data = m.data;
//           let msg = m.message;
//           return [data, msg];
//         })
//       );
//   }

//   get_users_category_id(category_id: string) {
//     return this.http
//       .get<any>(
//         `${environment.get_users_category_id}?country_code=${this.country_code}&customer_id=${this.customer_id}&category_id=${category_id}`
//       )
//       .pipe(
//         map((m) => {
//           let data = m.data;
//           let msg = m.message;
//           return [data, msg];
//         })
//       );
//   }

//   update_assigned_category(body: any) {
//     return this.http.put<any>(
//       `${environment.update_assigned_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   check_user_is_assigned_category(body: any): Observable<any> {
//     return this.http.post<any>(
//       `${environment.check_user_is_assigned_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }

//   passingUsersParentToChild(body: any): Observable<any> {
//     return this.http.put<any>(
//       `${environment.passingUsersParentToChild}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
//       body
//     );
//   }
// }

import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserCategoryManagementService {
  customer_id: any;
  country_code: any;

  private httpClient: HttpClient;

  constructor(private http: HttpClient, private handler: HttpBackend) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }

  getValues() {
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
  }

  post_category(body: any): Observable<any> {
    return this.http.post<any>(`${environment.add_getster_category}`, body);
  }

  update_category(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_category}?country_code=${this.country_code}&customer_id=${this.customer_id}`,
      body
    );
  }

  hide_category(body: any): Observable<any> {
    return this.http.put<any>(`${environment.hide_category}`, body);
  }

  get_category(): Observable<any> {
    return this.http.get<any>(`${environment.get_all_getster_category}`).pipe(
      map((m) => {
        let data = m.data;
        let msg = m.message;
        return [data, msg];
      })
    );
  }

  get_user_category_wise_app_access_and_userapp_user_registration_data(
    user_category_id: string
  ): Observable<any> {
    return this.http
      .get<any>(
        `${environment.get_user_category_wise_app_access_and_userapp_user_registration_data}?country_code=${this.country_code}&customer_id=${this.customer_id}&user_category_id=${user_category_id}`
      )
      .pipe(
        map((m) => {
          let data = m.data;
          let msg = m.message;
          return [data, msg];
        })
      );
  }

  get_user_app_categories(): Observable<any> {
    return this.http.get<any>(`${environment.get_user_app_categories}`).pipe(
      map((m) => {
        let data = m.data;
        let msg = m.message;
        return [data, msg];
      })
    );
  }

  get_all_user_app_by_category_ids(user_app_category_id: any): Observable<any> {
    return this.http
      .get<any>(
        `${environment.get_all_user_app_by_category_ids}?user_app_category_id=${user_app_category_id}`
      )
      .pipe(
        map((m) => {
          let data = m.data;
          let msg = m.message;
          return [data, msg];
        })
      );
  }

  check_user_is_assigned_category(getster_category_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.check_getster_is_assigned_getster_category}?getster_category_id=${getster_category_id}`
    );
  }

  addUserCategoryWiseAppAccess(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_category_wise_app_access}`,
      body
    );
  }

  // updateUserCategoryWiseAppAccess(body: any): Observable<any> {
  //   return this.http.put<any>(
  //     `${environment.update_user_category_wise_app_access}`,
  //     body
  //   );
  // }

  reassignUserCategoryIdToAnother(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.reassign_user_category_id_to_another}?country_code=${body.country_code}&customer_id=${body.customer_id}&user_id=${body.user_id}&existing_user_category_id=${body.existing_user_category_id}&new_user_category_id=${body.new_user_category_id}`,
      null
    );
  }

  get_user_category_audit_trail() {
    return this.http
      .get<any>(
        `${environment.user_category_audit_trail}?country_code=${this.country_code}&customer_id=${this.customer_id}`
      )
      .pipe(
        map((m) => {
          let data = m.data;
          let msg = m.message;
          return [data, msg];
        })
      );
  }

  get_additional_data_fields_by_user_category_id(body: any) {
    return this.http
      .get<any>(
        `${environment.get_additional_data_fields_by_user_category_id}?country_code=${body.country_code}&customer_id=${body.customer_id}&user_category_id=${body.user_category_id}`
      )
      .pipe(
        map((m) => {
          let data = m.data;
          let msg = m.message;
          return [data, msg];
        })
      );
  }
}
