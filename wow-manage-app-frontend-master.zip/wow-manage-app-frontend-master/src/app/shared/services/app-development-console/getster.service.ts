import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class GetsterService {
  getster_id: any;
  customer_id: any;
  country_code: any;
  timeZoneIanaString: any;

  private httpClient: HttpClient;

  constructor(
    private http: HttpClient,
    private handler: HttpBackend,
    private jwtAutService: JwtAuthService
  ) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }
  getValues() {
    this.getster_id = localStorage.getItem('getster_id');
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
    this.timeZoneIanaString = localStorage.getItem('time_zone_iana_string');
  }

  // ---- Start -----
  // Getster App Category

  getAllGetsterCategory(): Observable<any> {
    return this.http.get<any>(`${environment.get_all_getster_category}`);
  }

  getAllGetsterByIds(ids: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_category}?getster_category_id=${ids}`
    );
  }

  addGetsterCategory(body: any): Observable<any> {
    return this.http.post<any>(`${environment.add_getster_category}`, body);
  }

  updateGetsterCategory(body: any): Observable<any> {
    return this.http.put<any>(`${environment.update_getster_category}`, body);
  }

  hideGETsterCategory(body: any): Observable<any> {
    return this.http.put<any>(`${environment.hide_getster_category}`, body);
  }

  checkGetsterIsAssignedGetsterCategory(
    getster_category_id: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.check_getster_is_assigned_getster_category}?getster_category_id=${getster_category_id}`
    );
  }

  AssignGetsterCategoryToGetster(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.assign_getster_category_to_getster_app}`,
      body
    );
  }

  reassignGetsterCategoryIdToAnother(
    existing_getster_category_id: string,
    new_getster_category_id: string
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.reassign_getster_category_id_to_another}?existing_getster_category_id=${existing_getster_category_id}&new_getster_category_id=${new_getster_category_id}`,
      null
    );
  }

  addUserCategoryWiseAppAccess(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_user_category_wise_app_access}`,
      body
    );
  }

  getUserCategoryWiseAppAccess(getster_category_id: string): Observable<any> {
    return this.http.get<any>(
      `${environment.get_user_category_wise_app_access}?getster_category_id=${getster_category_id}`
    );
  }

  getGetsterCategoryWiseAdditionalFields(
    getster_category_id: string
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_category_wise_additional_fields}?getster_category_id=${getster_category_id}`
    );
  }

  getGetsterGetsterCategoryAuditTrail(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_getster_category_audit_trail}`
    );
  }

  // Home Scree Apps
  onGetHomeScreenApps(): Observable<any> {
    return this.http.get<any>(
      `${environment.home_screen_apps}`,
      this.jwtAutService.getJwtToken()
    );
  }
}
