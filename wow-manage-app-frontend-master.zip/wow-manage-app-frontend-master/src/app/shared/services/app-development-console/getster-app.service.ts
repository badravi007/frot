import { HttpBackend, HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class GetsterAppService {
  getster_id: any;
  customer_id: any;
  country_code: any;
  timeZoneIanaString: any;

  private httpClient: HttpClient;

  constructor(
    private http: HttpClient,
    private handler: HttpBackend,
    private jwtAutService: JwtAuthService
  ) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }
  getValues() {
    this.getster_id = localStorage.getItem('getster_id');
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
    this.timeZoneIanaString = localStorage.getItem('time_zone_iana_string');
  }

  // ---- Start -----
  // Screen Name: Apps for GETSTERs
  getAllGETsterAppByCategoryWise(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_app_by_category_wise}`
    );
  }

  updateGETsterAppStatus(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_getster_app_status}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  // Screen Name: ADD/EDIT Apps for GETSTERs
  getGetsterAppById(getster_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_app_by_id}?getster_app_id=${getster_app_id}`
    );
  }
  getFileGetsterAppMaster(file_name: any): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders({
      Accept: 'text/html, application/xhtml+xml, */*',
      'Content-Type': 'text/plain; charset=utf-8',
      observe: 'body',
    });

    let options: any = { headers: headers, responseType: 'arraybuffer' };

    return this.http.get<any>(
      `${environment.get_file_getster_app_master}?file_name=${file_name}`,
      options
    );
  }

  addGetsterApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_getster_app}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  updateGetsterApp(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_getster_app}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  createCommentsCommunicationTable(user_app_id: number): Observable<any> {
    return this.http.post<any>(
      `${environment.create_getster_app_comments_communication_table}?getster_app_id=${user_app_id}`,
      ''
    );
  }

  // Getster App Category

  getAllGetsterAppCategory(): Observable<any> {
    return this.http.get<any>(`${environment.get_all_getster_app_category}`);
  }

  getAllGetsterAppByIds(ids: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_app_by_ids}?getster_app_category_id=${ids}`
    );
  }

  addGetsterAppCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_getster_app_category}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  updateGetsterAppCategory(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_getster_app_category}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  hideGETsterAppCategory(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.hide_getster_app_category}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  checkGetsterIsAssignedGetsterAppCategory(
    getster_app_category_id: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.check_getster_is_assigned_getster_app_category}?getster_app_category_id=${getster_app_category_id}`,
      this.jwtAutService.getJwtToken()
    );
  }

  AssignGetsterCategoryToGetsterApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.assign_getster_category_to_getster_app}`,
      body
    );
  }

  // Getster App Communication
  getGetsterAppCommunication(getster_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_app_communication}?getster_app_id=${getster_app_id}`
    );
  }

  addGetsterAppCommunication(getster_app_id: any, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_getster_app_communication}?getster_app_id=${getster_app_id}&timeZoneIanaString=${this.timeZoneIanaString}`,
      body
    );
  }

  deleteGetsterAppCommunication(
    getster_app_id: any,
    communication_id: any
  ): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_getster_app_communication}?getster_app_id=${getster_app_id}&communication_id=${communication_id}`
    );
  }

  // Getster APp Comments
  getGetsterAppComments(getster_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_app_comments}?getster_app_id=${getster_app_id}`
    );
  }

  addGetsterAppComments(getster_app_id: any, body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_getster_app_comments}?getster_app_id=${getster_app_id}&timeZoneIanaString=${this.timeZoneIanaString}`,
      body
    );
  }

  deleteGetsterAppComments(
    getster_app_id: any,
    comment_id: any
  ): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_getster_app_comments}?getster_id=${this.getster_id}&getster_app_id=${getster_app_id}&comment_id=${comment_id}`
    );
  }

  updateGetsterAppCommentsType(
    getster_app_id: any,
    comment_id: any,
    body: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.update_getster_app_comments_type}?getster_app_id=${getster_app_id}&comment_id=${comment_id}`,
      body
    );
  }

  // Getster App Demo Video Description
  addGetsterAppAboutDemoVideoDescription(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_getster_app_about_demo_video_description}`,
      body
    );
  }

  getGetsterAppAboutDemoVideoDescription(getster_app_id: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_app_about_demo_video_description}?getster_app_id=${getster_app_id}`
    );
  }

  // ----- end -----

  getAppCategoriesByID(appId: any): Observable<any> {
    return this.http.get<any>(
      `${environment.get_app_category_by_id}?getster_app_id=${appId}`,
      this.jwtAutService.getJwtToken()
    );
  }

  updatePreviewLocation(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.update_preview_location1}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }
  deleteAppsFromCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.delete_apps_from_category}`,
      body
    );
  }

  deleteGetsterAppCategory(getster_app_category_id: any): Observable<any> {
    return this.http.delete<any>(
      `${environment.delete_getster_app_category}?getster_app_category_id=${getster_app_category_id}`,
      this.jwtAutService.getJwtToken()
    );
  }

  reassignGetsterAppCategory(
    existing_getster_app_category_id: any,
    new_getster_app_category_id: any
  ): Observable<any> {
    return this.http.put<any>(
      `${environment.reassign_getster_app_category_id_to_another}?existing_getster_app_category_id=${existing_getster_app_category_id}&new_getster_app_category_id=${new_getster_app_category_id}`,
      this.jwtAutService.getJwtToken()
    );
  }

  updateGetsterAppAboutDemoVideoDescription(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_getster_app_about_demo_video_description}`,
      body
      // this.jwtAutService.getJwtToken()
    );
  }

  // updateNotification(body: any): Observable<any> {
  //   return this.http.post<any>(
  //     `${environment.update_about_custom_app_video_description}`,
  //     body,
  //     this.jwtAutService.getJwtToken()
  //   );
  // }

  updateComments(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.update_comments}`,
      body,
      this.jwtAutService.getJwtToken()
    );
  }

  getAllGetsterAppAuditTrail(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_getster_app_audit_trail}`,
      this.jwtAutService.getJwtToken()
    );
  }
}
