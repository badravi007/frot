import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
// import * as DateTime from 'luxon';
@Injectable({
  providedIn: 'root',
})
export class ConsoleUserService {
  customer_id: any;
  country_no: any;
  entry_by_user_id = 2;
  country_id = 'in';
  getster_id = 2;
  camp_id: 1;
  private httpClient: HttpClient;

  constructor(private http: HttpClient, private handler: HttpBackend) {
    this.getvalues();
    this.httpClient = new HttpClient(handler);
  }
  // cuttentTimestamp(): Promise<any> {
  //   let { DateTime } = require('luxon');
  //   var TimeZoneIanaString = 'Asia/Kolkata';
  //   var local = DateTime.local({ zone: TimeZoneIanaString }); //
  //   var serverLocalDateAndTimeFormate = DateTime.local({
  //     zone: TimeZoneIanaString,
  //   }).toFormat('yyyy-MM-dd TT');
  //   return serverLocalDateAndTimeFormate;
  // }
  // customCurrentTimestamp(): Promise<any> {
  //   let { DateTime } = require('luxon');
  //   var TimeZoneIanaString = 'Asia/Kolkata';
  //   var local = DateTime.local({ zone: TimeZoneIanaString });
  //   var overrideZone = DateTime.fromISO(local, {
  //     zone: TimeZoneIanaString,
  //   });
  //   var current_utc_timestamp = overrideZone.toString();
  //   var da: any = moment(current_utc_timestamp).format('D MMM YYYY, h:mm a');
  //   return da;
  // }

  getvalues() {
    this.customer_id = localStorage.getItem('customer_id');
    this.country_no = localStorage.getItem('country_no');
  }

  getNewGetster(): Observable<any> {
    return this.http.get<any>(`${environment.get_new_getster}`);
  }
  getGetsterProfile(getster_id: number): Observable<any> {
    return this.http.get<any>(
      `${environment.get_getster_profile}?getster_id=${getster_id}`
    );
  }

  getExistingGetster(): Observable<any> {
    return this.http.get<any>(`${environment.get_existing_profile}`);
  }
  // getManualBlockGetster(): Observable<any> {
  //   return this.http.get<any>(`${environment.get_manual_block_getster}`);
  // }
  updateGetsterApprovalStatus(getster_id: number): Observable<any> {
    let body = {
      getster_id: getster_id,
      approval_status: 2,
      entry_getster_id: this.entry_by_user_id,
    };
    return this.http.put<any>(`${environment.update_getster_profile}`, body);
  }
  updateGetsterApprovalRegistrationStatus(getster_id: number): Observable<any> {
    let body = {
      getster_id: getster_id,
      approval_status: 3,
      entry_getster_id: this.entry_by_user_id,
    };
    return this.http.put<any>(`${environment.update_getster_profile}`, body);
  }
  updateGetsterRemoveApprovalRegistrationStatus(
    getster_id: number
  ): Observable<any> {
    let body = {
      getster_id: getster_id,
      approval_status: 1,
      entry_getster_id: this.entry_by_user_id,
    };
    return this.http.put<any>(`${environment.update_getster_profile}`, body);
  }

  getAuditTrail(): Observable<any> {
    return this.http.get<any>(`${environment.get_audit_trail}`);
  }
}
