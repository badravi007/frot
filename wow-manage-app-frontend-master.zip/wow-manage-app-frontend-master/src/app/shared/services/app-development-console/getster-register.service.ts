import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class GetsterRegisterService {
  getster_id: any;
  customer_id: any;
  country_code: any;
  timeZoneIanaString: any;

  private httpClient: HttpClient;

  constructor(
    private http: HttpClient,
    private handler: HttpBackend,
    private jwtAutService: JwtAuthService
  ) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }
  getValues() {
    this.getster_id = localStorage.getItem('getster_id');
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
    this.timeZoneIanaString = localStorage.getItem('time_zone_iana_string');
  }

  // ---- Start -----
  // Getster Register

  loginRegister(body: any): Observable<any> {
    return this.http.post<any>(`${environment.login_register}`, body);
  }

  loginWithRegisteredMobileNumber(
    registered_mobile_number: any,
    registered_mobile_country_code: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.login_with_registered_mobile_number}?registered_mobile_number=${registered_mobile_number}&registered_mobile_country_code=${registered_mobile_country_code}`
    );
  }

  loginWithGetsterPassword(
    getster_id: any,
    getster_password: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.login_with_getster_password}?getster_id=${getster_id}&getster_password=${getster_password}`
    );
  }

  updateGetsterCategory(body: any): Observable<any> {
    return this.http.put<any>(`${environment.update_getster_category}`, body);
  }
}
