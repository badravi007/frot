import { HttpClient, HttpHeaders, HttpBackend } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { JwtAuthService } from '../auth/jwt-auth.service';

@Injectable({
  providedIn: 'root',
})
export class EducationalInstitutionsCategoryService {
  getster_id: any;
  customer_id: any;
  country_code: any;
  timeZoneIanaString: any;

  private httpClient: HttpClient;

  constructor(
    private http: HttpClient,
    private handler: HttpBackend,
    private jwtAutService: JwtAuthService
  ) {
    this.getValues();
    this.httpClient = new HttpClient(handler);
  }
  getValues() {
    this.getster_id = localStorage.getItem('getster_id');
    this.customer_id = localStorage.getItem('customer_id');
    this.country_code = localStorage.getItem('country_code');
    this.timeZoneIanaString = localStorage.getItem('time_zone_iana_string');
  }

  // ---- Start -----

  // Educational Institution Category

  getAllEducationalInstitutionCategory(): Observable<any> {
    return this.http.get<any>(
      `${environment.get_all_educational_institutions_category}`
    );
  }

  addEducationalInstitutionCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_educational_institutions_category}`,
      body
    );
  }

  updateEducationalInstitutionCategory(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.update_educational_institutions_category}`,
      body
    );
  }

  hideEducationalInstitutionCategory(body: any): Observable<any> {
    return this.http.put<any>(
      `${environment.hide_educational_institutions_category}`,
      body
    );
  }

  checkIsAssignedUserAppCategory(
    user_app_educational_institution_category_id: any
  ): Observable<any> {
    return this.http.get<any>(
      `${environment.check_is_assigned_user_app_category}?user_app_educational_institution_category_id=${user_app_educational_institution_category_id}`
    );
  }

  AssignEducationalInstitutionToUserApp(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.assign_getster_category_to_getster_app}`,
      body
    );
  }
  addDemoVideoForEducationalInstitutionsCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.add_demo_video_for_educational_institutions_category}`,
      body
    );
  }
  getDemoVideoForEducationalInstitutionsCategory(body: any): Observable<any> {
    return this.http.post<any>(
      `${environment.get_demo_video_for_educational_institution_category_by_id}`,
      body
    );
  }
}
