import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataSharingService {
  constructor() {}

  private Audit_trail = new BehaviorSubject<string>(undefined);
  audit_trail_data = this.Audit_trail.asObservable();

  updateAuditTrailData(data: string) {
    this.Audit_trail.next(data);
  }

  private Assigned_category = new BehaviorSubject<any>(undefined);
  assigned_category_data = this.Assigned_category.asObservable();

  updateAssignedCategoryData(data: any) {
    this.Assigned_category.next(data);
  }

  private AppCategoryListOfApps = new BehaviorSubject<any>(undefined);
  app_category_list_of_apps_data = this.AppCategoryListOfApps.asObservable();

  updateAppCategoryListOfAppData(data: any) {
    this.AppCategoryListOfApps.next(data);
  }
}
