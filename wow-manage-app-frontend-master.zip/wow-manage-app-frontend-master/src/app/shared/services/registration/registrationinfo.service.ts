import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RegistrationInfoService {
  iframeEmit = new EventEmitter();

  getGETsterInfo(body: any) {
    this.iframeEmit.emit({
      first_name: body.first_name,
      last_name: body.last_name,
      date_of_birth: body.date_of_birth,
      gender: body.gender,
      getster_category_id: body.getster_category_id,
      login_mobile_no: body.login_mobile_no,
      getster_password: body.getster_password,
      image: body.image,
    });
  }

  constructor() {}

  public productData: GETsterInfo = {} as GETsterInfo;
  public title = new BehaviorSubject(null);
  //Using Interfaces
  private getsterRecord: BehaviorSubject<GETsterInfo> =
    new BehaviorSubject<GETsterInfo>(this.productData);

  get getTitles(): Observable<any> {
    return this.title.asObservable();
  }

  public getGETster(): Observable<GETsterInfo> {
    return this.getsterRecord.asObservable();
  }

  public setGETster(product: GETsterInfo): void {
    this.getsterRecord.next(product);
  }
}

export interface GETsterInfo {
  first_name: string;
  last_name: string;
  date_of_birth: string;
  gender: string;
  getster_category_id: any;
  login_mobile_no: string;
  getster_password?: string;
  image?: any;
}
