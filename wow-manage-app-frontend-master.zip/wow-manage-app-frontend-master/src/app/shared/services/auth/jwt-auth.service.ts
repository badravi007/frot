import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { LocalStorageService } from '../local-storage/local-store.service';

@Injectable({
  providedIn: 'root',
})
export class JwtAuthService {
  return: string;

  constructor(
    private ls: LocalStorageService,
    private route: ActivatedRoute,
    private jwtService: JwtHelperService
  ) {
    this.route.queryParams.subscribe(
      (params) => (this.return = params['return'] || '/')
    );
  }

  getJwtToken() {
    let HTTP_OPTIONS = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/x-www-form-urlencoded',
        AuthenticationToken: localStorage.getItem('access_token'),
      }),
    };

    return HTTP_OPTIONS;
  }

  decodeJwtToken(jwt_token: string) {
    this.jwtService.decodeToken(jwt_token);
  }

  isLoggedIn(): Boolean {
    return !!this.getJwtToken();
  }
}
